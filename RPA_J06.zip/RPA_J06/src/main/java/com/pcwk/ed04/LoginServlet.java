package com.pcwk.ed04;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(description = "로그인", urlPatterns = { "/LoginServlet" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private Logger LOG = Logger.getLogger(LoginServlet.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // Dao 객체 생성
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		super.service(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //http://localhost:8080/RPA_J06/LoginServlet?user_id=%EC%9D%B4%EC%83%81%EB%AC%B4&user_passwd=2
		
		//Encoding
		request.setCharacterEncoding("utf-8");
		
		String userId     = request.getParameter("user_id");
		String userPasswd = request.getParameter("user_passwd");
		
		LOG.debug("userId:"+userId);
		LOG.debug("userPasswd:"+userPasswd);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String userId     = request.getParameter("user_id");
		String userPasswd = request.getParameter("user_passwd");
		LOG.debug("post:");
		LOG.debug("userId:"+userId);
		LOG.debug("userPasswd:"+userPasswd);
	}

}
