package com.pcwk.ed01;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.*;

public class FirstServlet extends HttpServlet {

	
	public void init() throws ServletException {
		System.out.println("init 메서드");
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException{
		System.out.println("Hello, world!");
		PrintWriter out = res.getWriter();
		
		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h2>Hello, world.</h2>");
		
		out.println("</body>");
		out.println("</html>");
		
	}
	
	
	
}
