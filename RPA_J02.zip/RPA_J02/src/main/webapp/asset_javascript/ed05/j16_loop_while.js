/**
 * while문
 * 1 ~ 10까지 더하기 
 */
 
 let num = 1;
 let sum = 0;
 
 while(num<=10){
   sum += num;
   console.log(`sum=${sum}, num=${num}`);
   num++;
 }
 
 console.log(`sum=${sum}`);