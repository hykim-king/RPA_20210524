/**
 * equality
 */
//0 -> false, 0이외 값은 true
 console.log(0 == false);//true
 console.log(0 === false);//false
 console.log('' == false);//true
 console.log('' === false);//false
 console.log(null == undefined);//true
 console.log(null === undefined);//false
 