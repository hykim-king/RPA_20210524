/**
 *  Operator
 */
 
 //1.+ 연산자
 let subject = 'css';
 let score   = 10;
 
 console.log(subject+' 과목에 성적은 '+score);
 //ECMAScript 2015(ES6)에 추가
 console.log(`${subject} 과목에 성적은 ${score}`);
 
 let num01    = 10;
 let num02    = 12;
 
 let sum      = num01+num02;
 
 console.log(`${num01} + ${num02} = ${sum}`);
 
 //2. -,*,/ , %,  연산자,** 승
 console.log(11 + 13);
 console.log(11 - 13);
 console.log(11 * 13);  
 console.log(11 / 13);//0.8461538461538461
 console.log(11 % 13);      
 /* console.log(2 ** 3);//8*/
 
 console.clear();//console지우기
 //3. 증감 연산자
 let score01 = 10;
 let result  = ++score01;//선증가후 result에 할당.
 console.log(`score01:${score01}, result:${result}`); //score01:11, result:11
 
 score01 = 10;
 result  = score01++;//할당후 증가
 console.log(`score01:${score01}, result:${result}`); //score01:11, result:10
 
 
 
 
 
 
 
 
 
 
 
 
 
 