  /**
   * 
   */
  console.log("Hello, world.");
  
  //한줄 comment
  /*
    여러줄 comment
  */
  
  console.log(num);
  
  
  //var 변수는 hosting 발생.
  //ECMAscript 6 -> let
  //BABEL써서 낮은 버전으로 실행 가능.
  var  num = 5;   
  
  //1. 하나의 실행문이 끝나면 마지막에 세미콜론을 붙여 준다.
  let  age = 5;
  console.log(age);    
  
  //2. 대소문자를 구분 한다.
  
  let  name = '이상무' ;
  console.log(name);  
  
  //console.log(Name);  
  
   
  //3. 가독을 위해 들여쓰기를 사용
  
  //4. 주석(comment)
  //한줄 주석
  
  /* 여러줄 주석 */












