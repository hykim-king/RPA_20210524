/**
 * do ~ while 
 */
 
 let i = -1;
 
 do{
   console.log(`do while:${i}`); 
   i--;
 }while(i>0);