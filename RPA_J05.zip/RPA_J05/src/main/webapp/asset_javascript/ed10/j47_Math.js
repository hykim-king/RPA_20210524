/**
 * 
 */
 
 let luckyNumber = [];
 let num = 0;
 
 for(let i =1;i<=100;i++){
    luckyNumber.push(i);
    //console.log(Math.random());
 }

//Math.random()
//함수는 0 <=x <1
//     0 <=x <100
  num = Math.floor(Math.random()* luckyNumber.length);
  console.log(luckyNumber.toString());
  console.log('오늘의 행운번호:'+luckyNumber[num]+' 입니다.');
  

 