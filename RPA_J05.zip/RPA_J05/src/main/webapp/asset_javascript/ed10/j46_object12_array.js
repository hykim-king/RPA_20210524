/**
 * 
 */
 
 const fruits = ['복숭아','수박','자두'];
 
 console.log(fruits);
 console.log(`fruits.length:${fruits.length}`);//배열의 길이
 
 console.log(`fruits[0]:${fruits[0]}`);
 console.log(`fruits[1]:${fruits[1]}`);
 console.log(`fruits[3]:${fruits[3]}`);//undefined
 
 console.clear();
 
 //반복문 사용 배열 처리
 for(let i=0;i<fruits.length;i++){
    console.log(`i=${i}, `+fruits[i]); 
 }
 
 //for .. in : index          
for(var j in fruits){
    console.log(j);//배열의 index
}
 
 //for .. of : value          
for(var k of fruits){
    console.log(k);//배열의 값
}
 
console.clear(); 
 //forEach
 //배열 요소에 순차적으로 접근하여 필요한 값을 만들 때 사용.                                
 fruits.forEach(function(value,index,array){
    console.log(`value:${value}`);    
    console.log(`index:${index}`);  
    console.log(`array:${array}`);
});

 //map
 let base = [11,12,15];
 var newArray = base.map(function(value){
   return value *2; 
 }); 
 
 
 console.log(newArray.toString());//22,24,30
 
 //filter
 let data =['javascript',11,13,'jquery'];
 let newArray02 = data.filter(function(value){
    //console.log(value)
    return typeof value =='number';  
 });

 console.log(newArray02.toString());
   
 //Math
 console.log(`Math.PI:${Math.PI}`);
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 




 
 
 
 
 
 
 