/**
 * 
 */
 
 window.onload = function(){
    
  let button = document.getElementById("btnSave");
  console.log(button);
  
  function view(){
    alert('ok');
  }
  
  button.addEventListener("click",view);
 };
 