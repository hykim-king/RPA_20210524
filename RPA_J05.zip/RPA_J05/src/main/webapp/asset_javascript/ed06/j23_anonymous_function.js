/**
 * 익명함수 
 */
 //Uncaught ReferenceError: Cannot access 'compute' before initialization
 //compute();
 let compute = function(){
               console.log('익명함수! '); 
 }
 
 //compute();