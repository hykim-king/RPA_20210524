/**
 * 
 */
 
 let i =0;
 setInterval(function(){
  i++;
  alert('2초마다 실행'+i); 
 },2000);