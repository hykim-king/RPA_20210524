/**
 * 
 */
 
 let browser = navigator.userAgent;
 let browserName = '';
 console.log(browser);
 //console.log(`browser:${browser}`);
 if(browser.match(/Trident/)){
   browserName ='인터넷 익스프러러';
 }else if(browser.match(/Edg/)){
  browserName ='엣지';
 }else if(browser.match(/Chrome/)){
  browserName ='크롬';
 }else if(browser.match(/Firefox/)){
  browserName ='파이어 폭스';
 }else{
  browserName ='알수없는 버전';  
 }
 //
 alert(browserName);    