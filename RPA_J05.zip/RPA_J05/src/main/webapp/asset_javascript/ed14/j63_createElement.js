/**
 * 
 */
 //id로 요소생성 button찾기
 function createFle(){
   let bt = document.getElementById("bt");
   
   function popup(){
     console.log("popup");
     
     //div생성
     let div = document.createElement('div');
     let p   = document.createElement('p');
     let txt = document.createTextNode('자바스크립트');
     
     p.appendChild(txt);//<p>자바스크립트</p>
     div.appendChild(p);
     
     
     document.body.appendChild(div);
   }
   
   bt.onclick = popup;      
 }
 
 addEventListener('load',createFle);