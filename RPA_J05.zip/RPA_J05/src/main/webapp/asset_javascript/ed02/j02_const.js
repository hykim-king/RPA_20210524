//상수 : 한번 값을 할당하면 변하지 않는 것.
//keyword const
//ex)const DIVISION_VALUE = 20;
/*let cm = 200;
let m  = cm / 100;
document.writeln("m="+m);*/

//상수
/*let cm = 200;
const DIVISION_VALUE = 100;
//DIVISION_VALUE = 99; Uncaught TypeError: Assignment to constant variable. 
let m  = cm / DIVISION_VALUE;

document.writeln("m="+m);*/

const DIVISION_VALUE =100;
let cm = prompt('cm를 입려하세요');
let m  = cm / DIVISION_VALUE;
document.writeln(m+" m입니다.");