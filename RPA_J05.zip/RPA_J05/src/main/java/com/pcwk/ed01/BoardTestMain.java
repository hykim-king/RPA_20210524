package com.pcwk.ed01;

import java.util.List;

import org.apache.log4j.Logger;

public class BoardTestMain {
    static final Logger LOG = Logger.getLogger(BoardTestMain.class);
	BoardVO inVO;
	BoardDao dao;
	

	
	public BoardTestMain() {
		inVO=new BoardVO();
		//inVO.setSeq(1);
		inVO.setTitle("게시제목 99_수정");
		inVO.setConstents("내용 99_수정");
		inVO.setReadCnt(0);
		inVO.setRegId("pcwk");		
		
		
		dao = new BoardDao();
	}
	
	public void doMerge() {
		int flag = dao.doMerge(inVO);
		if(flag ==1) {
			LOG.debug("====================");
			LOG.debug("=merge 성공="+flag);
			LOG.debug("====================");
		}
	}
	
	
	public void doDelete() {
		int flag = dao.doDelete(inVO);
	}
	
	public void doInsert() {
		int flag = dao.doInsert(inVO);
		if(flag ==1) {
			LOG.debug("*******************");
			LOG.debug("********등록성공:"+flag);
			LOG.debug("*******************");
		}
	}
	
	public void doSelectOne() {
		BoardVO oneVO = (BoardVO) dao.doSelectOne(inVO);
		if(oneVO.equals(inVO)) {
			LOG.debug("*********************");
			LOG.debug("***조회 성공:");
			LOG.debug("*********************");				
		}
	}

	public void doRetrieve() {
		SearchVO search=new SearchVO();
		search.setPageSize(10);
		search.setPageNum(1);
		search.setSearchDiv("");//전체
		
		List<BoardVO> list = dao.doRetrieve(search);
		for(BoardVO vo :list) {
			LOG.debug(vo);
		}
	}
	
	
	public void doReadCnt() {
		inVO.setSeq(100007);
		
		int flag = dao.doReadCnt(inVO);
		if(flag==1) {
			LOG.debug("*********************");
			LOG.debug("**doReadCnt*:");
			LOG.debug("*********************");				
		}
		
		
	}
	
	public static void main(String[] args) {
		BoardTestMain main=new BoardTestMain();
		//기존 데이터 삭제
		//main.doDelete();
		//데이터 입력
//		main.doMerge();
		
		
//		//기존 데이터 삭제
//		main.doDelete();
//		
//		//데이터 입력
//		main.doInsert();
//		
//		//단건조회
//		main.doSelectOne();  
//		
//		
		//리드 cnt
		main.doReadCnt();
		//목록조회
		main.doRetrieve();
		
	}

}
