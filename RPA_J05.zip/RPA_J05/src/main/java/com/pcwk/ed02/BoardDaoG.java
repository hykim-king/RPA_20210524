package com.pcwk.ed02;

import java.util.List;

public class BoardDaoG implements WorkdDiv<BoardVO> {

	@Override
	public List<BoardVO> doRetrieve(DTO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doUpdate(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BoardVO doSelectOne(BoardVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doDelete(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doInsert(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

}
