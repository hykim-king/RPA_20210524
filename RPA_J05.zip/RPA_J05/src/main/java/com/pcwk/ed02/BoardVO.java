package com.pcwk.ed02;

import java.util.Objects;

public class BoardVO extends DTO{
	//변수 : 카멜케이스
	//ctrl+shift+y : 소문자로 전환
	
	private int seq	            ;//순번       NUMBER
	private String title	    ;//제목       VARCHAR2(1000 BYTE)
	private String constents	;//내용       CLOB
	private int  readCnt	    ;//읽은 회수    NUMBER
	private String regId	    ;//등록자 아이디 VARCHAR2(12 BYTE)
	private String regDt	    ;//등록일      DATE	
	
	
	//생성자
	public BoardVO() {
		
	}


	public BoardVO(int seq, String title, String constents, int readCnt, String regId, String regDt) {
		super();
		this.seq = seq;
		this.title = title;
		this.constents = constents;
		this.readCnt = readCnt;
		this.regId = regId;
		this.regDt = regDt;
	}


	public int getSeq() {
		return seq;
	}


	public void setSeq(int seq) {
		this.seq = seq;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getConstents() {
		return constents;
	}


	public void setConstents(String constents) {
		this.constents = constents;
	}


	public int getReadCnt() {
		return readCnt;
	}


	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}


	public String getRegId() {
		return regId;
	}


	public void setRegId(String regId) {
		this.regId = regId;
	}


	public String getRegDt() {
		return regDt;
	}


	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}


	@Override
	public String toString() {
		return "BoardVO [seq=" + seq + ", title=" + title + ", constents=" + constents + ", readCnt=" + readCnt
				+ ", regId=" + regId + ", regDt=" + regDt + ", toString()=" + super.toString() + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(constents, readCnt, regId, seq, title);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BoardVO other = (BoardVO) obj;
		return Objects.equals(constents, other.constents) && readCnt == other.readCnt
				&& Objects.equals(regId, other.regId) && seq == other.seq && Objects.equals(title, other.title);
	}
	
	
	
	
	
}
