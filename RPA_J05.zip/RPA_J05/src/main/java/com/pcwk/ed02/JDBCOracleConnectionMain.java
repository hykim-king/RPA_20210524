package com.pcwk.ed02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class JDBCOracleConnectionMain  {

	final static String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	//final static String DB_URL = "jdbc:oracle:thin:@192.168.3.100:1521:xe";//URL
	final static String USER_ID= "scott"; //아이디
	final static String USER_PASS= "pcwk";//비번
	
	final static Logger LOG = Logger.getLogger(JDBCOracleConnectionMain.class);
	
	
	/**
	 * 목록 조회
	 * @return
	 */
	
	public List<BoardVO> doRetrieve(SearchVO vo){
		List<BoardVO> list = null;
		SearchVO  inVO = vo;
		
		Connection          con = null;
		PreparedStatement pstmt = null;
		ResultSet  rs           = null;
		
		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결: "+con);
			StringBuilder sbWhere=new StringBuilder(200);
			//제목
			if(inVO.getSearchDiv().equals("10")) {
				sbWhere.append("WHERE a.title LIKE ? ||'%'     \n");
			//내용	
			}else if(inVO.getSearchDiv().equals("20")) {
				sbWhere.append("WHERE a.constents LIKE ? ||'%' \n");
			//등록자ID	
			}else if(inVO.getSearchDiv().equals("30")) {
				sbWhere.append("WHERE a.reg_id LIKE ? ||'%'    \n");
			}
			
			StringBuilder sb=new StringBuilder(300);//main query
			
			sb.append(" SELECT a.seq,                                \n");
		    sb.append("    a.title,                                  \n");
		    sb.append("    a.reg_id,                                 \n");
		    sb.append("    TO_CHAR(a.reg_dt,'YY.MM.DD') reg_dt,      \n");
		    sb.append("    a.read_cnt                                \n");
		    sb.append(" FROM board  a                                \n");
			//--------------------------------------------------------------------------			
			// Where조건
			//--------------------------------------------------------------------------
		    sb.append(sbWhere.toString());
		    sb.append(" ORDER BY a.seq desc                          \n");
		    LOG.debug("2) 쿼리:\n"+sb.toString());
		    LOG.debug("2-1) param:\n"+inVO.toString());
		    
		    pstmt = con.prepareStatement(sb.toString());
		    //? param set
		    if(inVO.getSearchDiv().equals("10")
		    || inVO.getSearchDiv().equals("20")
		    || inVO.getSearchDiv().equals("30")){
		    	pstmt.setString(1, inVO.getSearchWord());
		    }
		    
		    //query수행 결과 
		    rs = pstmt.executeQuery();
		    
		    list = new ArrayList<BoardVO>();
		    while(rs.next()) {
		    	BoardVO outVO=new BoardVO();
		    	outVO.setSeq(rs.getInt("seq"));
		    	outVO.setTitle(rs.getString("title"));
		    	outVO.setReadCnt(rs.getInt("read_cnt"));
		    	outVO.setRegId(rs.getString("reg_id"));
		    	outVO.setRegDt(rs.getString("reg_dt"));
		    	
		    	list.add(outVO);
		    }//--rs while
		    
		    
		    //query수행 결과 출력
		    for(BoardVO rsVO  : list) {
		    	LOG.debug(rsVO.toString());
		    }
		    
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");			
		}finally {
			//ResultSet 자원반납
			JDBCUtil.close(rs);
			
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			
			//Connection 자원반납
			JDBCUtil.close(con);			
		}
		
		
		return list;
	}
	
	/*
	 * UPDATE ( 데이터 변경 하기)
           문법 : UPDATE 테이블
                 SET column   = 변경 value,
	             column02     = 변경 value
	             WHERE 조건 = 조건 VALUE;
	 */
	
	/**
	 * 게시글 수정
	 * @param vo
	 * @return flag(1:성공/1이외는 : 실패)
	 */
	
	public int doUpdate(BoardVO vo) {
		int flag = 0;
		BoardVO inVO  = vo;//param
		
		Connection        con   = null;//db connection객체
		PreparedStatement pstmt = null;//query수행
		try {
			con =  getConnection();
			LOG.debug("1) Connection -DB와 연결 : "+con);
			StringBuilder sb=new StringBuilder(50);
			sb.append(" UPDATE board	        \n");
			sb.append(" SET title     = ?,      \n");
			sb.append("     constents = ?       \n");
			sb.append(" WHERE seq = ?           \n");
			
			LOG.debug("2) 쿼리:\n"+sb.toString());
			LOG.debug("2-1) 파라메터:"+inVO.toString());
			pstmt = con.prepareStatement(sb.toString());
			
			//위아래 순서대로 ? 값 지정
			pstmt.setString(1, inVO.getTitle());//문자로 set
			pstmt.setString(2, inVO.getConstents());
			pstmt.setInt(3, inVO.getSeq());//숫자로 set
			
			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:"+flag);
		}catch(SQLException e) {
			LOG.debug("=SQLException===========================");
			LOG.debug(e.getMessage());
			LOG.debug("=SQLException===========================");
		}finally {
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			//Connection 자원반납
			JDBCUtil.close(con);
		}
		
		
		return flag;
	}
	

	/**
	 * Database Connection 
	 * @return  Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			LOG.debug("ClassNotFoundException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("ClassNotFoundException=====================");
		}
		LOG.debug("1) JDBC Driver loading ");		
		
		con = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("2) Connection -DB와 연결 :"+con);
		return con;
	}
	
	//단건 조회
	
	public BoardVO doSelectOne(BoardVO vo) {
		BoardVO inVO = vo;
		BoardVO outVO = null;
		
		Connection          con = null;
		PreparedStatement pstmt = null;
		
		//데이터 조회
		ResultSet  rs           = null;
		try {
			con  = getConnection();
			LOG.debug("2) Connection -DB와 연결 :"+con);
			StringBuilder sb=new StringBuilder(200);
			sb.append (" SELECT seq,                                              \n");
		    sb.append ("    title,                                                \n");
			sb.append ("    constents,                                            \n");
			sb.append ("    read_cnt,                                             \n");
			sb.append ("    reg_id,                                               \n");
			sb.append ("    TO_CHAR(reg_dt,'YYYY/MM/DD hh24:MI:SS') reg_date      \n");
		    sb.append (" FROM board                                               \n");
		    sb.append (" WHERE seq = ?			                                  \n");
		    LOG.debug("2) 쿼리:\n"+sb.toString());	
		    LOG.debug("2-1) param:\n"+inVO.toString());
		    
		    pstmt = con.prepareStatement(sb.toString());
		    pstmt.setInt(1, inVO.getSeq());
		    
		    rs = pstmt.executeQuery();//결과 return;
		    if(rs.next()) {
		    	outVO = new BoardVO();
		    	
		    	//int seq = rs.getInt("seq");
		    	//outVO.setSeq(seq);
		    	
		    	outVO.setSeq(rs.getInt("seq"));
		    	outVO.setTitle(rs.getString("title"));
		    	outVO.setConstents(rs.getString("constents"));
		    	outVO.setReadCnt(rs.getInt("read_cnt"));
		    	outVO.setRegId(rs.getString("reg_id"));
		    	outVO.setRegDt(rs.getString("reg_date"));
		    }
		    
		    LOG.debug("3) ResultSet:"+outVO.toString());	
			
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");
		}finally {
			//ResultSet 자원반납
			JDBCUtil.close(rs);
			
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			
			//Connection 자원반납
			JDBCUtil.close(con);
			
		}
		
		
		return outVO;
	}
	
	//삭제
	
	public int doDelete(BoardVO vo) {
		int flag = 0;
		BoardVO  inVO = vo;//param 
		
		Connection con           = null;
		PreparedStatement  pstmt = null;
		
		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 :"+con);
			
		    StringBuilder sb=new StringBuilder(50);
		    sb.append(" DELETE FROM board ");
		    sb.append(" WHERE seq = ?     \n");
		    LOG.debug("2) 쿼리:\n"+sb.toString());	
		    LOG.debug("2-1) param:\n"+inVO.toString());
		    
		    pstmt= con.prepareStatement(sb.toString());
		    pstmt.setInt(1, inVO.getSeq());
		    
		    flag = pstmt.executeUpdate();
		    LOG.debug("3) flag:"+flag);
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");			
		}finally {
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			//Connection 자원반납
			JDBCUtil.close(con);
		}
		
		return flag;
	}
	
	/**
	 * 등록
	 * @param vo
	 * @return flag(1:성공/1이외는 : 실패)
	 */
	
	public int doInsert(BoardVO vo) {
		int flag = 0;
		BoardVO inVO = vo;
		//---------------------------------
		/*
		 * 1) JDBC Driver loading - 데이터베이스 벤더에 맞는 디라이버를 호출 - 데이터페이스와의 연결을 위해 드라이버 로딩.
		 * 
		 * 2) Connection -DB와 연결을 위해 URL과 아이디/비번 필요 -연결 메소드
		 * DriverManager.getConnection(url,id,password):Connection
		 * 
		 * 3) Statement/PreparedStatement - SQL구문을 정의하고 변경될 값은 치환문자(?)를 이용해서 쿼리 전송
		 * 
		 * 4) executeUpdate()/executeQuery() - executeUpdate() : SQL Query
		 * insert,update,delete의 경우에 사용. - executeQuery() : SQL Query select문에 사용.
		 * 
		 * 5) ResultSet(Select의 경우 해당) - 데이터베이스 조회 결과 집합에 대한 표준 - next()를 통해 DB Table에
		 * row한 줄을 불러온다. - getString(Column명),getInt(Column명)를 통해 특정 Column값을 가져 온다.
		 */											

		
		Connection        con  = null;
		PreparedStatement pstmt = null;
		
		
		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 "+con);
			
			StringBuilder  sb=new StringBuilder();
			sb.append(" INSERT INTO BOARD (SEQ,TITLE,CONSTENTS,READ_CNT,REG_ID,REG_DT) \n"); 
			sb.append(" VALUES (?,?,?,?,?,sysdate) \n"); 
			
			LOG.debug("2) 쿼리:\n"+sb.toString());
			
		
			LOG.debug("2-1) param:\n"+inVO.toString());
			
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1,inVO.getSeq() );
			pstmt.setString(2, inVO.getTitle());
			pstmt.setString(3, inVO.getConstents());
			pstmt.setInt(4, inVO.getReadCnt());
			pstmt.setString(5, inVO.getRegId());
			
			
			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:"+flag);
			
		} catch (SQLException e) {
			LOG.debug("=SQLException================================");
			LOG.debug(e.getMessage());
			LOG.debug("=================================");		
		}finally {
			//pstmt 자원반납
			JDBCUtil.close(pstmt);
			
			//con 자원반납
			JDBCUtil.close(con);
		}
				
		//---------------------------------
		return flag;
	}
	
	public static void main(String[] args) {
		JDBCOracleConnectionMain main=new JDBCOracleConnectionMain();

		//Param
		BoardVO inVO=new BoardVO();
		inVO.setSeq(1);
		inVO.setTitle("게시제목 2");
		inVO.setConstents("내용 2");
		inVO.setReadCnt(0);
		inVO.setRegId("pcwk");	
		
		//기존 데이터 삭제
		main.doDelete(inVO); 
		
		//데이터 입력
		int insertFlag = main.doInsert(inVO);
		if(insertFlag==1) {
			LOG.debug("*********************");
			LOG.debug("***등록 성공:"+insertFlag);
			LOG.debug("*********************");
		}
		
		//입력 데이터 조회
		BoardVO  oneVO = main.doSelectOne(inVO);
//		if( oneVO.getSeq() == inVO.getSeq() 
//		 &&	oneVO.getTitle().equals(inVO.getTitle())
//		 && oneVO.getConstents().equals(inVO.getConstents())
//		 && oneVO.getReadCnt() == inVO.getReadCnt()
//		 && oneVO.getRegId().equals(inVO.getRegId())
//				) {
//			LOG.debug("*********************");
//			LOG.debug("***조회 성공:");
//			LOG.debug("*********************");			
//			
//		}
        
		if(oneVO.equals(inVO)) {
			LOG.debug("*********************");
			LOG.debug("***조회 성공:");
			LOG.debug("*********************");					
		}
		
		//수정 데이터 생성
		oneVO.setTitle(oneVO.getTitle()+"_U");
		oneVO.setConstents(oneVO.getConstents()+"_U");
		
		int updateFlag = main.doUpdate(oneVO);
		if(updateFlag==1) {
			LOG.debug("*********************");
			LOG.debug("***수정 성공:");
			LOG.debug("*********************");				
		}else {
			LOG.debug("*********************");
			LOG.debug("***수정 실패:");
			LOG.debug("*********************");				
		}
		
		
		
		SearchVO  searchVO=new SearchVO();
		//searchVO.setSearchDiv("");  //전체 조회
		
//		searchVO.setSearchDiv("10");//제목으로 조회
//		searchVO.setSearchWord("기사");
		
		//내용:20
		searchVO.setSearchDiv("20");//제목으로 조회
		searchVO.setSearchWord("내용");
		
		//등록자 ID:30
//		searchVO.setSearchDiv("30");//제목으로 조회
//		searchVO.setSearchWord("pcwk");
		
		//목록 데이터 검색
		main.doRetrieve(searchVO);
		
		
	}

}




