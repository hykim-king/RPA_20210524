package com.pcwk.ed02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

public class BoardDao implements WorkdDiv<BoardVO> {
	final static Logger LOG = Logger.getLogger(BoardDao.class);



	@Override
	public int doUpdate(BoardVO vo) {
		int flag = 0;
		BoardVO inVO  = (BoardVO) vo;//param
		
		Connection        con   = null;//db connection객체
		PreparedStatement pstmt = null;//query수행
		try {
			con =  getConnection();
			LOG.debug("1) Connection -DB와 연결 : "+con);
			StringBuilder sb=new StringBuilder(50);
			sb.append(" UPDATE board	        \n");
			sb.append(" SET title     = ?,      \n");
			sb.append("     constents = ?       \n");
			sb.append(" WHERE seq = ?           \n");
			
			LOG.debug("2) 쿼리:\n"+sb.toString());
			LOG.debug("2-1) 파라메터:"+inVO.toString());
			pstmt = con.prepareStatement(sb.toString());
			
			//위아래 순서대로 ? 값 지정
			pstmt.setString(1, inVO.getTitle());//문자로 set
			pstmt.setString(2, inVO.getConstents());
			pstmt.setInt(3, inVO.getSeq());//숫자로 set
			
			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:"+flag);
		}catch(SQLException e) {
			LOG.debug("=SQLException===========================");
			LOG.debug(e.getMessage());
			LOG.debug("=SQLException===========================");
		}finally {
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			//Connection 자원반납
			JDBCUtil.close(con);
		}
		
		
		return flag;
	}

	@Override
	public BoardVO doSelectOne(BoardVO vo) {
		BoardVO inVO = (BoardVO) vo;
		BoardVO outVO = null;
		
		Connection          con = null;
		PreparedStatement pstmt = null;
		
		//데이터 조회
		ResultSet  rs           = null;
		try {
			con  = getConnection();
			LOG.debug("2) Connection -DB와 연결 :"+con);
			StringBuilder sb=new StringBuilder(200);
			sb.append (" SELECT seq,                                              \n");
		    sb.append ("    title,                                                \n");
			sb.append ("    constents,                                            \n");
			sb.append ("    read_cnt,                                             \n");
			sb.append ("    reg_id,                                               \n");
			sb.append ("    TO_CHAR(reg_dt,'YYYY/MM/DD hh24:MI:SS') reg_date      \n");
		    sb.append (" FROM board                                               \n");
		    sb.append (" WHERE seq = ?			                                  \n");
		    LOG.debug("2) 쿼리:\n"+sb.toString());	
		    LOG.debug("2-1) param:\n"+inVO.toString());
		    
		    pstmt = con.prepareStatement(sb.toString());
		    pstmt.setInt(1, inVO.getSeq());
		    
		    rs = pstmt.executeQuery();//결과 return;
		    if(rs.next()) {
		    	outVO = new BoardVO();
		    	
		    	//int seq = rs.getInt("seq");
		    	//outVO.setSeq(seq);
		    	
		    	outVO.setSeq(rs.getInt("seq"));
		    	outVO.setTitle(rs.getString("title"));
		    	outVO.setConstents(rs.getString("constents"));
		    	outVO.setReadCnt(rs.getInt("read_cnt"));
		    	outVO.setRegId(rs.getString("reg_id"));
		    	outVO.setRegDt(rs.getString("reg_date"));
		    }
		    
		    LOG.debug("3) ResultSet:"+outVO.toString());	
			
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");
		}finally {
			//ResultSet 자원반납
			JDBCUtil.close(rs);
			
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			
			//Connection 자원반납
			JDBCUtil.close(con);
			
		}
		
		
		return outVO;
	}
	

	/**
	 * Database Connection
	 * 
	 * @return Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			LOG.debug("ClassNotFoundException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("ClassNotFoundException=====================");
		}
		LOG.debug("1) JDBC Driver loading ");

		con = DriverManager.getConnection(JDBCUtil.DB_URL, JDBCUtil.USER_ID, JDBCUtil.USER_PASS);
		LOG.debug("2) Connection -DB와 연결 :" + con);
		return con;
	}

	@Override
	public int doDelete(BoardVO vo) {
		int flag = 0;
		BoardVO inVO = (BoardVO) vo;// param

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 :" + con);

			StringBuilder sb = new StringBuilder(50);
			sb.append(" DELETE FROM board ");
			sb.append(" WHERE seq = ?     \n");
			LOG.debug("2) 쿼리:\n" + sb.toString());
			LOG.debug("2-1) param:\n" + inVO.toString());

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, inVO.getSeq());

			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:" + flag);
		} catch (SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");
		} finally {
			// PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			// Connection 자원반납
			JDBCUtil.close(con);
		}

		return flag;
	}



	@Override
	public int doInsert(BoardVO vo) {
		int flag = 0;
		BoardVO inVO = (BoardVO) vo;
		// ---------------------------------
		/*
		 * 1) JDBC Driver loading - 데이터베이스 벤더에 맞는 디라이버를 호출 - 데이터페이스와의 연결을 위해 드라이버 로딩.
		 * 
		 * 2) Connection -DB와 연결을 위해 URL과 아이디/비번 필요 -연결 메소드
		 * DriverManager.getConnection(url,id,password):Connection
		 * 
		 * 3) Statement/PreparedStatement - SQL구문을 정의하고 변경될 값은 치환문자(?)를 이용해서 쿼리 전송
		 * 
		 * 4) executeUpdate()/executeQuery() - executeUpdate() : SQL Query
		 * insert,update,delete의 경우에 사용. - executeQuery() : SQL Query select문에 사용.
		 * 
		 * 5) ResultSet(Select의 경우 해당) - 데이터베이스 조회 결과 집합에 대한 표준 - next()를 통해 DB Table에
		 * row한 줄을 불러온다. - getString(Column명),getInt(Column명)를 통해 특정 Column값을 가져 온다.
		 */

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 " + con);

			StringBuilder sb = new StringBuilder();
			sb.append(" INSERT INTO BOARD (SEQ,TITLE,CONSTENTS,READ_CNT,REG_ID,REG_DT) \n");
			sb.append(" VALUES (?,?,?,?,?,sysdate) \n");

			LOG.debug("2) 쿼리:\n" + sb.toString());

			LOG.debug("2-1) param:\n" + inVO.toString());

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, inVO.getSeq());
			pstmt.setString(2, inVO.getTitle());
			pstmt.setString(3, inVO.getConstents());
			pstmt.setInt(4, inVO.getReadCnt());
			pstmt.setString(5, inVO.getRegId());

			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("=SQLException================================");
			LOG.debug(e.getMessage());
			LOG.debug("=================================");
		} finally {
			// pstmt 자원반납
			JDBCUtil.close(pstmt);

			// con 자원반납
			JDBCUtil.close(con);
		}

		// ---------------------------------
		return flag;
	}

	@Override
	public List<BoardVO> doRetrieve(DTO vo) {
		// TODO Auto-generated method stub
		return null;
	}

}
