package com.pcwk.ed02;

import org.apache.log4j.Logger;

public class BoardTestMain {
    static final Logger LOG = Logger.getLogger(BoardTestMain.class);
	BoardVO inVO;
	BoardDao dao;
	
	public BoardTestMain() {
		inVO=new BoardVO();
		inVO.setSeq(1);
		inVO.setTitle("게시제목 2");
		inVO.setConstents("내용 2");
		inVO.setReadCnt(0);
		inVO.setRegId("pcwk");		
		
		
		dao = new BoardDao();
	}
	
	
	public void doDelete() {
		int flag = dao.doDelete(inVO);
	}
	
	public void doInsert() {
		int flag = dao.doInsert(inVO);
		if(flag ==1) {
			LOG.debug("*******************");
			LOG.debug("********등록성공:"+flag);
			LOG.debug("*******************");
		}
	}
	
	public void doSelectOne() {
		BoardVO oneVO = (BoardVO) dao.doSelectOne(inVO);
		if(oneVO.equals(inVO)) {
			LOG.debug("*********************");
			LOG.debug("***조회 성공:");
			LOG.debug("*********************");				
		}
	}
	
	public static void main(String[] args) {
		BoardTestMain main=new BoardTestMain();
		
		//기존 데이터 삭제
		main.doDelete();
		
		//데이터 입력
		main.doInsert();
		
		//단건조회
		main.doSelectOne();
		
	}

}
