package com.pcwk.ed02;
/**
 * 모든 VO에 Parent
 * @author HKEDU
 *
 */
public class DTO {

}
