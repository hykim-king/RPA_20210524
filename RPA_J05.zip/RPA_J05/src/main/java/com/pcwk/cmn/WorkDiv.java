package com.pcwk.cmn;

import java.util.List;

import com.pcwk.ed01.DTO;

public interface WorkDiv<T> {
	

	/**
	 * 목록 조회
	 * @return
	 */
	List<T> doRetrieve(DTO vo);

	/**
	 * 게시글 수정
	 * @param vo
	 * @return flag(1:성공/1이외는 : 실패)
	 */
	int doUpdate(T vo);


	/**
	 * 단건 조회
	 * @param vo
	 * @return
	 */
	T doSelectOne(T vo);


	/**
	 * 삭제
	 * @param vo
	 * @return
	 */
	int doDelete(T vo);

	/**
	 * 등록
	 * @param vo
	 * @return flag(1:성공/1이외는 : 실패)
	 */
	int doInsert(T vo);

}