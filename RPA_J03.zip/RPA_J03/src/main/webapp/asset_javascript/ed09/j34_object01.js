/**
 * 객체 리터럴                                   
  let 변수 = { 프로퍼티:값, 프로퍼티:값, 메서드: function() {} ,….}                                  
 */
 
 
 let info = {
    subject: 'javascript',
    credit: 1,
    printOut: function(){
      return  info.subject+","+info.credit +" 학점";
    }
 };
 
 
 console.log(`info.subject:${info.subject}`);//info.subject:javascript
 console.log(`info.credit:${info.credit}`);//info.credit:1
 console.log(`info.printOut:${info.printOut()}`);//info.printOut:javascript,1 학점
 
 //객체 리터럴의 속성 추가, 삭제 변경  
 //속성 추가               
 info.days = 20;
 console.log(`info.days:${info.days}`);//info.days:20
 
 //속성 삭제.
 delete info.credit;
 console.log(`info.credit:${info.credit}`);//info.credit:undefined

 info.printOut = function(){
     return this.subject +","+this.days+"일";
 };
 //info.printOut:javascript,20일
 console.log(`info.printOut:${info.printOut()}`);
 
 
 let subjectName = Symbol();
 
 let info02 = {
  [subjectName] : "자바스크립트",
  subjectName : "제이쿼리"
 }
 
 console.log(`info02.subjectName:${info02.subjectName}`);
 console.log(`info02.[subjectName]:${info02[subjectName]}`);
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 