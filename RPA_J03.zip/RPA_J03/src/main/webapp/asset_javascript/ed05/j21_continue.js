/**
 * 1 ~ 10까지 홀수만 더하기 
 */
 
 let sum = 0;
 
 for(let i=1;i<=10;i++){
  
    if(i%2==0){ //짝수 이면 continue;
      continue; 
    } 
  
  
   sum+=i;
 }
 
 console.log(`sum:${sum}`);