/**
 * 제어문 : if문
 */
 
 let age = 10;//나이
 
 let admissionFee = "";
 
 if(age < 13){
   admissionFee = "2,000원";
 }
 
 console.log(`age:${age}, 입장료:${admissionFee}`);
 