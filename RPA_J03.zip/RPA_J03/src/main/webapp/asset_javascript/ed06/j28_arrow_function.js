/**
 * 화살표 함수(Arrow function)                                         
  ECMAScript 2015(ES6)에 추가된 내용 =>를 이용해서 함수를 간결하게 표현.                                        
  항상 익명 함수 형식으로 표현.                                       
  단일 명령어의 경우 함수 중괄호{}와 return을 생략가능.                                        
 */
 
 const doAdd = (s1,s2)=>s1+s2;
 
 console.log(doAdd(11,13));//24
 
 const doMutip = (s1,s2)=>{
    let result = s1 * s2;
    return result;
 };
 
 
 console.log(doMutip(10,12));//120