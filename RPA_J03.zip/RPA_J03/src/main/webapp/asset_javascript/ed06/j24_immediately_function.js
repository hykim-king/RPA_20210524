/**
 * 즉시 실행 함수(Immediately-invoked function)                                     
   선언과 동시에 함수가 실행되며 함수명이 없기 때문에 재호출 않됨.                                   
 */
 
 (function(){
    immediate();
  }
 )();
 
 
 function immediate(){
   console.log("즉시 실행 함수1.");
 }
 
 let instant = ( function(){
                    console.log("즉시 실행 함수2");
                 }
 )();
 
 /*
 즉시 실행 함수1.
 즉시 실행 함수2
 */