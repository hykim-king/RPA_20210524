/**
 * 
 */
 //toFixed(n)일 때 n값만큼 소수점 자릿수를 만들어 줍니다.
 let num = new Number(328.575);
 console.log(`num.toFixed():${num.toFixed()}`);
 console.log(`num.toFixed(1):${num.toFixed(1)}`);
 console.log(`num.toFixed(1):${num.toFixed(2)}`);
 
 //toString(n)일 때의 n값의 진수로 변환
 num = 12;
 console.log(num.toString(2));//1100
 console.log(num.toString(16));//c