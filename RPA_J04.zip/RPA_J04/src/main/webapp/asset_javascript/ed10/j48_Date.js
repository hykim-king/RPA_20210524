/**
 * 
 */
 
 let dateObj = new Date();
// let dateObj = new Date(2021,5,12,14,20,2,500);
  
 let dateInfo= {
      year : dateObj.getFullYear(), //년 4자리
      month: dateObj.getMonth()+1, //month+1 :1월달이 0
      day  : dateObj.getDate(),    //일
      hours: dateObj.getHours(),   //시간
      minutes: dateObj.getMinutes(),//분
      second:  dateObj.getSeconds(),//초
      milisecond: dateObj.getMilliseconds(),
      nowDate : dateObj.toUTCString()
};


for(let i in dateInfo){
    console.log(i+':'+dateInfo[i]);
}
console.clear();
//from날짜 - to날짜
let toDay = new Date(2021,7,12);
let afterDay = new Date(2021,9,16);
//1970.1.1. 부터 현째 까지 경과한 시간을 밀리초로 돌려 준다.
let diffDay  = afterDay.getTime() - toDay.getTime();
console.log(`diffDay:${diffDay}`);
let willDay = Math.ceil(diffDay/(1000*60*60*24));  

console.log(`willDay;${willDay}`);  












