/**
 * break;
 
 * 1 ~ 10사이 출력하고 8보다 크면 되면 반복문을 벗어 나세요.
 */
 
 for(let i=1;i<=10;i++){
  
    if(i>8){
      break;
    }
    
    console.log(`i:${i}`); 
 }
 
 //console.log(`i:${i}`); 