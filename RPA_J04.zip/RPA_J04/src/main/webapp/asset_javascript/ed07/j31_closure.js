/**
 * 
 */
//일반함수의 지역 변수
/*
function add(){
  
  var n = 0;
  return ++n;
  
}  

console.log(add());//1
console.log(add());//1
*/

//closure: 익명함수를 return
//호출하면 지역변수값을 유지 할수 있음.
function add(){
  var n = 0;
  
  return function(){
    return ++n;
  }
  
}

var increase = add();
console.log(increase());
console.log(increase());

//익명함수 return 확인
/*  
  ƒ (){
    return ++n;
  }
*/  
//console.log(add());

