/**
 * 비교연산자
 */
 console.log(5>2);//true
 console.log(5<2);//false
 console.log(5===5);//true
 console.log(5==='5');//false
 console.log(5 !='5');//false
 console.log(5!=='5');//true