/**
 * table을 문자열 연산 +=를 이용한 문자열 연결
 */
 
 let table = "<table>";
 table += "<tr>";
 table += "<td>자바스크립트</td>";
 table += "<td>제이쿼리</td>";
 table += "</tr>";
 table += "</table>";
 
 document.write(table);
 