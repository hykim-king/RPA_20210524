/**
 * class 접근 지정자: public, private
 */
/* 
class JExperiment{
   name = 'james'; //public 
   #age =  2;    ; //private
 };
  
 const  jExperiment = new JExperiment();
 console.log(`jExperiment.name: ${jExperiment.name}`);//jExperiment.name: james
 console.log(`jExperiment.age: ${jExperiment.age}`);//jExperiment.age: undefined
 */
 