//1.3 undefined 
// -> undefined는 변수는 선언 하였으나 데이터 값을 지정하지 않은 경우나,
// -> 객체의 속성 값을 지정하지 않았을 경우 자동으로 저장.

let temp01 = 10;
let temp;

console.log(`temp01:${temp01},type:${typeof temp01}`);
console.log(`temp:${temp}, type:${typeof temp}`);

let obj = {};
obj.name = "이상무";
obj.age;

console.log(`obj.name:${obj.name}`);
console.log(`obj.age:${obj.age}`);

console.clear();
//1.4. null
//-> undefined와 유사하지만 변수를 빈(empty) 상태로 만들거나,
//->데이터를 저장하였으나 값이 존재하지 않을 때 null 값을 반환
let obj01 = 10;
obj01 = null;

console.log(`obj01:${obj01}`);//변수를 empty상태로 처리

// undefined와 null의 boolean은 false
let obj10; //undefined
let obj20 = null; //null
console.log(`obj10:${Boolean(obj10)}`);
console.log(`obj20:${Boolean(obj20)}`);
/*Console was cleared
j04_datatype02.js:25 obj01:null
j04_datatype02.js:30 obj10:false
j04_datatype02.js:31 obj20:false*/

//1.5 typeof
//-> 변수에 저장되어 있는 데이터의 타입을 check
let num100 = 100;
let str100 ='문자';
console.log(`num100:${num100}, type:${typeof num100}`);
console.log(`str100;${str100}, type:${typeof str100}`);

console.clear();
//* number의 infinity, negativeInfinity, not a number

const infinity = 1 / 0;//Infinity
const negativeInfinity = -1/0;//-Infinity
const nAn = "not a num" / 2;//NaN

console.log(`infinity:${infinity}`);
console.log(`negativeInfinity:${negativeInfinity}`);
console.log(`nAn:${nAn}`);

//symbol은 객체에 대해 unique한 값이 필요할떄 사용
const gSymbol01 = Symbol.for('id01');
const gSymbol02 = Symbol.for('id02');
console.log(gSymbol01===gSymbol02);//false
console.log(`gSymbol01:${gSymbol01.toString}, type:${typeof gSymbol01}`);

console.clear();

// Dynamic type;
let text = 'pcwk';
console.log(`text:${text},type:${typeof text}`);//text:pcwk,type:string


text = 1;
console.log(`text:${text},type:${typeof text}`);//text:1,type:number
  
text = '1' + 5;
console.log(`text:${text},type:${typeof text}`);//text:15,type:string

text = '1' / '5';
console.log(`text:${text},type:${typeof text}`);//text:0.2,type:number


































