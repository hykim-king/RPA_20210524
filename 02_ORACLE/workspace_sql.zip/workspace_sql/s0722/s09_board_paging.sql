--board paging
--1~10 -> 
--11~20
--21~30

--oracle paging
SELECT TT1.* 
FROM(
    SELECT rownum rnum,T1.*
    FROM(
        --�ֽűۿ� ù��° ���̵��� ó��
        SELECT *
        FROM board 
        ORDER BY seq DESC
    )t1
)tt1
 WHERE rnum BETWEEN 1 AND 10   
;


--page_sizeó�� :
--page_size=10,page_no=1
SELECT tt1.rnum num,
       tt1.title,
       tt1.reg_id,
       CASE WHEN TO_CHAR(SYSDATE,'YYYY/MM/DD')=TO_CHAR(tt1.reg_dt,'YYYY/MM/DD') THEN TO_CHAR(tt1.reg_dt,'HH24:MI')
            ELSE TO_CHAR(tt1.reg_dt,'YYYY/MM/DD')
       END REG_DT02,
       tt1.read_cnt
FROM(
    SELECT rownum rnum,T1.*
    FROM(
        --�ֽűۿ� ù��° ���̵��� ó��
        SELECT *
        FROM board 
        --�˻�����
        ORDER BY seq DESC
    )t1
)tt1
-- WHERE rnum BETWEEN 1 AND 10   
WHERE rnum BETWEEN :page_size * (:page_num-1)+1 AND :page_size * (:page_num-1)+:page_size   
;
 --WHERE rnum BETWEEN 1 AND 10
 --1,11,21,31,... : :page_size * (:page_num-1)+1
 --10,20,30,40,...: :page_size * (:page_num-1)+:page_size


--�ӵ� ISSUE�� ������ �Ʒ� ���·� ���
SELECT TT1.* 
FROM(
    SELECT rownum rnum,T1.*
    FROM(
        --�ֽűۿ� ù��° ���̵��� ó��
        SELECT *
        FROM board 
        ORDER BY seq DESC
    )t1
    WHERE ROWNUM <=10
)tt1
WHERE ROWNUM >=1