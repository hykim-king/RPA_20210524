--board ���̺� mergeó��: update/insert

--merge : key������ Update, ������ Insert
--MERGE INTO TABLE_01(TARGET)
--USING TABLE_02
--ON (��������)
--WHEN MATCHED THEN 
--UPDATE SET ������Ʈ ����
--WHEN NOT MATCHED THEN 
--INSERT () VALUES ()

--
SELECT 
    :seq   seq,
    :title title,
    :constents constents,
    :reg_id reg_id
FROM dual t2;

MERGE INTO board t1
USING (
    SELECT 
        :seq   seq,
        :title title,
        :constents constents,
        :reg_id reg_id
    FROM dual t2
)t2
ON (t1.seq = t2.seq)
WHEN MATCHED THEN
    UPDATE SET t1.title = t2.title,
               t1.constents = t2.constents,
               t1.reg_id = t2.reg_id
WHEN NOT MATCHED THEN
    INSERT (t1.seq,t1.title,t1.constents,t1.reg_id) VALUES (t2.seq,t2.title,t2.constents,t2.reg_id);
    
--100001,'����_100001_U','����_100001_U','a few goodman'    
    
SELECT * FROM BOARD
WHERE  SEQ = 100001;








