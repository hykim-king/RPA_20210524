--���� �� �Է��ϱ�						
CREATE TABLE t_minus (
    no1 NUMBER,
    no2 NUMBER(3),
    no3 NUMBER(3,2)
);

--��� �Է�
INSERT INTO t_minus (
    no1,
    no2,
    no3
) VALUES (
    1,
    1,
    1
);

--�Ҽ��� �Է�
INSERT INTO t_minus (
    no1,
    no2,
    no3
) VALUES (
    1.1,
    1.1,
    1.1
);

SELECT *
FROM t_minus;

--minus�Է�
INSERT INTO t_minus (
    no1,
    no2,
    no3
) VALUES (
    -1.1,
    -1.1,
    -1.1
);

SELECT *
FROM t_minus;






