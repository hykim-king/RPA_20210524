sb.append(" MERGE INTO board t1                                                                                    \n");
sb.append(" USING (                                                                                                \n");
sb.append("     SELECT                                                                                             \n");
sb.append("         ? seq,                                                                                         \n");
sb.append("         ? title,                                                                                       \n");
sb.append("         ? constents,                                                                                   \n");
sb.append("         ? reg_id                                                                                       \n");
sb.append("     FROM dual t2                                                                                       \n");
sb.append(" )t2                                                                                                    \n");
sb.append(" ON (t1.seq = t2.seq)                                                                                   \n");
sb.append(" WHEN MATCHED THEN                                                                                      \n");
sb.append("     UPDATE SET t1.title = t2.title,                                                                    \n");
sb.append("                t1.constents = t2.constents,                                                            \n");
sb.append("                t1.reg_id = t2.reg_id                                                                   \n");
sb.append(" WHEN NOT MATCHED THEN                                                                                  \n");
sb.append("     INSERT (t1.seq,t1.title,t1.constents,t1.reg_id) VALUES (t2.seq,t2.title,t2.constents,t2.reg_id)    \n");
	
	