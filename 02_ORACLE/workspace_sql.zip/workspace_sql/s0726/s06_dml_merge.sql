--MERGE: ����
CREATE TABLE charge_01 (
  u_date VARCHAR2(6),
  cust_no NUMBER,
  u_time NUMBER,
  charge NUMBER
);

CREATE TABLE charge_02 
AS
SELECT *
FROM charge_01
WHERE 1=2;


INSERT INTO charge_01 VALUES ('141001',	1000,	2,	1000);	
INSERT INTO charge_01 VALUES ('141001',	1001,	2,	1000);	
INSERT INTO charge_01 VALUES ('141001',	1002,	1,	500	);


INSERT INTO charge_02 VALUES ('141002',	1000,	3,	1500 );	
INSERT INTO charge_02 VALUES ('141002',	1001,	4,	2000 );	
INSERT INTO charge_02 VALUES ('141002',	1003,	1,	500	 );

COMMIT;

SELECT * FROM charge_01
UNION ALL 
SELECT * FROM charge_02;

--ch_total ���̺� ����.
CREATE TABLE ch_total
AS
SELECT *
FROM charge_01
WHERE 1=2;

--charge_01,ch_total merge
MERGE INTO ch_total t1
USING charge_01 t2
ON(t1.u_date = t2.u_date)
WHEN MATCHED THEN
 UPDATE SET t1.cust_no = t2.cust_no
WHEN NOT MATCHED THEN
 INSERT VALUES (t2.u_date,t2.cust_no,t2.u_time,t2.charge);


SELECT * FROM ch_total;

--charge_02,ch_total merge
--PK�� ON���� ���
MERGE INTO ch_total t1
USing charge_02 t2
ON (t1.u_date = t2.u_date)
WHEN MATCHED THEN
    UPDATE SET t1.cust_no = t2.cust_no
WHEN NOT MATCHED THEN
    INSERT VALUES (t2.u_date,t2.cust_no,t2.u_time,t2.charge);

commit;

--������ Ȯ��
SELECT * FROM ch_total;



