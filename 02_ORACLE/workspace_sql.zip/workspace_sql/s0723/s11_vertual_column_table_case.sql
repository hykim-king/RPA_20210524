--case���� �̿��� ���� �÷� ����
CREATE TABLE sales10(
    no NUMBER,
    pcode CHAR(4),
    pdate CHAR(8),
    pqty  NUMBER,
    pbungi NUMBER(1)
    GENERATED ALWAYS AS
    (
      CASE WHEN SUBSTR(PDATE,5,2) IN ('01','02','03') THEN 1
           WHEN SUBSTR(PDATE,5,2) IN ('04','05','06') THEN 2
           WHEN SUBSTR(PDATE,5,2) IN ('07','08','09') THEN 3
           ELSE 4
      END     
    )
);
INSERT INTO sales10 ( no,pcode,pdate,pqty) values (1,'100','20210723',10);
INSERT INTO sales10 ( no,pcode,pdate,pqty) values (2,'100','20211023',10);
SELECT * FROM sales10;