--�÷��� ������ ũ�� ����. : MODIFY
DESC dept7;

--�̸�       ��?       ����           
---------- -------- ------------ 
--DCODE             VARCHAR2(6)  
--DNAME    NOT NULL VARCHAR2(30) 
--PDEPT             VARCHAR2(6)  
--AREA              VARCHAR2(30) 
--LOCATION          VARCHAR2(10) 
--LOC               VARCHAR2(10) 

--LOC               VARCHAR2(10) ->  VARCHAR2(20)
ALTER TABLE dept7
MODIFY ( loc VARCHAR2(20));

DESC dept7;
--�̸�       ��?       ����           
---------- -------- ------------ 
--DCODE             VARCHAR2(6)  
--DNAME    NOT NULL VARCHAR2(30) 
--PDEPT             VARCHAR2(6)  
--AREA              VARCHAR2(30) 
--LOCATION          VARCHAR2(10) 
--LOC               VARCHAR2(20) 