--ORACLE���� ��ȹ
--PLAN TABLE����: SCRIPT�� ����!
--set autotrace on
--set autotrace on explain
--set autotrace traceonly explain
set autotrace traceonly statistics
explain plan for

--PLANG SQL
SELECT *
FROM emp

col plan_table_output format a80;
select * from table(dbms_xplan.display);

--17:06:36 SCOTT>@S29_GROUP_WINDOW_ROLLUP_PLAN.sql
--
--PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------
--Plan hash value: 3956160932
--
----------------------------------------------------------------------------
--| Id  | Operation         | Name | Rows  | Bytes | Cost (%CPU)| Time     |
----------------------------------------------------------------------------
--|   0 | SELECT STATEMENT  |      |    12 |   468 |     3   (0)| 00:00:01 |
--|   1 |  TABLE ACCESS FULL| EMP  |    12 |   468 |     3   (0)| 00:00:01 |
----------------------------------------------------------------------------
--
--8 ���� ���õǾ����ϴ�.