--REGEXP_COUNT (source_char, pattern [, position [, match_param]])
----REGEXP_COUNT(11G): 정규식을 검색하여 발견된 횟수
col "REGEXP_COUNT" for 999
SELECT text,
       REGEXP_COUNT(text,'A') "REGEXP_COUNT"
FROM t_reg
;
