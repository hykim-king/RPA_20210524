--HAVING 절을 사용해서 그룹핑한 조건으로 검색.
--SELECT deptno
--      ,AVG(NVL(sal,0))
--FROM emp
--WHERE AVG(NVL(sal,0)) > 2000
--GROUP BY deptno
--ORDER BY 1
--;
--4행에 오류:
--ORA-00934: 그룹 함수는 허가되지 않습니다

SELECT deptno
      ,AVG(NVL(sal,0))
FROM emp
GROUP BY deptno
HAVING AVG(NVL(sal,0)) > 2000
ORDER BY 1
;
--    DEPTNO AVG(NVL(SAL,0))
------------ ---------------
--        10      2916.66667
--        20      2258.33333