--지정된 POSIX문자 클래스에 속한 임의의 문자와 일치

--POSIX문자 클래스 내용
--[:alnum:] 알파벳과 숫자 [A-Za-z0-9]
--[:alpha:] 알파벳 [A-Za-z]
--[:cntrl:] 제어 문자
--[:blank:] 탭과 공백 문자
--[:digit:] 숫자 [0-9]
--[:graph:] 제어문자와 공백 무자를 제외한 문자
--[:lower:] 소문자 [a-z]
--[:upper:] 대문자 [A-Z]
--[:print:] 제어문자를 제외한 문자, 즉 프린터 할 수 있는 문자
--[:punct:] [:graph:]문자 중 [:alnum:]을 제외한 문자. ex)!,@,#,$,%,^....
--[:space:] 화이트스페이스 ex)공백, 탭, 케리지 리턴, 새행, 수직탭, 폼필드
--[:xdigit:] 16진수

--[]:해당 문자에 해당하는 한 문자
--[:space:] 화이트스페이스 ex)공백, 탭, 케리지 리턴, 새행, 수직탭, 폼필드
SELECT *
FROM t_reg
WHERE REGEXP_LIKE(text,'[[:space:]]')
;