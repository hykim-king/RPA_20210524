--AVG:입력 데이터의 평균
--평균(mean)
--평균은 단순히 모든 관측값을 더해서 관측값 개수로 나눈 것이다.

--전체 인원에 대한 comm 평균 
SELECT AVG(comm)
      ,COUNT(comm)
	  ,COUNT(*)
	  ,SUM(comm)
	  ,ROUND(AVG(NVL(comm,0)),2) "AVG_ROUND_2"
	  ,SUM(comm)/COUNT(*)
FROM emp
;
-- AVG(COMM) COUNT(COMM)   COUNT(*)  SUM(COMM) AVG_ROUND_2 SUM(COMM)/COUNT(*)
------------ ----------- ---------- ---------- ----------- ------------------
--       550           4         12       2200      183.33         183.333333