--REGEXP_REPLACE: 정규식을 검색하여 대체 문자열로 변경
--replace함수를 확장한 개념, 주어진 문자열을 특정 패턴을 찾아서 다른 모양으로 치환
--char,varchar2,nchar,nvarchar2,clog,nclog

--REGEXP_REPLACE(source_컬럼,pattern,replace_string
--             ,position(default 1)
--			   ,occurrence -> 0 모든값
--			   ,match_pattern->c:대소문자구분,i:대소문자 구분하지 않음,m:검색조건을 여러줄로)
--숫자를 찾아서 '*'로 치환
COL "REGEXP_REPLACE" FOR a15
SELECT text
     ,REGEXP_REPLACE(text,'[0-9]','*') "REGEXP_REPLACE"
FROM t_reg;
--TEXT                 REGEXP_REPLACE
---------------------- ---------------
--ABC123               ABC***
--ABC 123              ABC ***
--ABC  123             ABC  ***
--abc 123              abc ***
--abc  123             abc  ***
--a1b2c3               a*b*c*
--aabbcc123            aabbcc***
--?/!@#$*&             ?/!@#$*&
--\~*().,              \~*().,
--123123               ******
--123abc               ***abc
--abc                  abc
--
--12 행이 선택되었습니다.