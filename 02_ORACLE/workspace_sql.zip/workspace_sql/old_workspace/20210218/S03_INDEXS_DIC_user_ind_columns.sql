--�ε��� �����ϱ�: DICTIONARY												
												
--	user:user_indexes,user_ind_columns									
--	DBA:dba_indexes,dba_ind_columns								
DESC user_indexes;
DESC user_ind_columns;

SELECT t1.table_name,
       t1.column_name,
       t1.index_name
FROM user_ind_columns t1
WHERE t1.table_name = 'EMP2';

--table_name column_name index_name
---------- ----------- -----------
--EMP2	   NAME	       EMP2_NAME99_UK
--EMP2	   EMPNO	   SYS_C007396