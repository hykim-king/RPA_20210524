--BIT MAP Index																			
--																			
--	OLAP에서 많이 사용.																		
--	B-TREE는 값의 종류가 많고(다양)하고 동일한(중복) 데이터가 적을 경우.																		
--																			
--	BIT MAP은 데이터 값의 종류가 적고, 동일한 데이터가 많을 경우																		
--	EX) 사원데이블에 성별 컬럼의 값이 2종류 뿐인 경우 BIT MAP사용																		
--																			
--문법																			
--	CREATE BITMAP INDEX 인덱명																		
--	ON	테이블명 (  컬럼명 ASC|DESC,컬럼명 ASC|DESC)																	
--																			
--	데이터가 병경이 안 되는 데이블과 값의 종류가 작은 컬럼에 생성하는 것이 유리																		

--emp JOB BITMAP 인덱스 생성
CREATE BITMAP INDEX idx_emp_job
ON emp ( job );