--1.new_emp4 테이블 생성
--CREATE TABLE new_emp4(
--	no NUMBER,
--	name VARCHAR2(20),
--	sal NUMBER
--);
--테이블이 생성되었습니다.
--2.data 입력
--INSERT INTO new_emp4 VALUES(1000,'SMITH' , 	300);	
--INSERT INTO new_emp4 VALUES(1001,'ALLEN',	250);
--INSERT INTO new_emp4 VALUES(1002,'KING'	,	430);	
--INSERT INTO new_emp4 VALUES(1003,'BLAKE',	220);
--INSERT INTO new_emp4 VALUES(1004,'JAMES',	620);
--INSERT INTO new_emp4 VALUES(1005,'MILLER',	810);
--COMMIT;


--SELECT *
--FROM new_emp4;

--        NO NAME                                            SAL
------------ ---------------------------------------- ----------
--      1000 SMITH                                           300
--      1001 ALLEN                                           250
--      1002 KING                                            430
--      1003 BLAKE                                           220
--      1004 JAMES                                           620
--      1005 MILLER                                          810
--
--6 행이 선택되었습니다.

--3.name 컬럼에 인덱스 생성
--CREATE INDEX IDX_EMP4_NAME
--ON new_emp4 ( name ASC );

--4.인덱스 사용 vs 미사용
--인덱스 미사용
--SELECT *
--FROM new_emp4;
--
--10:34:12 SCOTT>@S06_INDEX_USE.sql
--
--        NO NAME                                            SAL
------------ ---------------------------------------- ----------
--      1000 SMITH                                           300
--      1001 ALLEN                                           250
--      1002 KING                                            430
--      1003 BLAKE                                           220
--      1004 JAMES                                           620
--      1005 MILLER                                          810

--인덱스 사용
--SELECT *
--FROM new_emp4
--WHERE name > '0'  --NAME 컬럼에 있는 인덱스를 사용하라.
--;
--ORDER BY 없이 NAME 컬럼이 정렬됨.
--        NO NAME                                            SAL
------------ ---------------------------------------- ----------
--      1001 ALLEN                                           250
--      1003 BLAKE                                           220
--      1004 JAMES                                           620
--      1002 KING                                            430
--      1005 MILLER                                          810
--      1000 SMITH                                           300


--4.1 실행계획
--인덱스 미사용

--explain plan for

--SELECT *
--FROM new_emp4;

--col plan_table_output format a80;
--select * from table(dbms_xplan.display);

--PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------
--Plan hash value: 574968521
--
--------------------------------------------------------------------------------
--| Id  | Operation         | Name     | Rows  | Bytes | Cost (%CPU)| Time     |
--------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT  |          |     6 |   228 |     3   (0)| 00:00:01 |
--|   1 |  TABLE ACCESS FULL| NEW_EMP4 |     6 |   228 |     3   (0)| 00:00:01 |
--------------------------------------------------------------------------------

--인덱스 사용
--explain plan for
--SELECT *
--FROM new_emp4
--WHERE name > '0'
--;
--col plan_table_output format a120;
--select * from table(dbms_xplan.display);
--PLAN_TABLE_OUTPUT
------------------------------------------------------------------------------------------------------
--Plan hash value: 1925948565
--
------------------------------------------------------------------------------------------------------
--| Id  | Operation                           | Name          | Rows  | Bytes | Cost (%CPU)| Time|
------------------------------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT                    |               |     6 |   228 |     2   (0)| 00:00:01
--|   1 |  TABLE ACCESS BY INDEX ROWID BATCHED| NEW_EMP4      |     6 |   228 |     2   (0)| 00:00:01
--|*  2 |   INDEX RANGE SCAN                  | IDX_EMP4_NAME |     6 |       |     1   (0)| 00:00:01
------------------------------------------------------------------------------------------------------

--5.최소 최대를 MIN/MAX를 인덱스 사용해서 대처.

--SELECT MIN(name),MAX(name)
--FROM new_emp4;
--
--MIN(NAME)  MAX(NAME)
------------ ---------
--ALLEN      SMITH

--인덱스를 통한 MIN
--SELECT name
--FROM new_emp4
--WHERE name > '0'
--AND ROWNUM =1;


--NAME
----------------
--ALLEN

--인덱스 HINT를 통한 MAX
--SELECT /*+ INDEX_DESC(테이블명 인덱스명)  */
--         컬럼
--FROM new_emp4


--이방법을 권장.
--SELECT /*+ INDEX_DESC(t1 idx_emp4_name) */
--       MAX(name)
--FROM new_emp4 t1
--WHERE name > '0'
--AND ROWNUM =1;


--NAME
-------------------
--SMITH





--인덱스 사용 유무 확인

--		-모니터링 시작 하기							
ALTER INDEX IDX_EMP4_NAME MONITORING USAGE;	


--인덱스 사용
SELECT *
FROM new_emp4
WHERE name > '0'
;


--인덱스 사용 유무 확인
SELECT index_name,
       used
FROM v$object_usage


--INDEX_NAME           USED
---------------------- --------------------
--EMP2_NAME99_UK       NO
--IDX_EMP4_NAME        YES

--NOMONITORING 이후에도 기존 모니터링 정보는 남아 있음.
ALTER INDEX IDX_EMP4_NAME NOMONITORING USAGE;	












