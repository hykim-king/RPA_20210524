--INDEX REBUILD
--1. I_TEST 테이블 생성
--CREATE TABLE i_test(
--	NO NUMBER,
--	NAME VARCHAR2(20)
--);

--2. 데이터 10000건 입력
--BEGIN
--		FOR i IN 1..10000 LOOP
--			INSERT INTO i_test VALUES( i,'eStudent'||i);
--		END LOOP;
--		COMMIT;
--END;
--/

--2.1. 건수 확인
--SELECT COUNT(*)
--FROM i_test;


--3. 인덱스: NO 컬럼에 인덱스 생성
--CREATE INDEX idx_test_no
--ON i_test ( no DESC);

--4. 인덱스 상태 조회: 삭제전 인덱스 상태 조회
--STATIC DICTIONARY 조회 하므로 통계정보를 갱신
--ANALYZE INDEX IDX_TEST_NO VALIDATE STRUCTURE;

--DESC index_stats;
--
--lf_rows_len: 입력 데이터
--
--del_lf_rows_len: 삭제 데이터 

--SELECT   lf_rows_len,
--         del_lf_rows_len,
--		 (del_lf_rows_len/lf_rows_len)*100 balance
--FROM index_stats
--WHERE name = 'IDX_TEST_NO';

--BALANCE는 0에 가까울 수록 우수.
--LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
------------- --------------- ----------
--     159801               0          0


--5. 테이블에서 데이터 삭제
--SELECT *
--FROM i_test
--WHERE NO BETWEEN 1 AND 4000;


--DELETE FROM i_test
--WHERE NO BETWEEN 1 AND 4000;
--
--COMMIT;
--6. 인덱스 상태 조회

--STATIC DICTIONARY 조회 하므로 통계정보를 갱신
--ANALYZE INDEX IDX_TEST_NO VALIDATE STRUCTURE;
--SELECT   lf_rows_len,
--         del_lf_rows_len,
--		 (del_lf_rows_len/lf_rows_len)*100 balance
--FROM index_stats
--WHERE name = 'IDX_TEST_NO';
--
----BALANCE로 39.9628288 깨짐
--LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
------------- --------------- ----------
--     159801           63861 39.9628288

--7. 인덱스 REBUILD
--ALTER INDEX IDX_TEST_NO REBUILD;



--8. 인덱스 상태 조회
--STATIC DICTIONARY 조회 하므로 통계정보를 갱신
ANALYZE INDEX IDX_TEST_NO VALIDATE STRUCTURE;

SELECT   lf_rows_len,
         del_lf_rows_len,
		 (del_lf_rows_len/lf_rows_len)*100 balance
FROM index_stats
WHERE name = 'IDX_TEST_NO';

----BALANCE  0으로 인덱스 리빌드 됨.
--LF_ROWS_LEN DEL_LF_ROWS_LEN    BALANCE
------------- --------------- ----------
--      95940               0          0











