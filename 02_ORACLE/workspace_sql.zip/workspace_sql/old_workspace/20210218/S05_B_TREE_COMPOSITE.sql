--Composite Index(결합 인덱스)															
--															
--	두 개 이상의 컬럼을 합쳐서 인덱스를 생성 하는것.														
--	인덱스 순서 중요.														
--	*주로 where조거 컬럼이 2개 이상 and로 연결될때 사용.														
--	(단 or는 결합 인덱스 생성하면 않됨.)														
--	*두개의 컬럼이 합쳐서 결합인덱스 키가 생성된다.														

-- emp ename,job을 결합 인덱스로 사용
CREATE INDEX idx_emp_comp 
ON emp ( ename,job );


