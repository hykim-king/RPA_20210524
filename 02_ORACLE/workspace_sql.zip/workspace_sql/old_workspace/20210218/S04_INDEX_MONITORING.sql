--index_name조회
--SELECT t1.table_name,
--       t1.column_name,
--       t1.index_name
--FROM user_ind_columns t1
--WHERE t1.table_name = 'EMP2';

--EMP2_NAME99_UK
--
--	인덱스 사용여부 모니터링 하기 																			
--		-사용하지 않는 인덱스를 삭제하기 위함																		
--		-모니터링 시작 하기																		
--		ALTER INDEX 인덱스 이름 MONITORING USAGE;																		
--		-모니터링 중단																		
--		ALTER INDEX 인덱스 이름 NOMONITORING USAGE;																		

--		-모니터링 시작 하기																		
--ALTER INDEX EMP2_NAME99_UK MONITORING USAGE;	

-- 모니터링 사용여부 확인

--SELECT index_name,
--       used
--FROM v$object_usage
--WHERE index_name = 'EMP2_NAME99_UK'
--;

--		-모니터링 중단																		
---ALTER INDEX EMP2_NAME99_UK NOMONITORING USAGE;	
col index_name for a20
col used for a20
SELECT index_name,
       used
FROM v$object_usage
WHERE index_name = 'EMP2_NAME99_UK'
;
--INDEX_NAME           USED
---------------------- --------------------
--EMP2_NAME99_UK       NO

