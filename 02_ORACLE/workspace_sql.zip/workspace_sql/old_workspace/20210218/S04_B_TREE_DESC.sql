--DESCEDING INDEX(내림차순 인덱스)															
--	인덱스 생성시 큰 값이 먼저오도록 처리																															
--	* 오름차순/내림차순 동시에 사용할 경우: 별도 생성 하지 말고 hint사용															
--																
--	* 인덱스가 많아 지는 경우 DML에 취약															

--professor pay desc

CREATE INDEX idx_professor_pay99
ON professor ( pay DESC);