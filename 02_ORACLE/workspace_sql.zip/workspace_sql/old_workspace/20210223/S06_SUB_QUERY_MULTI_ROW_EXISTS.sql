--EXISTS : 존재하면
--어떤 데이터가 있는지 없는지 확인해서 쿼리를 수행 할때 아주 많이 사용 됩니다.


--SUB 쿼리의 내용을 먼저 수행하고 그 결과가 1건이라도 나오면 메인쿼리 수행.
--한건도 나오지 않으면 MAIN 쿼리가 수행 않됨.
--
--IN VS EXISTS

--SELECT *
--FROM dept
--WHERE deptno IN (SELECT deptno
--                 FROM dept
--                 WHERE deptno = &deptno
--)
--;
--deptno의 값을 입력하십시오: 10
--구   5:                  WHERE deptno = &deptno
--신   5:                  WHERE deptno = 10
--
--    DEPTNO DNAME                        LOC
------------ ---------------------------- --------------------------
--        10 ACCOUNTING                   NEW YORK

SELECT *
FROM dept
WHERE EXISTS    (SELECT '1' 
                 FROM dept
                 WHERE deptno = &deptno
)
;
--    DEPTNO DNAME                        LOC
------------ ---------------------------- --------------------------
--        10 ACCOUNTING                   NEW YORK
--        20 RESEARCH                     DALLAS
--        30 SALES                        CHICAGO
--        40 OPERATIONS                   BOSTON
