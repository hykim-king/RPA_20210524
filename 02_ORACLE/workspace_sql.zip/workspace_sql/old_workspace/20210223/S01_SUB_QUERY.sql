--상호연관 Sub query															
--	main query와 sub query가 데이터를 주고 받는 관계														
--	성능이 않좋음.(잘못 사용될 경우 성능 저하의 원인이 될수 있으므로 조심해야 함.)														
--															
--	emp2테이블을 조회해서 직원들중 자신의 직급 평균연봉과 같거나 많이 받는 사람들의 이름 직급,현재연봉														
col name for a30
col position for a25
col "SALAY" for a20
SELECT t1.name,
       t1.position,
	   TO_CHAR(t1.pay,'$999,999,999,999') "SALAY"
FROM emp2 t1
WHERE t1.pay >= ( SELECT AVG(pay)
                  FROM emp2 t2
				  WHERE t1.position = t2.position	
                 )
;
--NAME                           POSITION                  SALAY
-------------------------------- ------------------------- --------------------
--Kurt Russell                   Boss                           $100,000,000
--AL Pacino                      Department head                 $72,000,000
--Tommy Lee Jones                Deputy department head          $60,000,000
--Gene Hackman                   Section head                    $56,000,000
--Kevin Bacon                    Department head                 $75,000,000
--Keanu Reeves                   Deputy Section chief            $35,000,000
--
--6 행이 선택되었습니다.
