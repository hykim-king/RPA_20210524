--with_test1 테이블에서 no 120000번에서 130000사이인 사람들 중 
--가장 pay가 작은 사람들을 찾은 후 그 사람보다 pay가 작은 사람수를 세는 작업.

--1. no 컬럼에 인덱스 생성
--2. sub query를 이용해서 데이터 조회 및 시간 측정.
--3. with절을 이용해서 데이터 조회 및 시간 측정.

--1. 
--CREATE INDEX idx_with_no
--ON with_test1 ( NO ASC);

--SELECT pay
--FROM with_test1 t1
--WHERE no BETWEEN 120000 AND 130000;

--10001 행이 선택되었습니다.
--
--경   과: 00:00:02.49
--SELECT count(*)
--FROM with_test1 
--WHERE pay <ALL(SELECT /*+ INDEX(t1 idx_with_no)  */ pay
--               FROM with_test1 t1
--               WHERE no BETWEEN 120000 AND 130000)
--;
--  COUNT(*)
------------
--      1118
--
--경   과: 00:00:03.09


WITH t AS (
	SELECT /*+ INDEX(t1 idx_with_no)  */ min(pay) min_pay
	FROM with_test1 t1
	WHERE no BETWEEN 120000 AND 130000
)
SELECT  COUNT(*)
FROM with_test1 t1, t
WHERE t1.pay< t.min_pay
;

--11:42:56 SCOTT>@S05_WITH_SUB_QUERY.sql
--
--  COUNT(*)
------------
--      1118
--
--경   과: 00:00:00.00







