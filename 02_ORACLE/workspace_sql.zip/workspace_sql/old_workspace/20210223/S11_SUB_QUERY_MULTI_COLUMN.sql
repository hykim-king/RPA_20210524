SELECT t2.profno,
       t2.name,
       TO_CHAR(t2.hiredate,'YYYY-MM-DD') hiredate,
       t3.dname "DEPT_NAME"
FROM professor t2,department t3
WHERE t2.deptno = t3.deptno
and (t2.deptno, t2.hiredate) IN (SELECT deptno,MIN(t1.hiredate)
                                 FROM professor t1
                                 GROUP BY deptno
);