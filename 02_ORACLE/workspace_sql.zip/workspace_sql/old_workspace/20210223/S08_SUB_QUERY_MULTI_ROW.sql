SELECT t2.name,
       t2.grade,
       t2.weight
FROM student t2
WHERE t2.weight < ALL(SELECT t1.weight
                      FROM student t1
                      WHERE grade =2)
;
--NAME                  GRADE     WEIGHT
------------------ ---------- ----------
--Billy Crystal             3         48
--Danny Devito              1         48
--Nicholas Cage             3         42				   