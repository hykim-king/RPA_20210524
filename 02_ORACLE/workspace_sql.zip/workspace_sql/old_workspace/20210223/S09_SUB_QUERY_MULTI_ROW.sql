COL name FOR A25
COL dname FOR A35
SELECT t2.name,
       t3.dname,
       TO_CHAR(t2.pay,'$999,999,999,999') "SALARY"
FROM emp2 t2,dept2 t3
WHERE t2.deptno = t3.dcode
AND t2.pay <ALL( SELECT AVG(NVL(t1.pay,0))
                 FROM emp2 t1
                 GROUP BY t1.deptno);
				 
--NAME                      DNAME                               SALARY
--------------------------- ----------------------------------- ----------------------------------
--Harrison Ford             H/W Support Team                          $20,000,000
--Clint Eastwood            S/W Support Team                          $20,000,000
--JohnTravolta              Sales1 Team                               $22,000,000
--Robert De Niro            Sales2 Team                               $22,000,000
--Sly Stallone              Sales3 Team                               $22,000,000
--Tom Cruise                Sales4 Team                               $20,000,000
--
--6 행이 선택되었습니다.				 