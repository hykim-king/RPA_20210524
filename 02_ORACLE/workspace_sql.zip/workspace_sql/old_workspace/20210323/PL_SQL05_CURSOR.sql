--오라클 서버에서는 SQL 문을 실행할 때마다 처리(Parse,Execution)를 위한 
--메모리공간 (이 공간을 이후부터 SQL 커서라고 부르겠습니다)을 사용합니다. 
--즉 사용자가 요청하는 데이터를 데이터베이스 버퍼 캐쉬에서 커서로 복사 해 온 후 커서에서 
--원하는 데이터를 추출하여(Fetch)후속 작업을 하게 된다는 뜻입니다. 이 메모리 공간을 PrivateSQL Area 라고도 부르며, 
--오라클의 서버 프로세스 구성이 DedicatedServer 환경이냐 또는 MTS(Multi-ThreadedServer)환경이냐에 따라 
--서버 내에 위치되는 곳이 다릅니다.
--
--SQL 커서는크게 묵시적커서(ImplicitCursor)와 명시적커서(ExplicitCursor)로 나눌 수 있습니다.
--
--묵시적커서(ImplicitCursor)
---묵시적커서는 오라클에서 자동적으로 선언해주는 SQL 커서로서, 
---사용자는 생성 유무를 알 수 없습니다.
--
--•묵시적커서 속성(CursorAttribute)
--- SQL%ROWCOUNT
--- SQL%FOUND
--- SQL%NOTFOUND
--- SQL%ISOPEN 
--
--명시적커서(ExplicitCursor)
--명시적커서는 사용자가 선언하여 생성 후 사용하는 SQL커서로, 주로 여러 개의 행을 처리하고자 할 경우 사용합니다.
--
--•명시적커서 속성(CursorAttribute)
--•커서이름%ROWCOUNT
--•커서이름%FOUND
--•커서이름%NOTFOUND
--•커서이름%ISOPEN 
--------------------------------------
--명시적 커서(Explicit Cursor) 처리 단계
--명시적커서 선언      - CURSOR  c_name
--명시적커서 오픈      - OPEN    c_name
--커서에서데이터 추출   - Fetch    c_name
--커서 사용종료       - CLOSE    c_name
--
--
--CURSOR  커서명  
--IS
-- 커서에담고 싶은 내용을 가져오는 서브쿼리
--OPEN 커서 이름 ;
--FETCH커서_이름 INTO 변수들;
--CLOSE커서_이름;

DECLARE
    v_empid employees.employee_id%TYPE;
	v_fname employees.first_name%TYPE;

	CURSOR C1 IS     --커서 선언
	SELECT employee_id,first_name
	FROM employees
	WHERE department_id =30;	
	
BEGIN
	OPEN C1;	--커서 OPEN
	LOOP
		FETCH C1 INTO v_empid,v_fname; --FETCH커서_이름 INTO 변수들;
	
		EXIT WHEN C1%NOTFOUND;--EXIT조건
		
		DBMS_OUTPUT.PUT_LINE(v_empid ||','||v_fname);
	
	END LOOP;
    CLOSE C1; --커서 CLOSE
END;
/
--114,덴
--115,알렉산더
--116,셸리
--117,시걸
--118,가이
--119,캐런
--
--PL/SQL 처리가 정상적으로 완료되었습니다.




























