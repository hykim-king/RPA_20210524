--FOR 반복문  반복 횟수를 지정 가능함
--FOR counter IN [REVERSE] start .. end LOOP
--  Statement1 ;
--  Statement2 ;
--…
--END LOOP ;

DECLARE

BEGIN
	FOR  i  IN REVERSE 0 .. 20 LOOP
		DBMS_OUTPUT.PUT_LINE(i);
	END LOOP;
	
END;
/