--case문
--CASE  [ 조건 ]
--   WHEN 조건 1  THEN  결과 1
--   WHEN 조건 2  THEN  결과 2
--    …
--   WHEN 조건 n  THEN  결과 n
--[ ELSE  기본값 ]
--END ;

--유형 1번의 예: 
--      employees 테이블에서 employee_id 가 203 번인 사원의 employee_id , first_name , 
--      department_id , dname 을 출력하세요. 단 DNAME 의 값은 아래와 같습니다.
--      department_id 가 10 이면 ’Administration’ ,
--      department_id 가 20 이면 ‘Marketing’ ,
--      department_id 가 30 이면 ‘Purchasing’ ,
--      department_id 가 40 이면 'Human Resources’ 로 출력하세요.

DECLARE
	v_empid employees.employee_id%TYPE;
	v_fname employees.first_name%TYPE;
	v_deptid employees.department_id%TYPE;
	v_dname  VARCHAR2(30 BYTE);
BEGIN
	SELECT employee_id,first_name,department_id
	INTO   v_empid,v_fname,v_deptid
	FROM employees
	WHERE employee_id = 203;
	
	v_dname :=   CASE v_deptid
					WHEN 10 THEN  'Administration'
					WHEN 20 THEN  'Marketing'
					WHEN 30 THEN  'Purchasing'
					WHEN 40 THEN  'Human Resources'
				 END;

	
	DBMS_OUTPUT.PUT_LINE(v_empid ||','|| v_fname||','|| v_deptid||','|| v_dname);
	
END;
/
--203,수잔,40,Human Resources