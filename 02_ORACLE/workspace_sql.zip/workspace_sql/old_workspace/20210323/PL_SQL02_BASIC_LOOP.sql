--반복문은 반복 횟수를 알 수 없는 경우에 사용하는 
--BASIC LOOP 문과 
--WHILE 문이 있고 반복횟수를 지정하는 
--FOR 문이 있습니다.

--LOOP
--   PL/SQL 문장 ;
--   PL/SQL 문장 ;
--   EXIT [ 조건 ] ;
--END LOOP 

DECLARE
	
	no01 NUMBER := 0;

BEGIN
	LOOP
		DBMS_OUTPUT.PUT_LINE( no01 );
		no01 := no01 +1;
		EXIT WHEN no01 > 10;
	END LOOP;

END;
/
--09:13:34 HR>@PL_SQL02_BASIC_LOOP.sql
--0
--1
--2
--3
--4
--5
--6
--7
--8
--9
--10