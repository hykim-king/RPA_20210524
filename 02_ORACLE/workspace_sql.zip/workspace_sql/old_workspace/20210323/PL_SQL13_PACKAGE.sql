--패키지란
--패키지란 변수, 상수, 서브프로그램등의 항목을 묶어놓은 객체입니다. 
--여러가지 항목들을 모아 하나의 이름으로 묶어놓은 객체라고 생각하시면 됩니다. 
--패키지는 컴파일 과정을 거쳐 데이터베이스에 저장되며 다른 프로그램에서 패키지의 항목을 참조하고 실행할 수도 있습니다.

--패키지를 사용하는 이유
--프로그래밍을 하다보면 프로시저같은 서브 프로그램의 수가 기하급수적으로 많아지게 됩니다. 
--이렇게 항목들이 많아지게되면 관리하기가 힘들어지게되고 자신이 필요한 항목을 찾는것마저 어려워지는 상황이 옵니다. 
--이 상황을 방지하기 위해 여러가지 항목들을 좀 더 손쉽게 관리하자라는 요지에서 나온 것이 바로 패키지라는 개념입니다.

--패키지 사용법
--패키지는 선언부, 본문, 실행부로 이루어집니다.

--1. 선언부
CREATE [OR REPLACE] PACKAGE package_name --패키지 선언부
IS|AS
  PUBLIC TYPE 
  PROCEDURE PROC_1;                         --패키지로 묶을 프로시저1 
  PROCEDURE PROC_2(P_PRODUCT_ID IN NUMBER); --패키지로 묶을 프로시저2
  
  FUNCTION FUNC_1(P_PRODUCT_ID IN NUMBER)   --패키지로 묶을 함수
  RETURN VARCHAR2;
  
END package_name;  --패키지 종료

--2.본문
CREATE [OR REPLACE] PACKAGE BODY package_name
IS|AS
----------패키지 선언부 프로시저1----------
PROCEDURE PROC_1
    IS
	BEGIN
	
END PROC_1;	
----------패키지 선언부 프로시저1----------


----------패키지 선언부 프로시저2----------
PROCEDURE PROCEDURE PROC_2(P_PRODUCT_ID IN NUMBER)
    IS
	BEGIN
	
	
	
END PROC_2;	
----------패키지 선언부 프로시저2----------
END package_name; 


--3.실행부
EXEC package_name.PROC_1;
EXEC package_name.PROC_2(20);



