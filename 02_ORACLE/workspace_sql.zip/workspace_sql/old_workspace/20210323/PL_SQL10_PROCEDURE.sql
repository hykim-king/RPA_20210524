--PROCEDURE(프로시저):
--생성 CREATE PROCEDURE
--삭제 DROP PROCEDURE
--수정 ALTER PROCEDURE
--CREATE [OR REPLACE] PROCEDURE procedure_name
--[(
--	parameter1 datatype1,
--	parameter2 datatype2,
--	parameter3 datatype3
--)]
--IS|AS
--PL/SQL BLOCK


--PARAMETER
--IN: 사용자로 부터 입력
--OUT: RETURN
--IN OUT:  입력 출력 가능