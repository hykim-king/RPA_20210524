--선언부 조회 하기
SELECT text
FROM user_source
WHERE type ='PACKAGE';

--BODY
SELECT text
FROM user_source
WHERE type ='PACKAGE BODY';