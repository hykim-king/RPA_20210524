--NULL값을 위한 DEFAULT 값 지정

--일반적인 default
--CREATE TABLE d_test100(
--	no NUMBER,
--	name VARCHAR2(200),
--	sal NUMBER DEFAULT 200
--);

--INSERT INTO d_test100 (no,name) VALUES (1,'AAA');


--INSERT INTO d_test100 VALUES (2,'BBB',NULL);
--
--SELECT *
--FROM d_test100;

--  NO NAME              SAL
------ ---------- ----------
--   1 AAA               200
--   2 BBB

--개선된  default
--CREATE TABLE d_test300(
--	no NUMBER,
--	name VARCHAR2(200),
--	sal NUMBER DEFAULT ON NULL 100
--);

--INSERT INTO d_test300 (no,name) VALUES (1,'AAA');
INSERT INTO d_test300 VALUES (2,'BBB',NULL);
SELECT *
FROM d_test300;

CREATE TABLE d_test500(
	no NUMBER,
	name VARCHAR2(5000),
	sal NUMBER DEFAULT ON NULL 100
);