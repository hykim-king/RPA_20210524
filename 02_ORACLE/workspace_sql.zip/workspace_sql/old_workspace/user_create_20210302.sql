col tablespace_name for a10
col file_name for a50
select tablespace_name, bytes/1024/1024 MB, file_name 
from dba_data_files ;


 create tablespace MIRACLE_TS
datafile 'C:\APP\SIST\PRODUCT\18.0.0\ORADATA\XE\USERS01.DBF'
size 300m autoextend on next 5m;