--COL view_name FOR  A15
--COL read_only FOR  A80
--COL read_only FOR  A15
--SELECT view_name,
--       text,
--       read_only
--FROM user_views
--;

--V_EMP VIEW삭제
--DROP VIEW v_emp;

COL view_name FOR  A15
COL read_only FOR  A80
COL read_only FOR  A15
SELECT view_name,
       text,
       read_only
FROM user_views
;

--VIEW_NAME       TEXT                                                                             READ_ONLY
----------------- -------------------------------------------------------------------------------- ---------------
--VIEW1           SELECT a,b                                                                       N
--                FROM o_table
--
--VIEW2           SELECT a,b                                                                       Y
--                        FROM o_table
--                        WITH READ ONLY
--
--VIEW3           SELECT a,b                                                                       N
--                   FROM o_table
--                   WHERE a=3
--                WITH CHECK OPTION
--
--V_EMP1          SELECT empno,                                                                    N
--                       ename,
--                           hiredate
--                FROM emp