--1. COMPLEX VIEW����
--CREATE OR REPLACE VIEW v_emp								
--AS								
--SELECT t1.ename, t2.dname							
--FROM emp t1, dept t2							
--WHERE t1.deptno = t2.deptno;							


--2. VIEW��ȸ
--SELECT *
--FROM v_emp;
