SELECT num,profno,name,pay,sum_pay,avg_pay
FROM(
    SELECT rownum num,
           profno,
           name,
           pay,
           pay sum_pay,
           pay avg_pay,
           ceil(rownum/3) gnum
    FROM professor
    UNION ALL
    SELECT NULL num,
           null profno,
           null name,
           null pay,
           SUM(pay),
           ROUND(AVG(NVL(PAY,0)),1),
           gnum
    FROM(
        SELECT pay,
               ceil(rownum/3) gnum,
               profno
        FROM professor
        ORDER BY profno
    )
    GROUP BY gnum
)
ORDER BY gnum,num
;




