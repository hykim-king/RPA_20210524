--emp와 dept 테이블을 조회 하여, 부서번호,부서별 최대급여 및 부서명.
SELECT t1.deptno,
       t2.dname,
	   t1.sal
FROM (
		SELECT deptno,MAX(sal) sal
		FROM emp
		GROUP BY deptno
)t1, dept T2
WHERE t1.deptno = t2.deptno
;
--    DEPTNO DNAME                               SAL
------------ ---------------------------- ----------
--        10 ACCOUNTING                         5000
--        20 RESEARCH                           3300
--        30 SALES                              2850