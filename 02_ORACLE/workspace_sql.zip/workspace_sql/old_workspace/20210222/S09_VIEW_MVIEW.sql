--Materialized View(Mview) 																	
--	데이터를 가지고 있는 View, 대용량 view일 경우 성능 이슈가 발생.																
--																	
--	*원본 테이블과 동기화 방법																
--																	
--	*권한																
--	GRANT query rewrite to scott;																
--	GRANT CREATE MATERIALIZED VIEW to scott;																

--권한 부여
--11:09:11 SCOTT>CONN / AS SYSDBA
--11:09:58 SYS>GRANT query rewrite to scott;
--11:10:31 SYS>GRANT CREATE MATERIALIZED VIEW to scott;
--
--권한이 부여되었습니다.

--계정전환
--11:11:06 SYS>conn scott/sist

--MVIEW생성
--CREATE MATERIALIZED VIEW m_prof
--BUILD IMMEDIATE
--REFRESH
--ON DEMAND
--COMPLETE
--ENABLE QUERY REWRITE
--AS
--SELECT profno,name,pay
--FROM professor;


--BUILD IMMEDIATE : 서버쿼리 수행 하면서 데이터를 가져오라
--ON DEMAND :사용자가 수동으로 데이터 동기화
-- ON COMMIT: 원본테이블 변경후 COMMIT이 발생하면 자동으로 동기화
--COMPLETE : MVIEW 내의 데이터 전체가 원본 테이블과 동기화 되는 방법.
--  ATOMIC_REFRESH=TRUE와 COMPLETE로 설정되어야 한다.
--  데이터가 많은 경우 시간이 많이 소유.
--  FAST : 원본 테이블에 새로운 데이터가 입력된 경우 그 부분만 MVIEW로 동기화
--  FORCE: FAST방법이 간으한지 살펴보고 불가능하면 COMPLETE방법을 사용자가
--  NEVER: 동기화 하지 않음.

--BUILD IMMEDIATE : 즉시 서브쿼리를 수행해서 데이이터를 가져와라.
--ON DEMAND(동기화): 사용자가 수동으로 동기화 명령을 수행해서 동기화 한다.
--ON COMMIT : COMMIT이 발생하면 동기화
--REFRESH :
--1. COMPLETE :MVIEW내의 데이터 전체가 원본 테이블과 동기화
--2. FAST : 원본 테이블에 새로운 데이터가 입력될 경우 그 부분만 동기화
--3. FORCE : FAST방법이 가능한지 살펴 보고 불가능하면 COMPLETE방법으로 동기화
--4. NAVER : 동기화 자지 않음.

--MVIEW 인덱스 생성: 데이를 가지고 있는지 확인

--CREATE INDEX idx_m_prof_pay
--ON m_prof ( pay ASC);
--
--인덱스가 생성되었습니다.


--MVIEW관리
--1. 수동으로 원본테이블과 데이터 동기화

--SELECT profno,name,pay
--FROM professor;

--PROFNO NAME                        PAY
-------- -------------------- ----------
--  1001 Audie Murphy                550
--  1002 Angela Bassett              380
--  1003 Jessica Lange               270
--  2001 Winona Ryder                250
--  2002 Michelle Pfeiffer           350
--  2003 Whoopi Goldberg             490
--  3001 Emma Thompson               530
--  3002 Julia Roberts               330
--  3003 Sharon Stone                290
--  4001 Meryl Streep                570
--  4002 Susan Sarandon              330
--  4003 Nicole Kidman               310
--  4004 Holly Hunter                260
--  4005 Meg Ryan                    500
--  4006 Andie Macdowell             253
--  4007 Jodie Foster                290
--  5001 James Bond                  500
--
--17 행이 선택되었습니다.

--SELECT *
--FROM m_prof;
----17 행이 선택되었습니다.



--원본 테이블 데이터 1건 삭제
--DELETE FROM professor
--WHERE profno = 5001
--;

--COMMIT;

--SELECT COUNT(*)
--FROM professor;
--
--  COUNT(*)
------------
--        16


--SELECT COUNT(*)
--FROM m_prof;
--
--
--
--  COUNT(*)
------------
--        17
--DBMS_MVIEW 패키지로 동기화 수행.

BEGIN
	DBMS_MVIEW.REFRESH('M_PROF');
END;
/

--동기화 이후 건수 확인 
SELECT COUNT(*)
FROM m_prof;
  COUNT(*)
----------
        16















