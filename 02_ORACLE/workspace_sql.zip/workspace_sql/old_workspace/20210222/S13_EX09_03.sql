col dname for a35
col max_height for 99999
col name for a25
col height for 99999
SELECT t2.dname, t1.max_height,t3.name,t3.height
FROM (SELECT deptno1,max(height) max_height
	  FROM student
	  GROUP BY deptno1)t1, department t2,student t3
WHERE t1.deptno1 = t2.deptno
AND t1.max_height = t3.height
AND t1.deptno1    = t3.deptno1
;

--DNAME                               MAX_HEIGHT NAME                      HEIGHT
------------------------------------- ---------- ------------------------- ------
--Software Engineering                       168 Sandra Bullock               168
--Electronic Engineering                     177 Demi Moore                   177
--Mechanical Engineering                     182 Danny Glover                 182
--Computer Engineering                       182 Richard Dreyfus              182
--Library and Information science            184 Daniel Day-Lewis             184
--Multimedia Engineering                     179 Charlie Sheen                179
--
--6 행이 선택되었습니다.