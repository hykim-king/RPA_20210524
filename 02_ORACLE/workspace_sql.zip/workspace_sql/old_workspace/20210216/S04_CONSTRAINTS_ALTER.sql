--테이블 생성후 제약 조건 추가
--NEW_EMP2 NAME 컬럼에 UNIQUE 추가

--ALTER TABLE 테이블이름
--ADD CONSTRAINT 제약조건이름 제약(커럼)

ALTER TABLE new_emp2
ADD
CONSTRAINT emp2_name_uk UNIQUE(name);
