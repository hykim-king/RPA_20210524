--제약조건에 이름이 없는 겨우: 제약조건 관리에 어려움이 있다.
--직접 지정을 권장한다.

CREATE TABLE new_emp02(
	no NUMBER(4)            PRIMARY KEY,
    name VARCHAR2(20 BYTE)  NOT NULL,
	jumin VARCHAR2(13 BYTE) NOT NULL UNIQUE,
	loc_code NUMBER(1)      CHECK(loc_code<5),
	deptno VARCHAR2(6 BYTE) REFERENCES dept2(DCODE)
);