--FK 작성시 PARENT테이블의 해당 컬럼은 UNIQUE KEY가 설정되어야 한다.
--ALTER TABLE new_emp2
--ADD CONSTRAINT emp2_name_fk FOREIGN KEY(name)
--REFERENCES emp2(name);

--3행에 오류:
--ORA-02270: 이 열목록에 대해 일치하는 고유 또는 기본 키가 없습니다.

--emp2 테이블에 name컬럼에 unique생성
--ALTER TABLE emp2
--ADD CONSTRAINT emp2_name99_uk UNIQUE(name);


ALTER TABLE new_emp2
ADD CONSTRAINT emp2_name_fk FOREIGN KEY(name)
REFERENCES emp2(name);