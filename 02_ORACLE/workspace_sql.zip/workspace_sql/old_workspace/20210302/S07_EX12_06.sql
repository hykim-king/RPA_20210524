col "Name and Position" for a60
col  "PATH" for a700
SELECT LPAD(t1.name||'-'||t2.dname||'-'||NVL(t1.position,'Team Worker'),LEVEL*27,'-') "Name and Position"       
       ,SYS_CONNECT_BY_PATH(t1.name,'-') "PATH"
FROM emp2 t1,dept2 t2
WHERE t1.deptno = t2.dcode
START WITH t1.empno =19966102
CONNECT BY PRIOR t1.empno = t1.pempno
ORDER SIBLINGS BY t1.name
;