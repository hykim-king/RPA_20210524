--계층 구조의 문법															
--															
--	1.START WITH														
--			-계층형 질으의 루트(부모행)												
--			-서브쿼리를 사용할수도 있다.												
--	2. CONNECT BY														
--			- 계층 질의에서 상위계층과 하위계층의 관계를 규정												
--			- PRIOR 연산자와 함께 사용하여 계층 구조로 표현												
--															
--			EX) CONNECT BY PRIOR 자식컬럼 = 부모컬럼 (부모에서 자식으로) top down												
--			EX) CONNECT BY PRIOR 부모컬럼  = 자식컬럼 (자식에서 부모) bottom up												
--	LEVEL : Pseudocolumn														
--		- Level은 계층구조의 depth를 표현하는 의사컬럼.													
--	3.  WHERE														
--															
--	*ORDER SIBLINGS BY														
--			-계층 구조간의 정열	
--SELECT empno,
--       level,
--	   LPAD(ename,LEVEL*4,'*') "ENAME"
--FROM emp
--START WITH mgr IS NULL
--CONNECT BY prior empno = mgr;

--     EMPNO      LEVEL ENAME
------------ ---------- --------------------
--      7839          1 KING
--      7566          2 ***JONES
--      7902          3 ********FORD
--      7369          4 ***********SMITH
--      7698          2 ***BLAKE
--      7499          3 *******ALLEN
--      7521          3 ********WARD
--      7654          3 ******MARTIN
--      7844          3 ******TURNER
--      7900          3 *******JAMES
--      7782          2 ***CLARK
--      7934          3 ******MILLER

--ORDER SIBLINGS BY : 갑은 Level 정열
--SELECT절 prior ENAME AS "MGR_NM"
--SYS_CONNECT_BY_PATH : empno기준으로 계층구조 보기
col depth_name for a20
col "MGR_NM" for a20
col "depth_list" for a100
SELECT empno,
	   LPAD(' ',LEVEL*2,' ') || ename "depth_name",
	   prior ENAME AS "MGR_NM",
	   SYS_CONNECT_BY_PATH(ename,'-') "depth_list"
FROM emp
START WITH mgr IS NULL
CONNECT BY PRIOR empno = mgr
ORDER SIBLINGS BY ename;  

--     EMPNO      LEVEL depth_name
------------ ---------- --------------------
--      7839          1   KING
--      7698          2     BLAKE
--      7499          3       ALLEN
--      7900          3       JAMES
--      7654          3       MARTIN
--      7844          3       TURNER
--      7521          3       WARD
--      7782          2     CLARK
--      7934          3       MILLER
--      7566          2     JONES
--      7902          3       FORD
--      7369          4         SMITH
--
12 행이 선택되었습니다.
