--계층구조에서 일부분만 계층화 하기
--col depth_name for a20
--col "MGR_NM" for a20
--col "depth_list" for a100
--SELECT empno,
--	   LPAD(' ',LEVEL*2,' ') || ename "depth_name",
--	   prior ename AS "MGR_NM",
--	   SYS_CONNECT_BY_PATH(ename,'-') "depth_list"
--FROM emp
--START WITH mgr IS NULL
--CONNECT BY PRIOR empno = mgr
--      AND ename <> 'JONES'
--ORDER SIBLINGS BY ename; 


--     EMPNO depth_name           MGR_NM               depth_list
------------ -------------------- -------------------- ----------------------------------------------------------------------------------------------------
--      7839   KING                                    -KING
--      7698     BLAKE            KING                 -KING-BLAKE
--      7499       ALLEN          BLAKE                -KING-BLAKE-ALLEN
--      7900       JAMES          BLAKE                -KING-BLAKE-JAMES
--      7654       MARTIN         BLAKE                -KING-BLAKE-MARTIN
--      7844       TURNER         BLAKE                -KING-BLAKE-TURNER
--      7521       WARD           BLAKE                -KING-BLAKE-WARD
--      7782     CLARK            KING                 -KING-CLARK
--      7934       MILLER         CLARK                -KING-CLARK-MILLER
--
--9 행이 선택되었습니다.


--계층구조가 회손된다.
col depth_name for a20
col "MGR_NM" for a20
col "depth_list" for a100
SELECT empno,
	   LPAD(' ',LEVEL*2,' ') || ename "depth_name",
	   prior ename AS "MGR_NM",
	   SYS_CONNECT_BY_PATH(ename,'-') "depth_list"
FROM emp
WHERE ename <> 'JONES'
START WITH mgr IS NULL
CONNECT BY PRIOR empno = mgr      
ORDER SIBLINGS BY ename; 

--     EMPNO depth_name           MGR_NM               depth_list
------------ -------------------- -------------------- ----------------------------------------------------------------------------------------------------
--      7839   KING                                    -KING
--      7698     BLAKE            KING                 -KING-BLAKE
--      7499       ALLEN          BLAKE                -KING-BLAKE-ALLEN
--      7900       JAMES          BLAKE                -KING-BLAKE-JAMES
--      7654       MARTIN         BLAKE                -KING-BLAKE-MARTIN
--      7844       TURNER         BLAKE                -KING-BLAKE-TURNER
--      7521       WARD           BLAKE                -KING-BLAKE-WARD
--      7782     CLARK            KING                 -KING-CLARK
--      7934       MILLER         CLARK                -KING-CLARK-MILLER
--      7902       FORD           JONES                -KING-JONES-FORD
--      7369         SMITH        FORD                 -KING-JONES-FORD-SMITH
--
--11 행이 선택되었습니다.





