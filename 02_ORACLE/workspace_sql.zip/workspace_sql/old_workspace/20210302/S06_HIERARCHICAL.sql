--CONNECT_BY_ROOT :특정 레벨에서 최상위 값을 찾아주는 함수
--COL "ROOT<-LEAF" FOR A40
--COL ename FOR A20
--SELECT empno,
--       ename,
--	   level,
--	   SYS_CONNECT_BY_PATH(ename,'<-') "ROOT<-LEAF",
--	   CONNECT_BY_ROOT empno "ROOT EMPNO"
--FROM emp
--WHERE LEVEL > 1
--AND empno = 7369
--CONNECT BY PRIOR empno = mgr
--;

--     EMPNO ENAME                     LEVEL ROOT<-LEAF                               ROOT EMPNO
------------ -------------------- ---------- ---------------------------------------- ----------
--      7369 SMITH                         2 <-FORD<-SMITH                                  7902
--      7369 SMITH                         3 <-JONES<-FORD<-SMITH                           7566
--      7369 SMITH                         4 <-KING<-JONES<-FORD<-SMITH                     7839
--
--경   과: 00:00:00.00


COL "ROOT<-LEAF" FOR A40
COL ename FOR A20
SELECT empno,
       ename,
	   level,
	   SYS_CONNECT_BY_PATH(ename,'<-') "ROOT<-LEAF",
	   CONNECT_BY_ROOT empno "ROOT EMPNO"
FROM emp
WHERE LEVEL = 3
AND empno = 7369
CONNECT BY PRIOR empno = mgr
;