--계층 구조의 문법															
--															
--	1.START WITH														
--			-계층형 질으의 루트(부모행)												
--			-서브쿼리를 사용할수도 있다.												
--	2. CONNECT BY														
--			- 계층 질의에서 상위계층과 하위계층의 관계를 규정												
--			- PRIOR 연산자와 함께 사용하여 계층 구조로 표현												
--															
--			EX) CONNECT BY PRIOR 자식컬럼 = 부모컬럼 (부모에서 자식으로) top down												
--			EX) CONNECT BY PRIOR 부모컬럼  = 자식컬럼 (자식에서 부모) bottom up												
--	LEVEL : Pseudocolumn														
--		- Level은 계층구조의 depth를 표현하는 의사컬럼.													
--	3.  WHERE														
--															
--	*ORDER BY SIBLINGS BY														
--			-계층 구조간의 정열												
--SELECT LPAD(ename,LEVEL*4,'*') "ENAME"
--FROM emp
--CONNECT BY  empno =  PRIOR mgr
--START WITH empno = 7839;

--09:47:25 SCOTT>@S02_HIERARCHICAL.sql
--
--ENAME
----------------------
--KING


SELECT LPAD(ename,LEVEL*5,'-') "ENAME"
FROM emp
CONNECT BY  empno =  PRIOR mgr
START WITH empno = 7369;


--ENAME
----------------------
--SMITH
--------FORD
------------JONES
------------------KING