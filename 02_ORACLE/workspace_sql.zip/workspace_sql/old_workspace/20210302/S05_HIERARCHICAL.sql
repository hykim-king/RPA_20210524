--SYS_CONNECT_BY_PATH : 전체경로 출력
--CONNECT_BY_ISLEAF() : 값에 0을 주면 마지막 값을 안 볼 수도 있고, 1을 주고 마지막 값만 볼수  있다.
--COL ename FOR a25
--COL "ORDER(ROW->HIGH)" FOR a30
--SELECT LPAD(ename, level*5,'*') ename,
--       SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
--FROM emp
--START WITH empno = 7369
--CONNECT BY empno = PRIOR mgr;

--ENAME                     ORDER(ROW->HIGH)
--------------------------- ------------------------------
--SMITH                     ->SMITH
--******FORD                ->SMITH->FORD
--**********JONES           ->SMITH->FORD->JONES
--****************KING      ->SMITH->FORD->JONES->KING

--COL ename FOR a25
--COL "ORDER(ROW->HIGH)" FOR a30
--SELECT LPAD(ename, level*5,'*') ename,
--       SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
--FROM emp
--WHERE CONNECT_BY_ISLEAF = 0
--START WITH empno = 7369
--CONNECT BY empno = PRIOR mgr;

--ENAME                     ORDER(ROW->HIGH)
--------------------------- ------------------------------
--SMITH                     ->SMITH
--******FORD                ->SMITH->FORD
--**********JONES           ->SMITH->FORD->JONES


--COL ename FOR a25
--COL "ORDER(ROW->HIGH)" FOR a30
--SELECT LPAD(ename, level*5,'*') ename,
--       SYS_CONNECT_BY_PATH(ename,'->') "ORDER(ROW->HIGH)"
--FROM emp
--WHERE CONNECT_BY_ISLEAF = 1
--START WITH empno = 7369
--CONNECT BY empno = PRIOR mgr;
--
--
--ENAME                     ORDER(ROW->HIGH)
--------------------------- ------------------------------
--****************KING      ->SMITH->FORD->JONES->KING