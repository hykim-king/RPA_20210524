--Ư�� �÷��� COPY
--CREATE TABLE dept5
--AS
--SELECT deptno,dname  FROM dept;

SELECT * FROM dept5;
--    DEPTNO DNAME
------------ ----------------------------
--        10 ACCOUNTING
--        20 RESEARCH
--        30 SALES
--        40 OPERATIONS