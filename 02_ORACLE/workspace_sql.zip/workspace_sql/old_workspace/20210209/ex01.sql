SELECT employee_id
FROM employees;
