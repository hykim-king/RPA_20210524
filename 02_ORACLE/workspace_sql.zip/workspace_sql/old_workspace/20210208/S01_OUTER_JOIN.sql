--OUTER JOIN : 
--한쪽 테이블에는 데이터가 있고 다른쪽에는 데이터가 없는 경우
--데이터가 있는 쪽에 테이블의 내용을 모두 출력.

--ex)student테이블의 건수 20건,
--professor조인 하면 15건 -> 20건으로 출력

--1. ORACLE outer join 
--데이터가 없는 쪽 조인 조건에(+)

--2. ansi outer join
--데이터가 존재하는 쪽에 표시: left outer join, right outer join

--**선행테이블에 데이터를 다 검색하는 경우, 테이블에 인덱스가 있어도 쓰지 않고 FULL SCAN을 한다.



--SELECT t1.name "STU_NAME"
--      ,t2.name "PROF_NAME"
--FROM student t1, professor t2
--WHERE t1.profno = t2.profno;

--SELECT COUNT(*)
--FROM student;
col "STU_NAME" for a20
col "PROF_NAME" for a20
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1, professor t2
WHERE t1.profno = t2.profno(+);

--STU_NAME             PROF_NAME
---------------------- --------------------
--James Seo            Audie Murphy
--Billy Crystal        Angela Bassett
--Richard Dreyfus      Angela Bassett
--Rene Russo           Winona Ryder
--Tim Robbins          Winona Ryder
--Nicholas Cage        Michelle Pfeiffer
--Sandra Bullock       Julia Roberts
--Demi Moore           Meryl Streep
--Macaulay Culkin      Meryl Streep
--Wesley Snipes        Susan Sarandon
--Danny Glover         Nicole Kidman
--Micheal Keaton       Nicole Kidman
--Steve Martin         Nicole Kidman
--Bill Murray          Jodie Foster
--Daniel Day-Lewis     Jodie Foster
--Danny Devito
--Sean Connery
--Christian Slater
--Charlie Sheen
--Anthony Hopkins
--
--20 행이 선택되었습니다.




