col name for a20
col "curr_position" for a25
col "to_position" for a25

--SELECT * FROM p_grade;

--BOSS : AGE 57
--p_grade END ANG 이므로 BOSS는 조회되지 않음.

--ORACLE
--SELECT  t1.name
--       ,TRUNC((sysdate - birthday)/365) AGE
--	   ,t1.position "curr_position"
--	   ,t2.position  "to_position"
--FROM emp2 t1, p_grade t2
--WHERE TRUNC((sysdate - birthday)/365) BETWEEN  t2.s_age AND t2.e_age
--;

--SELECT  t1.name
--       ,TRUNC((sysdate - birthday)/365) AGE
--	   ,birthday
--	   ,t1.position
--FROM emp2 t1	   

--ANSI
SELECT  t1.name
       ,TRUNC((sysdate - birthday)/365) AGE
	   ,t1.position "curr_position"
	   ,t2.position  "to_position"
FROM emp2 t1 INNER JOIN p_grade t2
ON TRUNC((sysdate - birthday)/365) BETWEEN  t2.s_age AND t2.e_age
;
--NAME                        AGE curr_position             to_position
---------------------- ---------- ------------------------- -------------------------
--Jack Nicholson               36                           Deputy department head
--Denzel Washington            37                           Department head
--Richard Gere                 38                           Department head
--Kevin Costner                39                           Department head
--Robert De Niro               40                           Department head
--Tom Cruise                   40                           Department head
--Harrison Ford                40                           Department head
--Clint Eastwood               40                           Department head
--Sly Stallone                 40                           Department head
--JohnTravolta                 40                           Department head
--Tommy Lee Jones              44 Deputy department head    Director
--Val Kilmer                   44 Department head           Director
--Woody Harrelson              45 Section head              Director
--Gene Hackman                 47 Section head              Director
--AL Pacino                    47 Department head           Director
--Hugh Grant                   48 Section head              Director
--Kevin Bacon                  48 Department head           Director
--Chris O'Donnell              48 Section head              Director
--Keanu Reeves                 49 Deputy Section chief      Director
--
--19 행이 선택되었습니다.


--ANSI
SELECT  t1.name
       ,TRUNC((sysdate - birthday)/365) AGE
	   ,t1.position "curr_position"
	   ,t2.position  "to_position"
FROM emp2 t1 LEFT JOIN p_grade t2
ON TRUNC((sysdate - birthday)/365) BETWEEN  t2.s_age AND t2.e_age
;