--SELF JOIN : 한개의 테이블을 가지고 JOIN
--SELECT *
--FROM emp;

--사원이름 조회
--SELECT empno
--      ,ename
--	  ,mgr
--FROM emp 
--;
--     EMPNO ENAME             -   MGR      
------------ ------------- -----------
--      7369 SMITH             -  7902
--      7499 ALLEN             -  7698
--      7521 WARD              -  7698
--      7566 JONES             -  7839
--      7654 MARTIN            -  7698
--      7698 BLAKE             -  7839
--      7782 CLARK             -  7839
--      7839 KING              -
--      7844 TURNER            -  7698
--      7900 JAMES             -  7698
--      7902 FORD              -  7566
--      7934 MILLER            -  7782
--      1000 Tiger             -
--      2000 Cat


--     EMPNO ENAME                MGR
------------ ------------- ----------
--      7369 SMITH               7902
--      7499 ALLEN               7698
--      7521 WARD                7698
--      7566 JONES               7839
--      7654 MARTIN              7698
--      7698 BLAKE               7839
--      7782 CLARK               7839
--      7839 KING
--      7844 TURNER              7698
--      7900 JAMES               7698
--      7902 FORD                7566
--      7934 MILLER              7782
--      1000 Tiger
--      2000 Cat
--
--14 행이 선택되었습니다.

--상사이름 조회
--SELECT t1.ename "ENAME"
--	  ,t2.ename "MGR_NAME"
--FROM emp t1,emp t2
--WHERE t1.mgr = t2.empno
--;
--ENAME         MGR_NAME
--------------- --------------------
--FORD          JONES
--ALLEN         BLAKE
--WARD          BLAKE
--MARTIN        BLAKE
--TURNER        BLAKE
--JAMES         BLAKE
--MILLER        CLARK
--JONES         KING
--BLAKE         KING
--CLARK         KING
--SMITH         FORD

--ANSI
SELECT t1.ename "ENAME"
	  ,t2.ename "MGR_NAME"
FROM emp t1 INNER JOIN emp t2
ON t1.mgr = t2.empno
;
















