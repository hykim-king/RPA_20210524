----OUTER JOIN : 
--한쪽 테이블에는 데이터가 있고 다른쪽에는 데이터가 없는 경우
--데이터가 있는 쪽에 테이블의 내용을 모두 출력.

--ex)student과 professor조인 하여 출력 하세요.
--단 지도 학생이 결정되지 않는 교수들에 이름도 같이 출력 하세요.
col "STU_NAME" for a20
col "PROF_NAME" for a20
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1 RIGHT OUTER JOIN professor t2
ON t1.profno = t2.profno;

--STU_NAME             PROF_NAME
---------------------- --------------------
--James Seo            Audie Murphy
--Billy Crystal        Angela Bassett
--Richard Dreyfus      Angela Bassett
--                     Jessica Lange
--Tim Robbins          Winona Ryder
--Rene Russo           Winona Ryder
--Nicholas Cage        Michelle Pfeiffer
--                     Whoopi Goldberg
--                     Emma Thompson
--Sandra Bullock       Julia Roberts
--                     Sharon Stone
--Demi Moore           Meryl Streep
--Macaulay Culkin      Meryl Streep
--Wesley Snipes        Susan Sarandon
--Danny Glover         Nicole Kidman
--Micheal Keaton       Nicole Kidman
--Steve Martin         Nicole Kidman
--                     Holly Hunter
--                     Meg Ryan
--                     Andie Macdowell
--Daniel Day-Lewis     Jodie Foster
--Bill Murray          Jodie Foster
--
--22 행이 선택되었습니다.