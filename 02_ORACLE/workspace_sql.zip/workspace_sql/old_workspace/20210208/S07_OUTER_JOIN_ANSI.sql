--OUTER JOIN 주의 사항
--1. OUTER JOIN이 되는 컬럼들에 대해서는 전부 아우터 조인 연산자(+)를 붙여야 한다.
--하나라도 누락이 되면 일반 조인과 동일한 결과를 출력하게 된다.

--emp, dept를 조인해서 부서에 대한 정보를 모두 보여 주고, 부서 번호가 20인 사원의 사원번호, 이름 ,급여를 출력.
col ename for a15
col dname for a10
SELECT t2.deptno
      ,t2.dname
      ,t1.empno
	  ,t1.ename
	  ,t1.sal
FROM emp t1	, dept t2
WHERE t1.deptno(+) = t2.deptno
AND   t1.deptno(+) = 20
;
--    DEPTNO DNAME           EMPNO ENAME                  SAL
------------ ---------- ---------- --------------- ----------
--        10 ACCOUNTING
--        20 RESEARCH         7369 SMITH                  800
--        20 RESEARCH         7902 FORD                  3000
--        20 RESEARCH         7566 JONES                 2975
--        30 SALES
--        40 OPERATIONS