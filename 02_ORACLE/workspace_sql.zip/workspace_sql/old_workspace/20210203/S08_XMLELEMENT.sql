--XMLELEMENT: DATA를 xml로 생성
--XMLELEMENT
-- ( [ ENTITYESCAPING | NOENTITYESCAPING ]
--   [ NAME ]
--     { identifier
--     | EVALNAME value_expr
--     }
--   [, XML_attributes_clause ]
--   [, value_expr [ [AS] c_alias ]]...
-- )
col "xml_ename" for a30
SELECT deptno
      ,XMLELEMENT(eclass,',', ename) "xml_ename"
FROM emp;
--    DEPTNO xml_ename
------------ ------------------------------
--        20 <ECLASS>,SMITH</ECLASS>
--        30 <ECLASS>,ALLEN</ECLASS>
--        30 <ECLASS>,WARD</ECLASS>
--        20 <ECLASS>,JONES</ECLASS>
--        30 <ECLASS>,MARTIN</ECLASS>
--        30 <ECLASS>,BLAKE</ECLASS>
--        10 <ECLASS>,CLARK</ECLASS>
--        10 <ECLASS>,KING</ECLASS>
--        30 <ECLASS>,TURNER</ECLASS>
--        30 <ECLASS>,JAMES</ECLASS>
--        20 <ECLASS>,FORD</ECLASS>
--        10 <ECLASS>,MILLER</ECLASS>
--
--12 행이 선택되었습니다.