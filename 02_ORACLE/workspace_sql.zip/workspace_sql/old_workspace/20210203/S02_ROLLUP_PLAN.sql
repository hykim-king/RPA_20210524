explain plan for

--PLAN SQL
SELECT deptno,job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
FROM emp
GROUP BY deptno,job
UNION ALL
SELECT deptno,NULL job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
FROM emp
GROUP BY deptno
UNION ALL
SELECT NULL deptno,NULL job,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
FROM emp
ORDER BY deptno,job
;

09:44:18 SCOTT>col plan_table_output format a80
09:44:54 SCOTT>SELECT * FROM table(dbms_xplan.display);

-----------------------------------------------------------------------------
| Id  | Operation            | Name | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------
|   0 | SELECT STATEMENT     |      |    15 |   190 |    12  (25)| 00:00:01 |
|   1 |  SORT ORDER BY       |      |    15 |   190 |    11  (19)| 00:00:01 |
|   2 |   UNION-ALL          |      |       |       |            |          |
|   3 |    HASH GROUP BY     |      |    11 |   165 |     4  (25)| 00:00:01 |
|   4 |     TABLE ACCESS FULL| EMP  |    12 |   180 |     3   (0)| 00:00:01 |
|   5 |    HASH GROUP BY     |      |     3 |    21 |     4  (25)| 00:00:01 |
|   6 |     TABLE ACCESS FULL| EMP  |    12 |    84 |     3   (0)| 00:00:01 |
|   7 |    SORT AGGREGATE    |      |     1 |     4 |            |          |
|   8 |     TABLE ACCESS FULL| EMP  |    12 |    48 |     3   (0)| 00:00:01 |
-----------------------------------------------------------------------------

4-3-6-5-8-7-2-1-0



