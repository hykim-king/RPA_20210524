explain plan for

SELECT  deptno
		,job
		,AVG( NVL(sal,0)) "AVG",COUNT(*) "COUNT"
FROM emp
GROUP BY ROLLUP(deptno,job)
;


col plan_table_output format a80
SELECT * FROM table(dbms_xplan.display);

--PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------
--Plan hash value: 52302870
--
-------------------------------------------------------------------------------
--| Id  | Operation            | Name | Rows  | Bytes | Cost (%CPU)| Time     |
-------------------------------------------------------------------------------
--|   0 | SELECT STATEMENT     |      |    11 |   165 |     4  (25)| 00:00:01 |
--|   1 |  SORT GROUP BY ROLLUP|      |    11 |   165 |     4  (25)| 00:00:01 |
--|   2 |   TABLE ACCESS FULL  | EMP  |    12 |   180 |     3   (0)| 00:00:01 |
-------------------------------------------------------------------------------