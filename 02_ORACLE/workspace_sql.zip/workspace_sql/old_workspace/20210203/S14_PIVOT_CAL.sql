--SELECT MAX(DECODE(day,'SUN',dayno,NULL)) "SUN"
--	  ,MAX(DECODE(day,'MON',dayno,NULL))   "MON"
--	  ,MAX(DECODE(day,'TUE',dayno,NULL))   "TUE"
--	  ,MAX(DECODE(day,'WED',dayno,NULL))   "WED"
--	  ,MAX(DECODE(day,'THU',dayno,NULL))   "THU"
--	  ,MAX(DECODE(day,'FRI',dayno,NULL))   "FRI"
--	  ,MAX(DECODE(day,'SAT',dayno,NULL))   "SAT"
--FROM cal
--GROUP BY weekno
--ORDER BY weekno
--;

--PIVOT()함수  : 11g
--열을 행으로 ROW형태의 데이터를 COLUMN(UNPIVOT)으로 보여주는 쿼리
--컬럼 값을 기준으로 새로운 컬럼을 도출하여 다양한 집계함수를 적용 가능.
--
--SELECT * FROM (SELECT year,month FROM tb_pivot)
--PIVOT(
--PIVOT절 : 그룹 함수 적용된 컬럼  MAX(month)
--PIVOT FOR절: 피봇에 기준이 되는 컬럼 FOR month
--IN() : PIVOT FOR에서 정의한 컬럼 필터링 1 AS M01
--
--);

SELECT * FROM (SELECT weekno "WEEK",day,dayno FROM cal)
PIVOT(	MAX(dayno) FOR day IN ( 
                                 'SUN' AS "SUN"
								,'MON' AS "MON"
								,'TUE' AS "TUE"
								,'WED' AS "WED"
								,'THU' AS "THU"
								,'FRI' AS "FRI"
								,'SAT' AS "SAT"
                              )	
)
ORDER BY "WEEK"
;

















