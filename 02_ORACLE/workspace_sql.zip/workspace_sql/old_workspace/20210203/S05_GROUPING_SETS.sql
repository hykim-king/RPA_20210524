--그룹핑 조건이 여러 개일 경우 유용하게 사용될수 있다.
--GROUPING SETS(expr1,expr2,expr3...)
--학년별로 학생들의 인원수,학과별로 인수원수

--SELECT grade
--      ,COUNT(*)
--FROM student
--GROUP BY grade
--UNION ALL
--SELECT deptno1 
--      ,COUNT(*)
--FROM student
--GROUP BY deptno1;
--
--     GRADE   COUNT(*)
------------ ----------
--         1          5
--         2          5
--         4          5
--         3          5
--       101          4
--       103          2
--       202          2
--       301          2
--       201          6
--       102          4
--
--10 행이 선택되었습니다.

SELECT grade
      ,deptno1
      ,COUNT(*)
FROM student
GROUP BY GROUPING SETS(grade,deptno1)
;
--10:32:34 SCOTT>@S05_GROUPING_SETS.sql
--
--     GRADE    DEPTNO1   COUNT(*)
------------ ---------- ----------
--         1                     5
--         2                     5
--         4                     5
--         3                     5
--                  102          4
--                  201          6
--                  301          2
--                  202          2
--                  101          4
--                  103          2
--
--10 행이 선택되었습니다.










