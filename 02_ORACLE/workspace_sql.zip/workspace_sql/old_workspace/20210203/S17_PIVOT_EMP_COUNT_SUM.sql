--PIVOT()함수  : 11g
--열을 행으로 ROW형태의 데이터를 COLUMN(UNPIVOT)으로 보여주는 쿼리
--컬럼 값을 기준으로 새로운 컬럼을 도출하여 다양한 집계함수를 적용 가능.
--
--SELECT * FROM (SELECT year,month FROM tb_pivot)
--PIVOT(
--PIVOT절 : 그룹 함수 적용된 컬럼  MAX(month)
--PIVOT FOR절: 피봇에 기준이 되는 컬럼 FOR month
--IN() : PIVOT FOR에서 정의한 컬럼 필터링 1 AS M01
--
--);

COL "CLERK"     FOR 99999
COL "SALESMAN"  FOR 99999  
COL "ANALYST"   FOR 99999
COL "MANAGER"   FOR 99999
COL "PRESIDENT" FOR 99999

SELECT * FROM (SELECT deptno,job,empno,sal FROM emp)
PIVOT(
		COUNT(empno) AS CNT,
		SUM(sal)     AS sum   FOR job IN (
						'CLERK'   	AS 	"CL"
						,'SALESMAN' AS  "SA" 
						,'ANALYST'  AS  "AN"  
						,'MANAGER'  AS  "MA"  
						,'PRESIDENT'AS 	"PR"
		)
)
ORDER BY deptno
;

--    DEPTNO     CL_CNT     CL_SUM     SA_CNT     SA_SUM     AN_CNT     AN_SUM     MA_CNT     MA_SUM     PR_CNT     PR_SUM
------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------
--        10          1       1300          0                     0                     1       2450          1       5000
--        20          1        800          0                     1       3000          1       2975          0
--        30          1        950          4       5600          0                     1       2850          0