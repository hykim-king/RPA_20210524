--XMLAGG()함수 : 11g
--LISTAGG() RETURN 데이터 4000BYTE를 개선한 함수
--XMLAGG(XMLType_instance [ order_by_clause ])
--
--XMLELEMENT: DATA를 xml로 생성
--XMLELEMENT
-- ( [ ENTITYESCAPING | NOENTITYESCAPING ]
--   [ NAME ]
--     { identifier
--     | EVALNAME value_expr
--     }
--   [, XML_attributes_clause ]
--   [, value_expr [ [AS] c_alias ]]...
-- )
--
COL "DEPT_ENAME_LIST"   FOR a80
SELECT deptno
      ,SUBSTR(	XMLAGG(XMLELEMENT(X,',',ename) ORDER BY hiredate)
	              .EXTRACT('//text()').getStringVal(),2)   "DEPT_ENAME_LIST"
FROM emp
GROUP BY deptno;

--    DEPTNO DEPT_ENAME_LIST
------------ --------------------------------------------------------------------------------
--        10 <X>,CLARK</X><X>,KING</X><X>,MILLER</X>
--        20 <X>,SMITH</X><X>,JONES</X><X>,FORD</X>
--        30 <X>,ALLEN</X><X>,WARD</X><X>,BLAKE</X><X>,TURNER</X><X>,MARTIN</X><X>,JAMES</X>
--
--11:27:54 SCOTT>@S09_XMLEGG.sql
--
--    DEPTNO DEPT_ENAME_LIST
------------ --------------------------------------------------------------------------------
--        10 ,CLARK,KING,MILLER
--        20 ,SMITH,JONES,FORD
--        30 ,ALLEN,WARD,BLAKE,TURNER,MARTIN,JAMES
--
--11:29:22 SCOTT>@S09_XMLEGG.sql
--
--    DEPTNO DEPT_ENAME_LIST
------------ --------------------------------------------------------------------------------
--        10 CLARK,KING,MILLER
--        20 SMITH,JONES,FORD
--        30 ALLEN,WARD,BLAKE,TURNER,MARTIN,JAMES