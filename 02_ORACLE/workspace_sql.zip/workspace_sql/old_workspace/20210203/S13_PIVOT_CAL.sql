--SELECT *
--FROM cal;
--weekno VARCHAR2(1)
--day    VARCHAR2(5)
--dayno  VARCHAR2(2)
--desc cal;

--SELECT ASCII('1')
--      ,ASCII('8')
--      ,ASCII('15')	  
--      ,ASCII('22')	
--      ,ASCII('29')	  
--FROM dual;

--문자 첫자만 연산이 된다.

--ASCII('1') ASCII('8') ASCII('15') ASCII('22') ASCII('29')
------------ ---------- ----------- ----------- -----------
--        49         56          49          50          50
		


SELECT MAX(DECODE(day,'SUN',dayno,NULL)) "SUN"
	  ,MAX(DECODE(day,'MON',dayno,NULL)) "MON"
	  ,MAX(DECODE(day,'TUE',dayno,NULL)) "TUE"
	  ,MAX(DECODE(day,'WED',dayno,NULL)) "WED"
	  ,MAX(DECODE(day,'THU',dayno,NULL)) "THU"
	  ,MAX(DECODE(day,'FRI',dayno,NULL)) "FRI"
	  ,MAX(DECODE(day,'SAT',dayno,NULL)) "SAT"
FROM cal
GROUP BY weekno
ORDER BY weekno
;

--WE DAY        DAYN
---- ---------- ----
--1  SUN        1
--1  MON        2
--1  TUE        3
--1  WED        4
--1  THU        5
--1  FRI        6
--1  SAT        7
--2  SUN        8
--2  MON        9
--2  TUE        10
--2  WED        11
--2  THU        12
--2  FRI        13
--2  SAT        14
--3  SUN        15
--3  MON        16
--3  TUE        17
--3  WED        18
--3  THU        19
--3  FRI        20
--3  SAT        21
--4  SUN        22
--4  MON        23
--4  TUE        24
--4  WED        25
--4  THU        26
--4  FRI        27
--4  SAT        28
--5  SUN        29
--5  MON        30
--5  TUE        31


--15:34:21 SCOTT>@S13_PIVOT_CAL.sql
--
--SUN  MON  TUE  WED  THU  FRI  SAT
------ ---- ---- ---- ---- ---- ----
--8    9    31   4    5    6    7


--SUN  MON  TUE  WED  THU  FRI  SAT
------ ---- ---- ---- ---- ---- ----
--1    2    3    4    5    6    7
--8    9    10   11   12   13   14
--15   16   17   18   19   20   21
--22   23   24   25   26   27   28
--29   30   31