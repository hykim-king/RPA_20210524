--PIVOT()함수  : 11g
--열을 행으로 ROW형태의 데이터를 COLUMN(UNPIVOT)으로 보여주는 쿼리
--컬럼 값을 기준으로 새로운 컬럼을 도출하여 다양한 집계함수를 적용 가능.
--
--SELECT * FROM (SELECT year,month FROM tb_pivot)
--PIVOT(
--PIVOT절 : 그룹 함수 적용된 컬럼  MAX(month)
--PIVOT FOR절: 피봇에 기준이 되는 컬럼 FOR month
--IN() : PIVOT FOR에서 정의한 컬럼 필터링 1 AS M01
--
--);

--EMP 테이블에서 부서별로 각 직급별 인원이 명명인지

--SELECT *
--FROM emp;
-- job       deptno
-- --------- 
-- CLERK         20
-- SALESMAN      30
-- SALESMAN      30
-- MANAGER       20
-- SALESMAN      30
-- MANAGER       30
-- MANAGER       10
-- PRESIDENT     10
-- SALESMAN      30
-- CLERK         30
-- ANALYST       20
-- CLERK         10
--
--12 행이 선택되었습니다.

--job을 중복되지 않게 추출
--SELECT job
--FROM emp
--GROUP BY job;

--CLERK
--SALESMAN
--ANALYST
--MANAGER
--PRESIDENT

COL "CLERK"     FOR 99999
COL "SALESMAN"  FOR 99999  
COL "ANALYST"   FOR 99999
COL "MANAGER"   FOR 99999
COL "PRESIDENT" FOR 99999

SELECT deptno
	  ,COUNT(DECODE(job,'CLERK','1') 	)	"CLERK"
      ,COUNT(DECODE(job,'SALESMAN','1') )	"SALESMAN"
	  ,COUNT(DECODE(job,'ANALYST','1') 	)	"ANALYST"
	  ,COUNT(DECODE(job,'MANAGER','1') 	)	"MANAGER"
	  ,COUNT(DECODE(job,'PRESIDENT','1')) 	"PRESIDENT"
FROM emp
GROUP BY deptno
ORDER BY deptno
;

--    DEPTNO  CLERK SALESMAN ANALYST MANAGER PRESIDENT
------------ ------ -------- ------- ------- ---------
--        10      1        0       0       1         1
--        20      1        0       1       1         0
--        30      1        4       0       1         0








