--SCOTT>conn /as sysdba
--sys>
--ed scott_plant_config.sql

--role plustrace생성
--ALTER SESSION SET "_ORACLE_SCRIPT"=true;


--1.plustrace 권한 생성
--@C:\app\sist\product\18.0.0\dbhomeXE\sqlplus\admin\plustrce.sql

--SCOTT,HR
--GRANT plustrace to scott;
--GRANT plustrace to hr;

--2.plan table생성
@C:\app\sist\product\18.0.0\dbhomeXE\rdbms\admin\utlxplan.sql
