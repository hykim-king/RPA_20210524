explain plan for
SELECT deptno
      ,NULL job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
GROUP BY deptno
UNION ALL
SELECT NULL deptno
      ,job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
GROUP BY job
UNION ALL
SELECT deptno
      ,job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
GROUP BY deptno,job
UNION ALL
SELECT NULL deptno
      ,NULL job
      ,ROUND(AVG(NVL(sal,0)),1) "AVG_SAL"
	  ,COUNT(*)
FROM emp
ORDER BY deptno,job;


col plan_table_output format a80
SELECT * FROM table(dbms_xplan.display);


PLAN_TABLE_OUTPUT
--------------------------------------------------------------------------------
Plan hash value: 4172172844

-----------------------------------------------------------------------------
| Id  | Operation            | Name | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------
|   0 | SELECT STATEMENT     |      |    20 |   250 |    16  (25)| 00:00:01 |
|   1 |  SORT ORDER BY       |      |    20 |   250 |    15  (20)| 00:00:01 |
|   2 |   UNION-ALL          |      |       |       |            |          |
|   3 |    HASH GROUP BY     |      |     3 |    21 |     4  (25)| 00:00:01 |
|   4 |     TABLE ACCESS FULL| EMP  |    12 |    84 |     3   (0)| 00:00:01 |
|   5 |    HASH GROUP BY     |      |     5 |    60 |     4  (25)| 00:00:01 |
|   6 |     TABLE ACCESS FULL| EMP  |    12 |   144 |     3   (0)| 00:00:01 |
|   7 |    HASH GROUP BY     |      |    11 |   165 |     4  (25)| 00:00:01 |
|   8 |     TABLE ACCESS FULL| EMP  |    12 |   180 |     3   (0)| 00:00:01 |
|   9 |    SORT AGGREGATE    |      |     1 |     4 |            |          |
|  10 |     TABLE ACCESS FULL| EMP  |    12 |    48 |     3   (0)| 00:00:01 |
-----------------------------------------------------------------------------

17 행이 선택되었습니다.