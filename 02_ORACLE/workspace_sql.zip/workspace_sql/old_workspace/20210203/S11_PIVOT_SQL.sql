COL M01 FOR 99
COL M02 FOR 99
COL M03 FOR 99
COL M04 FOR 99
COL M05 FOR 99
COL M06 FOR 99
COL M07 FOR 99
COL M08 FOR 99
COL M09 FOR 99
COL M10 FOR 99
COL M11 FOR 99
COL M12 FOR 99

SELECT year
      ,MAX(DECODE(month, 1,month,NULL)) M01
      ,MAX(DECODE(month, 2,month,NULL)) M02
	  ,MAX(DECODE(month, 3,month,NULL)) M03
	  ,MAX(DECODE(month, 4,month,NULL)) M04
	  ,MAX(DECODE(month, 5,month,NULL)) M05
	  ,MAX(DECODE(month, 6,month,NULL)) M06
	  ,MAX(DECODE(month, 7,month,NULL)) M07
	  ,MAX(DECODE(month, 8,month,NULL)) M08
	  ,MAX(DECODE(month, 9,month,NULL)) M09
	  ,MAX(DECODE(month,10,month,NULL)) M10
	  ,MAX(DECODE(month,11,month,NULL)) M11
	  ,MAX(DECODE(month,12,month,NULL)) M12
FROM tb_pivot
GROUP BY year;

--15:09:05 SCOTT>@S11_PIVOT_SQL.sql
--
--       M01        M02        M03        M04        M05        M06        M07        M08        M09        M10        M11        M12
------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------
--         1
--                    2
--                               3
--                                          4
--                                                     5
--                                                                6
--                                                                           7
--                                                                                      8
--                                                                                                 9
--                                                                                                           10
--                                                                                                                      11
--                                                                                                                                 12
--
--12 행이 선택되었습니다.
--
--15:10:43 SCOTT>@S11_PIVOT_SQL.sql
--
--       M01        M02        M03        M04        M05        M06        M07        M08        M09        M10        M11        M12
------------ ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------
--         1          2          3          4          5          6          7          8          9         10         11         12
--
--15:12:50 SCOTT>@S11_PIVOT_SQL.sql
--
--YEAR     M01 M02 M03 M04 M05 M06 M07 M08 M09 M10 M11 M12
---------- --- --- --- --- --- --- --- --- --- --- --- ---
--2021       1   2   3   4   5   6   7   8   9  10  11  12
