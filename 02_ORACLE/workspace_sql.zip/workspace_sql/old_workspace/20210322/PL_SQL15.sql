DECLARE
	--정의
	TYPE tbl_emp_name IS TABLE OF
		employees.first_name%TYPE
		INDEX BY BINARY_INTEGER;
	--선언부
	v_name tbl_emp_name;
	t_name VARCHAR2(20);
BEGIN
	SELECT first_name 
	INTO t_name
	FROM employees
	WHERE employee_id =180;
	
	v_name(0) := t_name;
	DBMS_OUTPUT.PUT_LINE(v_name(0));
END;
/
--윈스턴