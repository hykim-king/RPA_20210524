--PL/SQL

--DECLARE : 선어부(변수,상수)

--BEGIN : 실행부(제어,반복문,함수 등의 로직)

--EXCEPTION: 예외처리

--한줄 주석: --
--여러줄 주석: /* */



--employees 테이블에서 employee id 200번인 사원의 이름과 사번을 출력.

--화면에 출력기능 켜기.
SET SERVEROUTPUT ON;

DECLARE
	vno  NUMBER(6);
	vname VARCHAR2(20);
	
BEGIN
	SELECT employee_id,first_name
		   INTO vno,vname
	FROM employees
	WHERE employee_id = 200;

	DBMS_OUTPUT.PUT_LINE(vno ||','|| vname );

END;
/	