--SELECT * FROM pl_test;
--
--        NO NAME
------------ --------------------
--         1 AAA
--         2 AAA

--2 AAA를 BBB로 UPDATE처리
--DECLARE
--
--BEGIN
--	UPDATE pl_test
--	SET name = 'BBB'
--	WHERE  NO = 2; 
--END;
--/

SELECT * FROM pl_test;
COMMIT;