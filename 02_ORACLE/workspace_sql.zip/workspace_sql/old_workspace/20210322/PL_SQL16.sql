DECLARE
	--정의
	TYPE tbl_emp_name IS TABLE OF
		employees.first_name%TYPE
		INDEX BY BINARY_INTEGER;
	--선언부
	v_name tbl_emp_name;

	--INDEX 
	a BINARY_INTEGER :=0;
BEGIN
    --이름을 v_name에 index로 별로 할당!
	FOR  i  IN (SELECT first_name FROM employees) LOOP
	    a:=a+1;
		v_name(a) := i.first_name;
	END LOOP;

    --이름을 v_name에 index로 별로 출력
	FOR  j  IN 1..a  LOOP
		DBMS_OUTPUT.PUT_LINE( j||'. '||v_name(j));
	END LOOP;

END;
/
