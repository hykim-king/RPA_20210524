--PL/SQL DML

--TABLE생성
--CREATE TABLE pl_test(
--	no NUMBER,
--	name VARCHAR2(10 BYTE)
--);

--SEQUENCE생성

--CREATE SEQUENCE pl_seq;

DECLARE

BEGIN
	INSERT INTO pl_test VALUES (pl_seq.NEXTVAL,'AAA');
END;
/

--09:43:13 HR>select * from pl_test;
--
--        NO NAME
------------ --------------------
--         1 AAA
--         2 AAA