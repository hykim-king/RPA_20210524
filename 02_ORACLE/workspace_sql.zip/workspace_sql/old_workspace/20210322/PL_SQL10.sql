--참조 변수를 통한 데이터 조회
--CTAS를 통해 employees3 생성

--SELECT employee_id,
--       first_name,
--	   salary
--FROM employees;

--CREATE TABLE employees3
--AS
--SELECT employee_id,
--       first_name,
--	   salary
--FROM employees;

--SELECT *
--FROM employees3;
--180 윈스턴                                         3200
DECLARE
	v_no   employees3.employee_id%TYPE;
	v_name employees3.first_name%TYPE;
	v_sal  employees3.salary%TYPE;
BEGIN
	SELECT employee_id,first_name,salary
	       INTO  v_no,v_name,v_sal
	FROM employees3
	WHERE employee_id = 180;
    
	DBMS_OUTPUT.PUT_LINE(v_no ||'----'|| v_name  ||'----'|| v_sal);
END;
/
--11:17:31 HR>@PL_SQL10.sql
--180----윈스턴----3200











