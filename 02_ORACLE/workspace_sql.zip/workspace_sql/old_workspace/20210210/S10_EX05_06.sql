ALTER TABLE new_emp2
MODIFY (NO number(7));