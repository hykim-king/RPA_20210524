--CTAS
CREATE TABLE new_emp2
AS
SELECT no,
       name,
	   hiredate
FROM new_emp
;