--CTAS
CREATE TABLE new_emp3
AS
SELECT no,
       name,
	   hiredate
FROM new_emp
WHERE 1=2
;