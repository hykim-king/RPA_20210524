-NVL(컬럼,치환값):NULL값을 만나면 치환값으로 출력
SELECT ename
      ,comm
	  ,NVL(comm,0) "NVL"
	  ,NVL(comm,200) "NVL_200"
	  ,comm*10
FROM emp
WHERE deptno =30;
;

--ENAME                      COMM        NVL    NVL_200    COMM*10
---------------------- ---------- ---------- ---------- ----------
--ALLEN                       300        300        300       3000
--WARD                        500        500        500       5000
--MARTIN                     1400       1400       1400      14000
--BLAKE                                    0        200
--TURNER                        0          0          0          0
--JAMES                                    0        200