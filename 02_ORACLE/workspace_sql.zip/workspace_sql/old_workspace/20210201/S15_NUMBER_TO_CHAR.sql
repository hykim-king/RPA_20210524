--TO_CHAR(숫자->문자로)													
--종류명					의미												
--9					9의 개수만큼 자릿수 TO_CHAR(1234,'9999')   1234		
--0					빈자리를 0으로 채움 TO_CHAR(1234,'009999')   001234	
--$					$표시를 붙여 출력 TO_CHAR(1234,'$9999') $1234			
--,					천 단위 구분 기호 TO_CHAR(1234,'99,999') 1,234		
--.					소수점 이하를 표시 TO_CHAR(1234,'99999.99') 1234.00	
--select *
--from (
--	select *
--	from 
--		(
--		SELECT *
--		FROM DUAAL
--		)
--)


SELECT name     				
      ,pay      				
      ,bonus    				
      ,TO_CHAR((pay*12)+bonus,'99,999') "TOTAL" 
FROM professor
WHERE deptno =201;
--NAME                        PAY      BONUS TOTAL
---------------------- ---------- ---------- --------------
--Meryl Streep                570        130   6,970
--Susan Sarandon              330

