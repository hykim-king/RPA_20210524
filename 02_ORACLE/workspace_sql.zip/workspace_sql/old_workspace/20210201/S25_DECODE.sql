--DECODE(A,B,1
--        ,C,2
--		  ,3) : IF ELSE IF ELSE
--IF(A==B) 		1
--ELSE IF(A==C) 2
--ELSE 			3

SELECT name     
      ,deptno   
	  ,DECODE(deptno,101,'Computer Engineering'
	                ,102,'Multimedia Engineering'
					,103,'Software Engineering', 'ETC') "DNAME"
FROM professor
;