--TO_CHAR(날짜->문자로)
--TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS')
SELECT SYSDATE
      ,TO_CHAR(SYSDATE,'YYYY') "TO_CHAR_YEAR"
	  ,TO_CHAR(SYSDATE,'RR') "TO_CHAR_YEAR"
	  ,TO_CHAR(SYSDATE,'MM') "TO_CHAR_MM"
	  ,TO_CHAR(SYSDATE,'DD') "TO_CHAR_DD"
	  ,TO_CHAR(SYSDATE,'YYYY/MM/DD HH24:MI:SS') "TO_CHAR_TOTAL"
	  ,TO_CHAR(SYSDATE,'YYYY-MM-DD HH24:MI:SS') "TO_CHAR_TOTAL"
FROM dual
;
SYSDATE             TO_CHAR_ TO_C TO_C TO_C TO_CHAR_TOTAL         TO_CHAR_TOTAL
------------------- -------- ---- ---- ---- -------------------------------------- --------------------------------------
2021-02-01:10:42:31 2021     21   02   01   2021/02/01 10:42:31   2021-02-01 10:42:31