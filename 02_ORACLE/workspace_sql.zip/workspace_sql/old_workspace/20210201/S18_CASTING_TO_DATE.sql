--TO_DATE(날짜문자를 날짜로)
--		날짜처럼 생긴 문자를 날짜로

SELECT LAST_DAY( TO_DATE('20210201') )
FROM dual
;