SELECT ename
      ,empno
	  ,sal
	  ,comm
	  ,NVL2(comm,sal*comm,sal*0) "NVL2"
FROM emp
WHERE deptno =30
;

--comm값이 null :sal*0
--comm값이 not null :sal*comm

--NVL2(COL1,COL2,COL3):COL1 NULL이면 COL3를 NULL이 아니면 COL2
--ENAME                     EMPNO        SAL       COMM       NVL2
---------------------- ---------- ---------- ---------- ----------
--ALLEN                      7499       1600        300     480000
--WARD                       7521       1250        500     625000
--MARTIN                     7654       1250       1400    1750000
--BLAKE                      7698       2850                     0
--TURNER                     7844       1500          0          0
--JAMES                      7900        950                     0
--
--6 행이 선택되었습니다.