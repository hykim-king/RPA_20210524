SELECT 11+'a'
FROM dual;
--1행에 오류:
--ORA-01722: 수치가 부적합합니다