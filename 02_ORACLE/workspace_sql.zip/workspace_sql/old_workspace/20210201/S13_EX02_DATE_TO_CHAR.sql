SELECT empno
      ,ename
	  ,TO_CHAR(hiredate,'YY/MM/DD') hiredate
FROM emp
WHERE TO_CHAR(hiredate,'MM') IN ('01','02','03')
;
--     EMPNO ENAME                HIREDATE
------------ -------------------- ----------------
--      7499 ALLEN                81/02/20
--      7521 WARD                 81/02/22
--      7934 MILLER               82/01/23