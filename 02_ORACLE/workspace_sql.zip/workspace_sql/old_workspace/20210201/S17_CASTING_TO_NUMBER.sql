--TO_NUMBER(숫자형 문자를 숫자로 바꾸어 주는 함수)
--SELECT TO_NUMBER('11')
--FROM dual;

--SELECT TO_NUMBER('A')
--FROM dual;
--1행에 오류:
--ORA-01722: 수치가 부적합합니다

--ASCII 코드로 변환
--SELECT ASCII('A')
--FROM dual;
--ASCII('A')
------------
--        65

--ASCII를 문자로 변환
SELECT CHR(65)
FROM dual;
--CH
----
--A