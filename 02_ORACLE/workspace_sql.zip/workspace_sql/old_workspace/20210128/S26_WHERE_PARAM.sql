--사용자에게 조건을 입력 받아서 
--출력 :&변수명

SELECT ename
      ,empno
      ,hiredate
	  ,sal
	  ,comm
	  ,&age *8 AS age
FROM emp
WHERE empno =&empno
;
--ENAME                     EMPNO HIREDATE        SAL       COMM        AGE
---------------------- ---------- -------- ---------- ---------- ----------
--SMITH                      7369 80/12/17        800                    88