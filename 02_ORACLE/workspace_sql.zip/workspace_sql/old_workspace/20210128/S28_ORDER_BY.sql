--주의사항: 최대한 ORDER BY는 사용하지 마세요.(인덱스)
--정열하여 출력 하기: ORDER BY 컬럼,컬럼
--정열하여 출력 하기: ORDER BY 1 ASC,2 DESC

--DEFAULT는 ASC
--한글:가,나,다..
--영어:A,B,C..Z
--숫자:1,2,3,...
--날짜:예전 날짜 부터 .... 최근 날짜로 정열

--database파일 저장 위치
--C:\app\sist\product\18.0.0\oradata\XE\USERS01.DBF
SELECT deptno
      ,ename
      ,sal
	  ,hiredate
FROM emp
ORDER BY deptno DESC,ename ASC
;
--15:36:16 SCOTT>@S28_ORDER_BY.sql
--
--    DEPTNO ENAME                       SAL HIREDATE
------------ -------------------- ---------- --------
--        30 ALLEN                      1600 81/02/20
--        30 BLAKE                      2850 81/05/01
--        30 JAMES                       950 81/12/03
--        30 MARTIN                     1250 81/09/28
--        30 TURNER                     1500 81/09/08
--        30 WARD                       1250 81/02/22
--        20 FORD                       3000 81/12/03
--        20 JONES                      2975 81/04/02
--        20 SMITH                       800 80/12/17
--        10 CLARK                      2450 81/06/09
--        10 KING                       5000 81/11/17
--        10 MILLER                     1300 82/01/23
--
--12 행이 선택되었습니다.