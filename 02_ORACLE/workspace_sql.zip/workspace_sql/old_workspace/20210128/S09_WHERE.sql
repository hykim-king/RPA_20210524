--SQL에서 산술연산자:+,-,/,*															
SELECT ename
      ,sal
	  ,sal+100
	  ,sal*1.1
FROM emp
WHERE deptno =10
;
--ENAME                       SAL    SAL+100    SAL*1.1
---------------------- ---------- ---------- ----------
--CLARK                      2450       2550       2695
--KING                       5000       5100       5500
--MILLER                     1300       1400       1430