--문자와 날짜는 반드시 작은 따옴표를 붙여야 한다.
--문자는 대소문자를 구분한다.
SELECT ename
      ,hiredate
FROM emp
WHERE ename ='SMITH'
;	  

