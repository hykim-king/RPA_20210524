--검색조건이 두개 이상
--AND, OR
--AND,OR가 동시에 나오면 우선순위는 AND가 먼저 수행!.

--SELECT ename
--      ,hiredate
--	  ,sal
--	  ,comm
--FROM emp
--WHERE sal>1000
--AND (comm < 1000 OR comm is NULL)
--;
--ENAME                HIREDATE        SAL       COMM
---------------------- -------- ---------- ----------
--ALLEN                81/02/20       1600        300
--WARD                 81/02/22       1250        500
--JONES                81/04/02       2975
--BLAKE                81/05/01       2850
--CLARK                81/06/09       2450
--KING                 81/11/17       5000
--TURNER               81/09/08       1500          0
--FORD                 81/12/03       3000
--MILLER               82/01/23       1300
--
--9 행이 선택되었습니다.

SELECT ename
      ,hiredate
	  ,sal
	  ,comm
FROM emp
WHERE sal>1000
AND comm < 1000 OR comm is NULL
;
--ENAME                HIREDATE        SAL       COMM
---------------------- -------- ---------- ----------
--SMITH                80/12/17        800
--ALLEN                81/02/20       1600        300
--WARD                 81/02/22       1250        500
--JONES                81/04/02       2975
--BLAKE                81/05/01       2850
--CLARK                81/06/09       2450
--KING                 81/11/17       5000
--TURNER               81/09/08       1500          0
--JAMES                81/12/03        950
--FORD                 81/12/03       3000
--MILLER               82/01/23       1300
--
--11 행이 선택되었습니다.


