--연결연산자: ||															
--	컬럼을 붙여서 출력														
SELECT ename ||' ''s job is '||job AS "NAME AND JOB"
FROM emp;

--NAME AND JOB
--------------------------------------------------------------
--SMITH 's job is CLERK
--ALLEN 's job is SALESMAN
--WARD 's job is SALESMAN
--JONES 's job is MANAGER
--MARTIN 's job is SALESMAN
--BLAKE 's job is MANAGER
--CLARK 's job is MANAGER
--KING 's job is PRESIDENT
--TURNER 's job is SALESMAN
--JAMES 's job is CLERK
--FORD 's job is ANALYST
--MILLER 's job is CLERK
--
--12 행이 선택되었습니다.