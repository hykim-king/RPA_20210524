--집합 연산자
--UNION       두 집합의 결과를 합쳐서 출력, 중복 값 제거하고 출력:u + 정렬
--UNION ALL   두 집합의 결과를 합쳐서 출력, 중복 값 제거하지 않고 출력:u
--INTERSECT   두 집합의 교집함 출력
--MINUS       두 집합의 차집합

--집합 연산자 사용 조건
--1. 두 집합의 SELECT 절에 오는 컬럼수 동일
--2. 두 집합의 SELECT 절에 오는 데이터형 동일
--3. 두 집합의 SELECT 절에 오는 컬럼명을 달라도 상관 없다.
SELECT studno,name,deptno1,1 				
FROM student
WHERE deptno1=101
UNION
SELECT  profno,name,deptno,2
FROM professor
WHERE deptno =101
;
--    NUMBER VARCHAR2                                    NUMBER
--    STUDNO NAME                                        DEPTNO1
------------ ------------------------------------------ --------
--      9411 James Seo                                       101
--      9511 Billy Crystal                                   101
--      9611 Richard Dreyfus                                 101
--      9711 Danny Devito	                                 101
--	  
--    PROFNO NAME                                         DEPTNO
------------ ---------------------------------------- ----------
--      1001 Audie Murphy                                    101
--      1002 Angela Bassett                                  101
--      1003 Jessica Lange                                   101
	  
--    STUDNO NAME                                                            DEPTNO1          1
------------ ------------------------------------------------------------ ---------- ----------
--      1001 Audie Murphy                                                        101          2
--      1002 Angela Bassett                                                      101          2
--      1003 Jessica Lange                                                       101          2
--      9411 James Seo                                                           101          1
--      9511 Billy Crystal                                                       101          1
--      9611 Richard Dreyfus                                                     101          1
--      9711 Danny Devito                                                        101          1