--like 문자
--ename이 A로 시작하는 모든 사람.
SELECT empno
      ,ename
	  ,sal
FROM emp
WHERE ename LIKE 'A%'
;
--     EMPNO ENAME                       SAL
------------ -------------------- ----------
--      7499 ALLEN                      1600
--
--1개의 행이 선택되었습니다.