--DESC user_sequences;
--COL  sequence_name FOR A15
--SELECT sequence_name
--	,min_value
--	,max_value
--	,increment_by
--	,cycle_flag
--	,order_flag
--	,cache_size
--	,last_number	
--FROM user_sequences
--WHERE sequence_name ='JNO_SEQ';	

--SEQUENCE_NAME    MIN_VALUE  MAX_VALUE INCREMENT_BY CY OR CACHE_SIZE LAST_NUMBER
----------------- ---------- ---------- ------------ -- -- ---------- -----------
--JNO_SEQ                 90        110            1 Y  N           2          92


--SEQUENCE DROP;
DROP SEQUENCE jno_seq;
--시퀀스가 삭제되었습니다.
--
--경   과: 00:00:00.13