ALTER TABLE MENU
	DROP
		PRIMARY KEY
		CASCADE
		KEEP INDEX;

DROP INDEX PK_MENU;

/* 메뉴 */
DROP TABLE MENU 
	CASCADE CONSTRAINTS;

/* 메뉴 */
CREATE TABLE MENU (
	메뉴아이디 VARCHAR2(20 BYTE) NOT NULL, /* MENU_ID */
	메뉴명 VARCHAR2(100 BYTE), /* MENU_NM */
	URL VARCHAR2(200 BYTE), /* URL */
	상위메뉴 VARCHAR2(20 BYTE), /* PARENT_ID */
	순번 NUMBER(3), /* SEQ */
	REG_ID VARCHAR2(12 BYTE), /* 등록자 */
	REG_DT DATE DEFAULT SYSDATE, /* 등록일 */
	MOD_ID VARCHAR2(12 BYTE), /* 수정자 */
	MOD_DT DATE DEFAULT SYSDATE /* 수정일 */
);

COMMENT ON TABLE MENU IS '메뉴';

COMMENT ON COLUMN MENU.메뉴아이디 IS 'MENU_ID';

COMMENT ON COLUMN MENU.메뉴명 IS 'MENU_NM';

COMMENT ON COLUMN MENU.URL IS 'URL';

COMMENT ON COLUMN MENU.상위메뉴 IS 'PARENT_ID';

COMMENT ON COLUMN MENU.순번 IS 'SEQ';

COMMENT ON COLUMN MENU.REG_ID IS '등록자';

COMMENT ON COLUMN MENU.REG_DT IS '등록일';

COMMENT ON COLUMN MENU.MOD_ID IS '수정자';

COMMENT ON COLUMN MENU.MOD_DT IS '수정일';

CREATE UNIQUE INDEX PK_MENU
	ON MENU (
		메뉴아이디 ASC
	);

ALTER TABLE MENU
	ADD
		CONSTRAINT PK_MENU
		PRIMARY KEY (
			메뉴아이디
		);

--메뉴아이디, 메뉴명, URL, 상위메뉴, 순번, REG_ID, REG_DT, MOD_ID, MOD_DT
INSERT INTO MENU VALUES ('MEMBER_01','회원관리','http://localhost;8080/WEB_H01/member/member_list.jsp'     ,NULL     ,1,'admin',sysdate,'admin',sysdate);			
INSERT INTO MENU VALUES ('BOARD_10' ,'공지사항','http://localhost;8080/WEB_H01/board/board_list.jsp?div=10','MEMBER_01',2,'admin',sysdate,'admin',sysdate);			
INSERT INTO MENU VALUES ('BOARD_20' ,'게시판' ,'http://localhost;8080/WEB_H01/board/board_list.jsp?div=20','BOARD_10'	 ,3,'admin',sysdate,'admin',sysdate);

commit;		

