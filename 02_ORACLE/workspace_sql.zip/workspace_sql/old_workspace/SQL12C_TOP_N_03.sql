--TOP-N : ����� ���ϴ� Ư�� ������ŭ�� �����͸� ������ �� �ִ�.


--CREATE SEQUENCE t_seq2;
--
--
--CREATE TABLE t_member2(
--	no 	NUMBER DEFAULT t_seq2.NEXTVAL PRIMARY KEY,
--	name VARCHAR2(320),
--	tel NUMBER,
--	jumin VARCHAR2(13) INVISIBLE
--);

--INSERT INTO t_member2 (name,tel) VALUES ('AAA',01012345678);
--INSERT INTO t_member2 (name,tel) VALUES ('BBB',01022345678);
--INSERT INTO t_member2 (name,tel) VALUES ('CCC',01032345678);
--INSERT INTO t_member2 (name,tel) VALUES ('DDD',01042345678);
--INSERT INTO t_member2 (name,tel) VALUES ('EEE',01052345678);
--COMMIT;
--SELECT * FROM t_member2;
--COL NO FOR 999
--COL name FOR A10
--COL tel FOR 9999999999999
--SELECT * 
--FROM t_member2
--FETCH FIRST 3 ROWS ONLY;


--COL NO FOR 999
--COL name FOR A10
--COL tel FOR 9999999999999
--SELECT * 
--FROM t_member2
--ORDER BY tel DESC
--FETCH FIRST 3 ROWS ONLY;
  

SELECT * 
FROM t_member2
WHERE no > 0
OFFSET 2 ROWS
FETCH NEXT 3 ROWS ONLY;