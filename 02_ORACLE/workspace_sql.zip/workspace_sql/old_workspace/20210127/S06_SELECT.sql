--컬럼 별칭 사용
--SELECT profno
--      ,name
--	  ,pay
--FROM professor
--;
--    PROFNO NAME                                            PAY
------------ ---------------------------------------- ----------
--      1001 Audie Murphy                                    550
--      1002 Angela Bassett                                  380
--      1003 Jessica Lange                                   270
--      2001 Winona Ryder                                    250
--      2002 Michelle Pfeiffer                               350
--      2003 Whoopi Goldberg                                 490
--      3001 Emma Thompson                                   530
--      3002 Julia Roberts                                   330
--      3003 Sharon Stone                                    290
--      4001 Meryl Streep                                    570
--      4002 Susan Sarandon                                  330
--      4003 Nicole Kidman                                   310
--      4004 Holly Hunter                                    260
--      4005 Meg Ryan                                        500
--      4006 Andie Macdowell                                 220
--      4007 Jodie Foster                                    290
--
--16 행이 선택되었습니다.

SELECT profno "Prof' NO"
      ,name AS "Prof's Name"
	  ,pay Prof_Pay
FROM professor
;
--  Prof' NO Prof's Name                                PROF_PAY
------------ ---------------------------------------- ----------
--      1001 Audie Murphy                                    550
--      1002 Angela Bassett                                  380
--      1003 Jessica Lange                                   270
--      2001 Winona Ryder                                    250
--      2002 Michelle Pfeiffer                               350
--      2003 Whoopi Goldberg                                 490
--      3001 Emma Thompson                                   530
--      3002 Julia Roberts                                   330
--      3003 Sharon Stone                                    290
--      4001 Meryl Streep                                    570
--      4002 Susan Sarandon                                  330
--      4003 Nicole Kidman                                   310
--      4004 Holly Hunter                                    260
--      4005 Meg Ryan                                        500
--      4006 Andie Macdowell                                 220
--      4007 Jodie Foster                                    290
--
--16 행이 선택되었습니다.