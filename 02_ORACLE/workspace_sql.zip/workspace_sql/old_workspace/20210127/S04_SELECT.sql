--SELECT를 이용한 표현식(값) 출력
--표현식은 '(값)'

SELECT name, 'good morning~~' "Good morning"
FROM professor
; 