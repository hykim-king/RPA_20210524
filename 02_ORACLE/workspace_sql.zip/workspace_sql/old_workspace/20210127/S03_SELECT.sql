--데이터가 숫자인 경우
--문법 : COL empno FOR 9999
--의미 : empno 컬럼의 길이를 숫자 4자리까지 들어가게 하세요.


--데이터가 문인 경우
--문법 : COL ename FOR a8
--의미 : ename 컬럼의 길이를 문자 8자리까지 들어가게 하세요.

--한화면에 출력 가능한 줄 길이(가로)
--문법 :SET LINE SIZE 200
--의미 :한 화면을 가로로 200BYTE까지 출력


--한화면에 출력 가능한 줄수(세로)
--문법 :SET PAGES 50
--의미 :한 페이지에 50줄 출력
SET LINE SIZE 200
SET PAGES 50
COL empno FOR 9999
COL ename FOR a8
SELECT empno
      ,ename
	  ,job
	  ,sal
FROM emp
;