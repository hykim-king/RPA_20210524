--ORACLE 12C이후 부터 가능한 기능
--INVISIBLE COLUMNE : 

--CREATE TABLE t_member(
--	no 	NUMBER,
--	name VARCHAR2(320),
--	tel NUMBER,
--	jumin VARCHAR2(13) INVISIBLE
--);

--INSERT INTO t_member VALUES (1,'AAA','01012345678',1234567890123);

--INSERT INTO t_member VALUES (1,'AAA','01012345678');
--VISIBLE속성으로 변경
--ALTER TABLE t_member MODIFY (jumin VISIBLE);
--
--INSERT INTO t_member VALUES (1,'AAA','01012345678',1234567890123);

--SELECT * FROM t_member;
--INVISIBLE속성으로 변경
--ALTER TABLE t_member MODIFY (jumin INVISIBLE);
COL table_name FOR A20
COL column_name FOR A20
COL hidden_column FOR A10
SELECT table_name,column_name,hidden_column
FROM user_tab_cols
WHERE table_name = 'T_MEMBER';
--TABLE_NAME           COLUMN_NAME          HIDDEN_COL
---------------------- -------------------- ----------
--T_MEMBER             NO                   NO
--T_MEMBER             NAME                 NO
--T_MEMBER             TEL                  NO
--T_MEMBER             JUMIN                YES



