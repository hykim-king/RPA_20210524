SELECT t1.name   "STU_NAME"
      ,t2.total  "SCORE"
	  ,t3.grade  "GRADE"
FROM student t1 INNER JOIN score t2
ON t1.studno = t2.studno
INNER JOIN hakjum t3
ON t2.total BETWEEN t3.min_point  AND t3.max_point
;