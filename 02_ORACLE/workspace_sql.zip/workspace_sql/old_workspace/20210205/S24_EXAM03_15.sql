--15) professor 테이블을 조회하여 학과번호 , 교수명 , 급여 , 학과별 급여 합계를 구하고 
--각 교수의 급여가 해당 학과별 급여 합계에서 차지하는 비율을 출력하세요.

SELECT deptno
      ,name
      ,pay
	  ,SUM(pay) OVER( PARTITION BY deptno) "TOTAL_PAY"
	  ,ROUND(RATIO_TO_REPORT(pay) OVER( PARTITION BY deptno)*100,2) "RATIO_%"
FROM professor
ORDER BY deptno,name
;
--    DEPTNO NAME                                            PAY  TOTAL_PAY    RATIO_%
------------ ---------------------------------------- ---------- ---------- ----------
--       101 Angela Bassett                                  380       1200      31.67
--       101 Audie Murphy                                    550       1200      45.83
--       101 Jessica Lange                                   270       1200       22.5
--       102 Michelle Pfeiffer                               350       1090      32.11
--       102 Whoopi Goldberg                                 490       1090      44.95
--       102 Winona Ryder                                    250       1090      22.94
--       103 Emma Thompson                                   530       1150      46.09
--       103 Julia Roberts                                   330       1150       28.7
--       103 Sharon Stone                                    290       1150      25.22
--       201 Meryl Streep                                    570        900      63.33
--       201 Susan Sarandon                                  330        900      36.67
--       202 Holly Hunter                                    260        570      45.61
--       202 Nicole Kidman                                   310        570      54.39
--       203 Meg Ryan                                        500        500        100
--       301 Andie Macdowell                                 220        510      43.14
--       301 Jodie Foster                                    290        510      56.86
--
--16 행이 선택되었습니다.