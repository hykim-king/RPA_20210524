--student테이블과 professor 테이블을 조회하여 
--학생의 제1정공이 101번인 학생들의 이름,지도교수를 출력 하세요.

SELECT t1.name "stu_name"
      ,t2.name "prof_name"
	  ,t1.deptno1
FROM student t1 JOIN professor t2
ON t1.profno = t2.profno
WHERE t1.deptno1 = 101
;