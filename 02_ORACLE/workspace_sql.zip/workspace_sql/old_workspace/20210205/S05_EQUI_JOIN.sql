--학생테이블(student)과 교수(professor)을 join하여 학생이름과 지도교수 이름을 출력하세요.
--col name for a20
--col profno for 99999
--SELECT name 
--      ,profno
--FROM student;


col "STU_NAME" for a20
col "PROF_NAME" for a20
SELECT t1.name "STU_NAME"
      ,t2.name "PROF_NAME"
FROM student t1, professor t2
WHERE t1.profno = t2.profno
;

--STU_NAME             PROF_NAME
---------------------- --------------------
--James Seo            Audie Murphy
--Billy Crystal        Angela Bassett
--Richard Dreyfus      Angela Bassett
--Tim Robbins          Winona Ryder
--Rene Russo           Winona Ryder
--Nicholas Cage        Michelle Pfeiffer
--Sandra Bullock       Julia Roberts
--Demi Moore           Meryl Streep
--Macaulay Culkin      Meryl Streep
--Wesley Snipes        Susan Sarandon
--Danny Glover         Nicole Kidman
--Micheal Keaton       Nicole Kidman
--Steve Martin         Nicole Kidman
--Daniel Day-Lewis     Jodie Foster
--Bill Murray          Jodie Foster
--
--15 행이 선택되었습니다.