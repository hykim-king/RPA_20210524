--student 학생테이블과 score테이블, hakjum테이블을 조회 하여 
--학생이름, 점수, 학점을 출력 하세요.
--SELECT * FROM score;
--score
--studno	NUMBER	Yes
--total	NUMBER	Yes
--
--
--SELECT * FROM hakjum;
--hakjum
--grade	    CHAR(3 BYTE)	Yes
--min_point	NUMBER	Yes
--max_point	NUMBER	Yes

SELECT t1.name   "STU_NAME"
      ,t2.total  "SCORE"
	  ,t3.grade  "GRADE"
FROM student t1, score t2,hakjum t3
WHERE t1.studno = t2.studno
AND   t2.total BETWEEN t3.min_point  AND t3.max_point
;