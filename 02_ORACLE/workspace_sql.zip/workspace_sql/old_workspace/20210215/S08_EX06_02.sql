--2. Dept2 테이블에 아래와 같은 내용으로 특정 컬럼에만 정보를 입력하세요 
--
--* 부서번호 : 9020
--* 부서명 : temp_20
--* 상위부서 : Business Department ( 1006 번 부서 )

INSERT INTO dept2(DCODE,DNAME,PDEPT) VALUES('9020','temp_20','1006');
COL DNAME FOR A25
COL AREA FOR A29
SELECT * FROM dept2;