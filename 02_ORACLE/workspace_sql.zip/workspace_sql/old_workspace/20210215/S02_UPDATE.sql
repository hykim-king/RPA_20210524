--UPDATE: 데이터 변경													
--	기존 데이터를 다른 데이터로 변경할 때 사용.												
--													
--	UPDATE  TABLE												
--	SET column = value												
--	WHERE 조건;												
--													
--	(SELECT를 먼저 수행, 결과를 확인 하고 수행 할것.)												
--	실수한 경우 : ROLLBACK												

--professor 테이블에서 직급이 조교수(assistant professor)인 교수들의 bonus를 200만원으로 인상 하세요.
--SELECT profno
--      ,name
--	  ,bonus
--FROM professor
--WHERE position = 'assistant professor'
--;
--    PROFNO NAME                                          BONUS
------------ ---------------------------------------- ----------
--      1002 Angela Bassett                                   60
--      2002 Michelle Pfeiffer                                80
--      3002 Julia Roberts                                    50
--      4002 Susan Sarandon
--      4003 Nicole Kidman                                    50
--      4007 Jodie Foster                                     30

--UPDATE professor
--SET bonus = 200
--WHERE position = 'assistant professor'
--;

--    PROFNO NAME                                          BONUS
------------ ---------------------------------------- ----------
--      1002 Angela Bassett                                  200
--      2002 Michelle Pfeiffer                               200
--      3002 Julia Roberts                                   200
--      4002 Susan Sarandon                                  200
--      4003 Nicole Kidman                                   200
--      4007 Jodie Foster                                    200

