--UPDATE조인																		
--	다른 테이블과 조인을 하는 UPDATE문																	
--	(WHERE절과 SET절 모두 다른 테이블과 조인, WHERE절에만 다른 테이블과 조인)																			

--WHERE절에만 다른 테이블과 조인
--emp테이블 에서 부서가 DALLAS에 위치하는 부서에 근무하는 사원의 급여를 10%인상 하세요.

--SELECT *
--FROM emp t1
--WHERE EXISTS(
--			SELECT 1
--			FROM dept t2
--			WHERE t2.loc = 'DALLAS'
--			AND t1.deptno= t2.deptno
--);
--     EMPNO ENAME  JOB             MGR HIREDATE              SAL       COMM     DEPTNO
------------ ------ -------- ---------- -------- ---------- ---------- ----------
--      7369 SMITH  CLERK          7902 80/12/17              800                    20
--      7902 FORD   ANALYST        7566 81/12/03             3000                    20
--      7566 JONES  MANAGER        7839 81/04/02             2975                    20
UPDATE emp t1
SET sal = sal*1.10
WHERE EXISTS(
			SELECT 1
			FROM dept t2
			WHERE t2.loc = 'DALLAS'
			AND t1.deptno= t2.deptno
);

SELECT *
FROM emp t1
WHERE EXISTS(
			SELECT 1
			FROM dept t2
			WHERE t2.loc = 'DALLAS'
			AND t1.deptno= t2.deptno
);
--     EMPNO ENAME  JOB             MGR HIREDATE        SAL       COMM     DEPTNO
------------ ------ -------- ---------- -------- ---------- ---------- ----------
--      7369 SMITH  CLERK          7902 80/12/17        880                    20
--      7902 FORD   ANALYST        7566 81/12/03       3300                    20
--      7566 JONES  MANAGER        7839 81/04/02     3272.5                    20