--DEPT2 테이블에서 부서번호(DCODE)가 9000번에서 9999번 사이인 매장들을 삭제 하세요.
--SELECT dcode
--      ,dname
--FROM dept2
--WHERE dcode  BETWEEN  9000 AND 9999;

--DELETE FROM dept2
--WHERE dcode  BETWEEN  9000 AND 9999;

--SELECT dcode
--      ,dname
--FROM dept2
--WHERE dcode  BETWEEN  9000 AND 9999;

--파일에 기록 취소
--rollback;

SELECT dcode
      ,dname
FROM dept2
WHERE dcode  BETWEEN  9000 AND 9999;