--MERGE: 여러 테이블의 데이터를 합치는 병합을 의미.,
--,
--	MERGE INTO TABLE1		
--	USING TABLE2		
--	ON (병합조건)		
--	WHEN MATCHED THEN		
--		UPDATE(DELETE) SET 업데이트 내용	
--	WHEN NOT MATCHED THEN		
--		INSERT VALUES(값)	

--charge01
--         ----> ch_total
--charge01

--CREATE TABLE charge01 (
--	u_date  VARCHAR2(6),
--	cust_no NUMBER,
--	u_time  NUMBER,
--	change  NUMBER
--);
--
--
--CREATE TABLE charge02 (
--	u_date  VARCHAR2(6),
--	cust_no NUMBER,
--	u_time  NUMBER,
--	change  NUMBER
--);

--INSERT INTO charge01 VALUES('141001',1000,2,1000);		
--INSERT INTO charge01 VALUES('141001',1001,2,1000);		
--INSERT INTO charge01 VALUES('141001',1002,1,500 ); 		
--SELECT *
--FROM charge01;

--INSERT INTO charge02 VALUES('141002',1000,3,1500 );		
--INSERT INTO charge02 VALUES('141002',1001,4,2000 );		
--INSERT INTO charge02 VALUES('141002',1003,1,500  );		
--SELECT *
--FROM charge02;


--ch_total : CTAS(데이터는 가지고 오지 않는다.)
--CREATE TABLE ch_total
--AS
--SELECT *
--FROM charge01
--WHERE 1=2;

--확인
--SELECT *
--FROM ch_total;

--charge01 MERGE수행
--MERGE INTO ch_total	t1	
--USING charge01 t2		
--ON (t1.u_date =t2.u_date)		
--WHEN MATCHED THEN		
--	UPDATE SET t1.cust_no	= t2.cust_no
--WHEN NOT MATCHED THEN		
--	INSERT VALUES(t2.u_date,t2.cust_no,t2.u_time,t2.change)	
--;

--SELECT *
--FROM ch_total;


--charge02 MERGE수행
--MERGE INTO ch_total	t1	
--USING charge02 t2		
--ON (t1.u_date =t2.u_date)		
--WHEN MATCHED THEN		
--	UPDATE SET t1.cust_no	= t2.cust_no
--WHEN NOT MATCHED THEN		
--	INSERT VALUES(t2.u_date,t2.cust_no,t2.u_time,t2.change)	
--;

--SELECT *
--FROM ch_total;
--U_DATE          CUST_NO     U_TIME     CHANGE
-------------- ---------- ---------- ----------
--141001             1000          2       1000
--141001             1001          2       1000
--141001             1002          1        500
--141002             1000          3       1500
--141002             1001          4       2000
--141002             1003          1        500


MERGE INTO ch_total	t1	
USING charge02 t2		
ON (t1.u_date =t2.u_date)		
WHEN MATCHED THEN		
	UPDATE SET t1.cust_no	= t2.cust_no
WHEN NOT MATCHED THEN		
	INSERT VALUES(t2.u_date,t2.cust_no,t2.u_time,t2.change)	
;


