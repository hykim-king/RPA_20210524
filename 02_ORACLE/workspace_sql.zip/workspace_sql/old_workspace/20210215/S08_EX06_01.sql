--1. Dept2 테이블에 아래와 같은 내용으로 새로운 부서 정보를 입력하세요.
--


--* 부서번호 : 9010
--* 부서명 : temp_10
--* 상위부서 : 1006
--* 지역 : temp area
--COL DNAME FOR A25
--COL AREA FOR A29
--SELECT * FROM dept2;
--DCODE        DNAME                     PDEPT        AREA
-------------- ------------------------- ------------ -----------------------------
--0001         President                              Pohang Main Office
--1000         Management Support Team   0001         Seoul Branch Office
--1001         Financial Management Team 1000         Seoul Branch Office
--1002         General affairs           1000         Seoul Branch Office
--1003         Engineering division      0001         Pohang Main Office
--1004         H/W Support Team          1003         Daejeon Branch Office
--1005         S/W Support Team          1003         Kyunggi Branch Office
--1006         Business Department       0001         Pohang Main Office
--1007         Business Planning Team    1006         Pohang Main Office
--1008         Sales1 Team               1007         Busan Branch Office
--1009         Sales2 Team               1007         Kyunggi Branch Office
--1010         Sales3 Team               1007         Seoul Branch Office
--1011         Sales4 Team               1007         Ulsan Branch Office
--9000         temp_1                    1006         temp_area
--9001         temp_2                    1006         temp_area
--9002         temp_3                    1006

--16 행이 선택되었습니다.
--INSERT INTO dept2 VALUES ('9010','temp_10','1006','temp area');


COL DNAME FOR A25
COL AREA FOR A29
SELECT * FROM dept2;
DCODE        DNAME  

