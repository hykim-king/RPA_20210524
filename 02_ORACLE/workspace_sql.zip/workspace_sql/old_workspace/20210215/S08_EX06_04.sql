--4. Professor 테이블에서 'Sharon Stone' 교수의 BONUS 를 100 만원으로 인상하세요.

SELECT name,bonus
FROM Professor
WHERE name ='Sharon Stone';

UPDATE professor
SET BONUS = 100
WHERE name = 'Sharon Stone'
;

SELECT name,bonus
FROM Professor
WHERE name ='Sharon Stone';