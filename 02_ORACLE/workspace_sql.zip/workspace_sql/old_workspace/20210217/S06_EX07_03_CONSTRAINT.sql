--제약조건 관리																																		
--																																		
--1. NOVALIDATE:  ENABLE하는 시점까지 해당 테이블에 들어 있는 데이터는 검사하지 않고  ENABLE한 시점 이후 부터 입력된 데이터의 무결성 적용.																																		
--2. VALIDATE: ENABLE하는 시점까지 입력되어 있던 모든 데이터를 전부검사, 신규로 입력된 데이터의 무결성도 검사.																																		
-- ENABLE VALIDATE를 하면 TABLE 락을 걸과 완료되기 까지 CUD가 않됨.(업무 시간에 작업 하면 않됨.)																																		
----EXCEPTIONS테이블을 통해 에러사항을 별도록 기록. 	
																																	
--3. tcons 테이블의 name 컬럼에 만들어져 있는 unique 
--제약조건을 "사용안함"으로 변경하되해당 테이블의 데이터에 DML 까지 안되도록 변경하는 쿼리를 쓰세요.
--( 제약조건 이름은 tcons_name_uk 입니다)

--EXCEPTION TABLE생성
--@C:\app\sist\product\18.0.0\dbhomeXE\rdbms\admin\utlexcpt.sql

--SELECT t1.owner
--       ,t1.constraint_name
--       ,t1.constraint_type
--       ,t1.status
--FROM user_constraints t1
--WHERE t1.table_name = 'T_CONS';

--비활성
--ALTER TABLE t_cons
--DISABLE VALIDATE CONSTRAINT TCONS_JUMIN_UK;

--OWNER           CONSTRAINT_NAME CONST STATUS
----------------- --------------- ----- ----------
--SCOTT           TCONS_DEPTNO_FK R     ENABLED
--SCOTT           TCONS_NAME_FK   R     ENABLED
--SCOTT           TCONS_NAME_NN   C     ENABLED
--SCOTT           TCONS_JUMIN_NN  C     ENABLED
--SCOTT           TCONS_AREA_CK   C     ENABLED
--SCOTT           TCONS_NO_PK     P     ENABLED
--SCOTT           TCONS_JUMIN_UK  U     DISABLED

--활성화
--ALTER TABLE t_cons
--ENABLE VALIDATE CONSTRAINT TCONS_JUMIN_UK;


--SELECT t1.owner
--       ,t1.constraint_name
--       ,t1.constraint_type
--       ,t1.status
--FROM user_constraints t1
--WHERE t1.table_name = 'T_CONS';


--OWNER           CONSTRAINT_NAME CONST STATUS
----------------- --------------- ----- ----------
--SCOTT           TCONS_DEPTNO_FK R     ENABLED
--SCOTT           TCONS_NAME_FK   R     ENABLED
--SCOTT           TCONS_NAME_NN   C     ENABLED
--SCOTT           TCONS_JUMIN_NN  C     ENABLED
--SCOTT           TCONS_AREA_CK   C     ENABLED
--SCOTT           TCONS_NO_PK     P     ENABLED
--SCOTT           TCONS_JUMIN_UK  U     ENABLED
--
--7 행이 선택되었습니다.

ALTER TABLE t_cons
DISABLE VALIDATE CONSTRAINT TCONS_JUMIN_UK;
