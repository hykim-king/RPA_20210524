--제약조건 조회 하기																
--																
--		딕셔너리 USER_CONSTRAINTS, USER_CONS_COLUMNS														
--		DBA: DBA_CONSTRAINTS, DBA_CONS_COLUMNS														

-- table이름은 반듯이 대문자
-- constraint type : P -> PK
--                   U -> UNIQUE
--					 C -> CHECK
--					 R -> FK
--					 
col owner for a15
col constraint_name for a15
col constraint_type for a5
col status for a10
--SELECT t1.owner
--      ,t1.constraint_name
--	  ,t1.constraint_type
--	  ,t1.status
--FROM user_constraints T1
--WHERE t1.table_name = 'EMP'
--;
--OWNER           CONSTRAINT_NAME CONST STATUS
----------------- --------------- ----- ----------
--SCOTT           FK_DEPTNO       R     ENABLED
--SCOTT           PK_EMP          P     ENABLED

col owner for a15
col constraint_name for a15
col column_name for a15
col table_name for a15
SELECT owner
	,constraint_name
	,table_name
	,column_name
FROM user_cons_columns
WHERE table_name = 'EMP';

--OWNER           CONSTRAINT_NAME TABLE_NAME      COLUMN_NAME
----------------- --------------- --------------- ---------------
--SCOTT           PK_EMP          EMP             EMPNO
--SCOTT           FK_DEPTNO       EMP             DEPTNO




















					 