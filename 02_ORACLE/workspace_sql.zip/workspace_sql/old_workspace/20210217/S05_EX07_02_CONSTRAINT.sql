--2. t_cons 테이블의 name 컬럼이 emp2 테이블의 name 컬럼의 값을 참조하도록 
--참조키 제약조건을 추가 설정하는 쿼리를 쓰세요.(tcons 테이블이 자식테이블입니다)
ALTER TABLE t_cons
ADD CONSTRAINT tcons_name_fk FOREIGN KEY(name)
REFERENCES emp2(name);