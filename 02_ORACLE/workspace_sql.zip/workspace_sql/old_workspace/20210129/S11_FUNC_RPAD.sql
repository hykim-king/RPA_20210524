--RPAD(): 오른쪽에 채운다(특정기호나 문자로 오른쪽에 채운다.)
--RPAD('문자열 또는 컬럼',자릿수,'채울문자')

SELECT  RPAD(ename,10,'-')
FROM emp
WHERE deptno =10
;
--RPAD(ENAME,10,'-')
----------------------
--CLARK-----
--KING------
--MILLER----