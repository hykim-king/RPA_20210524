--ROUND(숫자,[,m])숫자를 소수점 m+1 자리에서 반올림하여 처리, m이 생략되면 default 값은 0																		

SELECT ROUND(987.654,2) "ROUND_02"
      ,ROUND(987.654,1) "ROUND_01"
	  ,ROUND(987.654,0) "ROUND_00"
	  ,ROUND(987.654,-1) "ROUND_-1"
FROM dual
;
--  ROUND_02   ROUND_01   ROUND_00   ROUND_-1
------------ ---------- ---------- ----------
--    987.65      987.7        988        990