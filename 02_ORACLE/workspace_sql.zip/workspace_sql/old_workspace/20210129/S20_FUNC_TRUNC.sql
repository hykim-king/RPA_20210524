--TRUNC(숫자,[,m]) 숫자를 소수점 m+1 자리에서 잘라서 처리, m이 생략되면 default 값은 0																					
SELECT TRUNC(987.654,2) "TRUNC_02"
      ,TRUNC(987.654,1) "TRUNC_01"
	  ,TRUNC(987.654,0) "TRUNC_00"
	  ,TRUNC(987.654,-1) "TRUNC_-1"
FROM dual
;
--  TRUNC_02   TRUNC_01   TRUNC_00   TRUNC_-1
------------ ---------- ---------- ----------
--    987.65      987.6        987        980