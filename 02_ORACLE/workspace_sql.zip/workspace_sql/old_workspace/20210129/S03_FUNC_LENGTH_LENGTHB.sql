--LENGTH(),LENGTHB()
--LENGTH(문자 또는 컬럼): 입력된 문자열의 길이를 RETURN
--LENGTHB(문자 또는 컬럼): 입력된 문자열의 길이를 BYTE로 RETURN
--ENCODING(ANSI로)
SELECT ename
      ,LENGTH(ename)
	  ,LENGTHB(ename)
	  ,LENGTH('홍대')
	  ,LENGTHB('홍대')
FROM emp
WHERE deptno =20
;
--ENAME                LENGTH(ENAME) LENGTHB(ENAME) LENGTH('홍대') LENGTHB('홍대')
---------------------- ------------- -------------- ---------------- -----------------
--SMITH                            5              5                3                 9
--JONES                            5              5                3                 9
--FORD                             4              4                3                 9