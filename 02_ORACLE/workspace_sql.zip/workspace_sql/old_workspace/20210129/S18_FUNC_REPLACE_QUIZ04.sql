SELECT name
      ,tel
	  ,REPLACE(tel,SUBSTR(tel,INSTR(tel,'-')+1),'****') "SUBSTR"
FROM student
WHERE deptno1 =101
;
--NAME             TEL            SUBSTR
------------------ -------------- ------------------------------------------------------------------------------------------------------------------------
--James Seo        055)381-2158   055)381-****
--Billy Crystal    055)333-6328   055)333-****
--Richard Dreyfus  02)6788-4861   02)6788-****
--Danny Devito     055)278-3649   055)278-****