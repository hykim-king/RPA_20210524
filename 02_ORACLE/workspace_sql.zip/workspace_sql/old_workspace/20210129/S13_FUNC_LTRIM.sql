--LTRIM(문자열 또는 컬럼, '제거할 문자') :default 문자는 공백
--이름이 'C'로 시작하는 사람중 'C'제거
SELECT ename
      ,LTRIM(ename,'C')
	  ,LTRIM(' GOOD') 
	  ,RTRIM(ename,'R')
FROM emp
WHERE deptno = 10;
--ENAME                LTRIM(ENAME,'C')     LTRIM('G RTRIM(ENAME,'R')
---------------------- -------------------- -------- --------------------
--CLARK                LARK                 GOOD     CLARK
--KING                 KING                 GOOD     KING
--MILLER               MILLER               GOOD     MILLE