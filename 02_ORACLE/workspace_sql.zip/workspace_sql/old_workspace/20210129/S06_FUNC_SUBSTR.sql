--7510231901813
COL name  			FOR  A15
COL jumin  			FOR  A13
COL "BIRTHDAY"  	FOR  A10
COL "BIRTHDAY -1"   FOR  9999
SELECT name
      ,jumin
	  ,SUBSTR(jumin,3,4) "BIRTHDAY"
	  ,SUBSTR(jumin,3,4)-1 "BIRTHDAY -1"
FROM student
WHERE deptno1=101;

--NAME            JUMIN         BIRTHDAY   BIRTHDAY -1
----------------- ------------- ---------- -----------
--James Seo       7510231901813 1023              1022
--Billy Crystal   7601232186327 0123               122
--Richard Dreyfus 7711291186223 1129              1128
--Danny Devito    7808192157498 0819               818