--MOD(숫자1,숫자2) :숫자1을 숫자2로 나눈 나머지 값을 리턴																					
--CEIL(숫자)	  :숫자보다 크거나 같은 최소 정수																					
--FLOOR(숫자)	  :주어진 숫자와 가장 근접한 작은 정수																					

--SELECT MOD(121,10) "MOD"
--      ,CEIL(123.45) "CEIL"
--	  ,FLOOR(123.45) "FLOOR"
--FROM dual;
--
--       MOD       CEIL      FLOOR
------------ ---------- ----------
--         1        124        123
SELECT rownum
      ,ceil(rownum/3)
	  ,ename
FROM emp;




--SELECT * FROM
--(
--     SELECT T1.*, 
--            ROWNUM AS RN,
--            CEIL((ROWNUM-1)/[페이지당 출력 레코드 수]) AS PAGE,
--     
--) 
--
--WHERE PAGE = [페이지번호];








