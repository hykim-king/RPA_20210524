--RPAD(): 오른쪽에 채운다(특정기호나 문자로 오른쪽에 채운다.)
--RPAD('문자열 또는 컬럼',자릿수,'채울문자')

SELECT  ename
,RPAD(ename,9,substr('123456789',length(ename)+1,9-(length(ename))))
FROM emp
WHERE deptno =10
;

--ENAME                RPAD(ENAME,9,SUBSTR('123456789',LENGTH(ENAME)+1,9-(LENGTH(ENAME))))
---------------------- ------------------------------------------------------------------------
--CLARK                CLARK6789
--KING                 KING56789
--MILLER               MILLER789