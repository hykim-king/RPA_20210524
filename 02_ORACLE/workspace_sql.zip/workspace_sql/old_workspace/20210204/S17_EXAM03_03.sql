SELECT MAX(TOTAL) "TOTAL"
      ,COUNT(DECODE(AREA_CD,'02' ,'1')) "SEOUL"
      ,COUNT(DECODE(AREA_CD,'031','1')) "GYEONGGI"
      ,COUNT(DECODE(AREA_CD,'051','1')) "BUSAN"
      ,COUNT(DECODE(AREA_CD,'052','1')) "ULSAN"
      ,COUNT(DECODE(AREA_CD,'053','1')) "DAEGU"
      ,COUNT(DECODE(AREA_CD,'055','1')) "GYEONGNAM"
FROM(
		SELECT COUNT(*) OVER() "TOTAL",SUBSTR(tel,1,INSTR(tel,')')-1) "AREA_CD"
		FROM student
);

-- TOTAL      SEOUL   GYEONGGI      BUSAN      ULSAN      DAEGU  GYEONGNAM
-------- ---------- ---------- ---------- ---------- ---------- ----------
--    20          6          2          4          0          2          6