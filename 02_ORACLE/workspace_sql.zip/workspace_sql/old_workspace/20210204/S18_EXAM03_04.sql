--INSERT INTO emp (empno,deptno,ename,sal) VALUES (1000,10,'Tiger',3600);
--
--INSERT INTO emp (empno,deptno,ename,sal) VALUES (2000,10,'Cat',3000);
--
--COMMIT;
--SELECT empno,deptno,ename,job,sal
--FROM emp;

--     EMPNO     DEPTNO ENAME                JOB                       SAL
------------ ---------- -------------------- ------------------ ----------
--      7369         20 SMITH                CLERK                     800
--      7499         30 ALLEN                SALESMAN                 1600
--      7521         30 WARD                 SALESMAN                 1250
--      7566         20 JONES                MANAGER                  2975
--      7654         30 MARTIN               SALESMAN                 1250
--      7698         30 BLAKE                MANAGER                  2850
--      7782         10 CLARK                MANAGER                  2450
--      7839         10 KING                 PRESIDENT                5000
--      7844         30 TURNER               SALESMAN                 1500
--      7900         30 JAMES                CLERK                     950
--      7902         20 FORD                 ANALYST                  3000
--      7934         10 MILLER               CLERK                    1300
--      1000         10 Tiger                                         3600
--      2000         10 Cat                                           3000
--
--14 행이 선택되었습니다.

SELECT deptno
      ,SUM(DECODE(job,'CLERK',sal,0)    ) "CLERK"
      ,SUM(DECODE(job,'MANAGER',sal,0)  ) "MANAGER"
      ,SUM(DECODE(job,'PRESIDENT',sal,0)) "PRESIDENT"
      ,SUM(DECODE(job,'ANALYST',sal,0)  ) "ANALYST"
      ,SUM(DECODE(job,'SALESMAN',sal,0) ) "SALESMAN"  
	  ,SUM(NVL2(job,sal,0)) "TOTAL"  
FROM emp
GROUP BY ROLLUP(deptno)
;
--    DEPTNO      CLERK    MANAGER  PRESIDENT    ANALYST   SALESMAN   TOTAL
------------ ---------- ---------- ---------- ---------- ---------- -------
--        10       1300       2450       5000          0          0    8750
--        20        800       2975          0       3000          0    6775
--        30        950       2850          0          0       5600    9400
--                 3050       8275       5000       3000       5600   24925