--DENSE_RANK() : 순위 출력
--동일한 순위를 하나의 건수로 취급하므로 연속된 순위를 보여 준다.
--DENSE_RANK( ) OVER([ query_partition_clause ] order_by_clause)
--
--1
--2
--2
--3
--4
--5

SELECT empno
      ,ename
  ,sal
  ,RANK() OVER(ORDER BY sal ASC) "RANK_ASC"
  ,DENSE_RANK() OVER(ORDER BY sal ASC) "DENSE_RANK"
FROM emp;
--     EMPNO ENAME                       SAL   RANK_ASC DENSE_RANK
------------ -------------------- ---------- ---------- ----------
--      7369 SMITH                       800          1          1
--      7900 JAMES                       950          2          2
--      7521 WARD                       1250          3          3
--      7654 MARTIN                     1250          3          3
--      7934 MILLER                     1300          5          4
--      7844 TURNER                     1500          6          5
--      7499 ALLEN                      1600          7          6
--      7782 CLARK                      2450          8          7
--      7698 BLAKE                      2850          9          8
--      7566 JONES                      2975         10          9
--      7902 FORD                       3000         11         10
--      7839 KING                       5000         12         11
--
--12 행이 선택되었습니다.