--RATIO_TO_REPORT: 판매비율
--
--RATIO_TO_REPORT(expr)
--   OVER ([ query_partition_clause ])

--panmae테이블에서 100번 제품의 판매내역과 각 판매점별 판매비중
SELECT p_store
      ,p_code
	  ,p_qty
	  ,p_total
	  ,SUM(p_qty) OVER() "T_QTY"
	  ,SUM(p_total) OVER() "T_P_TOTAL"
	  ,ROUND( p_qty/SUM(p_qty) OVER()*100,2 ) "QTY_EX"
	  ,ROUND( RATIO_TO_REPORT( SUM(p_qty)   ) OVER()*100,2) "RATIO_TO_REPORT_QTY_%"
	  ,ROUND( RATIO_TO_REPORT( SUM(p_total) ) OVER()*100,2) "P_TOTAL_%"
FROM panmae
WHERE p_code =100
GROUP BY p_code,p_store,p_qty,p_total
;
--P_STORE        P_CODE      P_QTY    P_TOTAL      T_QTY  T_P_TOTAL     QTY_EX RATIO_TO_REPORT_QTY_%  P_TOTAL_%
------------ ---------- ---------- ---------- ---------- ---------- ---------- --------------------- ----------
--1000              100          3       2400         29      23200      10.34                 10.34      10.34
--1000              100          2       1600         29      23200        6.9                   6.9        6.9
--1001              100          3       2400         29      23200      10.34                 10.34      10.34
--1002              100          2       1600         29      23200        6.9                   6.9        6.9
--1003              100          4       3200         29      23200      13.79                 13.79      13.79
--1004              100          5       4000         29      23200      17.24                 17.24      17.24
--1004              100         10       8000         29      23200      34.48                 34.48      34.48