--SELECT *
--FROM fruit
--;
--NAME                      PRICE
---------------------- ----------
--apple                       100
--grape                       200
--orange                      300

SELECT MAX(DECODE(name,'apple',price) ) "APPLE"
      ,MAX(DECODE(name,'grape',price) ) "GRAPE"
      ,MAX(DECODE(name,'orange',price)) "ORANGE"
FROM fruit
;
--     APPLE      GRAPE     ORANGE
------------ ---------- ----------
--       100        200        300