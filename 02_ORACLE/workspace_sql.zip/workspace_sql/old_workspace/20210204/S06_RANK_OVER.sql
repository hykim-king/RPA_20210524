--전체순위 보기
--RANK() OVER (ORDER BY 조건값 [ASC|DESC]
--RANK( )
--   OVER ([ query_partition_clause ] order_by_clause)

-- emp 테이블에서 사원들의 empno,ename,sal 급여 순위를 출력하세요.
SELECT empno
      ,ename
	  ,sal
	  ,RANK() OVER(ORDER BY sal ASC) "RANK_ASC"
	  ,RANK() OVER(ORDER BY sal DESC) "RANK_DESC"
FROM emp;

--     EMPNO ENAME                       SAL   RANK_ASC  RANK_DESC
------------ -------------------- ---------- ---------- ----------
--      7839 KING                       5000         12          1
--      7902 FORD                       3000         11          2
--      7566 JONES                      2975         10          3
--      7698 BLAKE                      2850          9          4
--      7782 CLARK                      2450          8          5
--      7499 ALLEN                      1600          7          6
--      7844 TURNER                     1500          6          7
--      7934 MILLER                     1300          5          8
--      7654 MARTIN                     1250          3          9
--      7521 WARD                       1250          3          9
--      7900 JAMES                       950          2         11
--      7369 SMITH                       800          1         12









