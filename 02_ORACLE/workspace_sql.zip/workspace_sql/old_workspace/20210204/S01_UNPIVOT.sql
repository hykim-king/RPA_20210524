--1. unpivot table 생성
--CREATE TABLE unpivot
--AS
--SELECT * FROM (SELECT deptno,job,empno FROM emp)
--PIVOT(
--		COUNT(empno) FOR job IN (
--						'CLERK'   	AS 	"CLERK"
--						,'SALESMAN' AS  "SALESMAN" 
--						,'ANALYST'  AS  "ANALYST"  
--						,'MANAGER'  AS  "MANAGER"  
--						,'PRESIDENT'AS 	"PRESIDENT"
--		)
--)
--ORDER BY deptno
--;

--2. 생성된 TABLE 데이터 확인
--SELECT *
--FROM unpivot;
--    DEPTNO      CLERK   SALESMAN    ANALYST    MANAGER  PRESIDENT
------------ ---------- ---------- ---------- ---------- ----------
--        10          1          0          0          1          1
--        20          1          0          1          1          0
--        30          1          4          0          1          0

--3. UNPIVOT
--PIVOT된 결과를 되돌리는 기능이 아닌 PIVOT에 대응되는 개념
--PIVOT된 결과를 UNPIVOT 한다고 해서 원래의 PIVOT전 테이블로 돌아 갈 수 없다.

SELECT * FROM unpivot
UNPIVOT(
	empno FOR job IN ( CLERK,SALESMAN,ANALYST,MANAGER,PRESIDENT)
);

--    DEPTNO JOB                     EMPNO
------------ ------------------ ----------
--        10 CLERK                       1
--        10 SALESMAN                    0
--        10 ANALYST                     0
--        10 MANAGER                     1
--        10 PRESIDENT                   1
--        20 CLERK                       1
--        20 SALESMAN                    0
--        20 ANALYST                     1
--        20 MANAGER                     1
--        20 PRESIDENT                   0
--        30 CLERK                       1
--        30 SALESMAN                    4
--        30 ANALYST                     0
--        30 MANAGER                     1
--        30 PRESIDENT                   0
--
--15 행이 선택되었습니다.













