--LAG() : 이전 행 값을 가져올때 사용
--
--LAG
--  { ( 컬럼 [, offset [, 기본 출력]]) [ { RESPECT | IGNORE } NULLS ] 
--  | ( value_expr [ { RESPECT | IGNORE } NULLS ] [, offset [, default]] )
--  }
--  OVER ([ query_partition_clause ] order_by_clause)
SELECT ename
      ,hiredate
	  ,sal
	  ,LAG(sal,2,99) OVER(ORDER BY hiredate) "LAG"
FROM emp
;
--ENAME                HIREDATE        SAL        LAG
---------------------- -------- ---------- ----------
--SMITH                80/12/17        800         99
--ALLEN                81/02/20       1600         99
--WARD                 81/02/22       1250        800
--JONES                81/04/02       2975       1600
--BLAKE                81/05/01       2850       1250
--CLARK                81/06/09       2450       2975
--TURNER               81/09/08       1500       2850
--MARTIN               81/09/28       1250       2450
--KING                 81/11/17       5000       1500
--JAMES                81/12/03        950       1250
--FORD                 81/12/03       3000       5000
--MILLER               82/01/23       1300        950
--
--12 행이 선택되었습니다.