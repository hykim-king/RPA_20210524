--
SELECT deptno,profno,name
FROM professor
;

--LEG()OVER()

SELECT LAG(deptno) OVER(ORDER BY deptno) ndeptno, deptno,profno,name
FROM professor
;

--DECODE
SELECT DECODE(ndeptno,deptno,NULL,deptno) deptno,profno,name
FROM(
    SELECT LAG(deptno) OVER(ORDER BY deptno) ndeptno, deptno,profno,name
    FROM professor
)t1
;