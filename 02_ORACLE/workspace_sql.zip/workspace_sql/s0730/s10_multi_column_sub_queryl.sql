--
SELECT t1.name,
       t1.position,
       TO_CHAR(t1.pay,'$999,999,999') SALARY
FROM emp2 t1 
WHERE (position,pay) IN (SELECT position, max(pay)
                         FROM emp2
                         GROUP BY position
)
ORDER BY 3
;