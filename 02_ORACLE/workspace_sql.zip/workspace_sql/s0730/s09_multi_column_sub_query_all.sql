--

SELECT a.profno,
       a.name prof_name,
       TO_CHAR(a.hiredate,'YYYY-MM-DD') hiredate,
       b.dname dept_name
FROM professor a, department b
WHERE a.deptno = b.deptno
AND (a.deptno, a.hiredate) IN (SELECT t1.deptno,
                                      min(t1.hiredate)
                               FROM professor t1
                               GROUP BY t1.deptno
)
ORDER BY 3
;