--
SELECT name,position,TO_CHAR(pay,'$999,999,999') SALARY
FROM emp2
--pay > 50000000
WHERE pay >ANY  (SELECT pay
                 FROM emp2
                 WHERE position = 'Section head'
)
;