--single row sub ex03
SELECT t2.name,
       t2.weight
FROM student t2
WHERE t2.weight > (SELECT AVG(NVL(t1.weight,0))
                   FROM student t1
                   WHERE t1.deptno1 = 201
)                   
;