--������ sub query 2
--insert into professor
--values (4005,'Meg Ryan','Ryan','a full professor',500,to_date('1985-09-18','YYYY-MM-DD'),80,203,'standkang@naver.com',null);
--commit;


SELECT t1.name prof_name,
       TO_CHAR(t1.hiredate,'YYYY-MM-DD') hiredate,
       t2.dname dept_name
FROM professor t1, department t2
WHERE t1.deptno = t2.deptno
AND t1.hiredate > (SELECT hiredate
                   FROM professor
                   WHERE name = 'Meg Ryan'
)
;