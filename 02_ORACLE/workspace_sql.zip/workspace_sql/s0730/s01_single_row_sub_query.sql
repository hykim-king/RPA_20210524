--������ sub query����1
SELECT t1.name stud_name,
       t2.dname dept_name
FROM student t1, department t2
WHERE t1.deptno1 = t2.deptno
AND   t1.deptno1 = (SELECT deptno1
                    FROM student
                    WHERE name = 'Anthony Hopkins'
)
;




