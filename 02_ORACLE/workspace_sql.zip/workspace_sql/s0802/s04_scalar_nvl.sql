--Scalar Sub Query���� Nulló��											
--											
--	EMP2, DEPT2										
--  EMP2�� DEPT2�� ���� �μ� ��ȣ(999)�� �Է�
SELECT *
FROM dept2;
INSERT INTO emp2 (
    empno,
    name,
    birthday,
    deptno,
    emp_type,
    tel
) VALUES (
    2020000219,
    'Ray',
    TO_DATE('1980/03/22','YYYY/MM/DD'),
    '999',
    'Intern',
    '02)909-2345'
);
commit;
SELECT *
FROM emp2;

--nulló�� �ʵ�
SELECT t1.name,
       (SELECT NVL(t2.dname,'not belong to a Dept..')
        FROM dept2 t2
        WHERE t1.deptno = t2.dcode ) dname
FROM emp2 t1
;

--nulló��
SELECT t1.name,
       NVL((SELECT t2.dname
           FROM dept2 t2
           WHERE t1.deptno = t2.dcode ),'not belong to a Dept..') dname
FROM emp2 t1
;










