--with���� �̿��Ͽ� WITH_TEST1���̺��� �� ���� �е��� �մϴ�.
WITH sub_pay 
AS(
    SELECT MAX(pay) max_pay, Min(pay) min_pay
    FROM with_test1
)
SELECT 'min_pay' c1, min_pay FROM sub_pay
UNION ALL
SELECT 'max_pay' c1, max_pay FROM sub_pay
UNION ALL
SELECT 'max_pay-min_pay' c1, (max_pay - min_pay) diff_pay FROM sub_pay
;

--���� ��ȹ
explain plan for
WITH sub_pay 
AS(
    SELECT MAX(pay) max_pay, Min(pay) min_pay
    FROM with_test1
)
SELECT 'min_pay' c1, min_pay FROM sub_pay
UNION ALL
SELECT 'max_pay' c1, max_pay FROM sub_pay
UNION ALL
SELECT 'max_pay-min_pay' c1, (max_pay - min_pay) diff_pay FROM sub_pay

SELECT * FROM table(dbms_xplan.display);


