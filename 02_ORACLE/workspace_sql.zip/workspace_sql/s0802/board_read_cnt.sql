--readCnt
UPDATE board
SET read_cnt = NVL(read_cnt,0)+1
WHERE SEQ = :seq
;

--SELECT *
--FROM board
--WHERE seq = 240;