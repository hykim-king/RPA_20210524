--�л�(student), �а� ���̺�(department), ���� ���̺�(professor)�� join�Ͽ�
--�л��̸�, �л��� �а� �̸�,���� ���� �̸�
SELECT *
FROM department;

SELECT *
FROM student
;

SELECT *
FROM professor
;

--ORACLE JOIN
SELECT t1.name "stud_name",
       t3.name "prof_name",
       t2.dname "dept_name"
FROM student t1, department t2, professor t3
WHERE t1.profno = t3.profno
AND t1.deptno1 = t2.deptno
;

--ANSI JOIN
SELECT t1.name "stud_name",
       t3.name "prof_name",
       t2.dname "dept_name"
FROM student t1 JOIN professor t3 
ON t1.profno = t3.profno
JOIN department t2
ON t1.deptno1 = t2.deptno
;

--oracle JOIN WHERE
SELECT t1.name "stud_name",
       t3.name "prof_name",
       t2.dname "dept_name"
FROM student t1, department t2, professor t3
WHERE t1.profno = t3.profno
AND t1.deptno1 = t2.deptno
--where
AND t1.deptno1 = 101
;
--ansi JOIN WHERE
SELECT t1.name "stud_name",
       t3.name "prof_name",
       t2.dname "dept_name"
FROM student t1 JOIN professor t3
ON t1.profno = t3.profno
JOIN department t2
ON t1.deptno1 = t2.deptno
--where
WHERE t1.deptno1 = 101
;
-- ,



