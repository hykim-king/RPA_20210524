--CTAS : ���̺��� DATA ����
CREATE TABLE professor2
AS
SELECT deptno,
       position,
       pay
FROM professor
;

SELECT *
FROM professor2;

--������
--101	a full professor	550
--101	assistant professor	380
--101	instructor	270

INSERT INTO professor2 VALUES (101,'instructor',100);

INSERT INTO professor2 VALUES (101,'assistant professor',100);

INSERT INTO professor2 VALUES (101,'a full professor',100);

COMMIT;

SELECT *
FROM professor2
WHERE deptno =101
ORDER BY position
;
--101	a full professor	100
--101	a full professor	550   650
--101	assistant professor	100
--101	assistant professor	380   480
--101	instructor	100
--101	instructor	270           370

--deptno���� grouping �� position���� pay �Ұ�
SELECT deptno,
       position,
       SUM(pay)
FROM professor2
GROUP BY deptno,ROLLUP(position)
;
--1.plan table���� ��ũ��Ʈ ����
@C:\app\HKEDU\product\18.0.0\dbhomeXE\rdbms\admin\utlxplan.sql

--2.sql ����
explain plan for
--plan sql
SELECT *
FROM emp

--3.���� ��� Ȯ��
SELECT * FROM table(dbms_xplan.display);



--1.union all vs rollup �����ȹ ��.
explain plan for
SELECT deptno,
       job,
       ROUND( AVG( NVL(sal,0))   ,1) avg_sal,
       COUNT(*) cnt_emp
FROM emp
GROUP BY ROLLUP(deptno,job)

SELECT * FROM table(dbms_xplan.display);


explain plan for
SELECT deptno,null job,ROUND( AVG( NVL(sal,0))   ,1),COUNT(*) cnt_emp
FROM emp
GROUP BY deptno
UNION ALL
SELECT deptno, job, ROUND( AVG( NVL(sal,0))   ,1),COUNT(*) cnt_emp
FROM emp
GROUP BY deptno,job
UNION ALL
SELECT null deptno, null job, ROUND( AVG( NVL(sal,0))   ,1),COUNT(*) cnt_emp
FROM emp
ORDER BY deptno,JOB

SELECT * FROM table(dbms_xplan.display);
