--FOREIGN KEY ��ȸ�ϱ�										
--										
--user_constraints										
--user_constraints										
--user_cons_columns										
--(select * from user_cons_columns)			
--scott�� ������ �ִ� FK ��ȸ
SELECT a.table_name "child_table",
       c.column_name "child_column",
       a.constraint_name "child_cons_name",
       b.table_name "Parent_table",
       a.r_constraint_name "parent_cons_name",
       d.column_name "parent_column"
FROM user_constraints a, user_constraints b, user_cons_columns c,
     (SELECT * FROM user_cons_columns)d
WHERE a.r_constraint_name = b.constraint_name
AND   a.constraint_name   = c.constraint_name
AND   a.r_constraint_name = d.constraint_name
AND   a.constraint_type   = 'R';