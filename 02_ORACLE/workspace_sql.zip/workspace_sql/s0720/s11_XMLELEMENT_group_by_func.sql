--XMLELEMENT(): XML�� ����� �ִ� �Լ�
--https://docs.oracle.com/en/database/oracle/oracle-database/19/sqlrf/index.html
SELECT deptno,
       XMLELEMENT("RPA",',' ,ename) "XML_NAME"
FROM emp
;

--XMLAGG
SELECT deptno,
       SUBSTR( XMLAGG( XMLELEMENT("RPA",',' ,ename) ORDER BY hiredate)
       .EXTRACT('//text()').getStringVal(),2)   "XML_NAME"
FROM emp
GROUP BY deptno
;
--<RPA>,CLARK</RPA><RPA>,MILLER</RPA><RPA>,KING</RPA>
--EXTRACT('//text()'): xml to text
--,CLARK,MILLER,KING
