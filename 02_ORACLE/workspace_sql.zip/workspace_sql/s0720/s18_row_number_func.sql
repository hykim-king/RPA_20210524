SELECT ename,
       empno,
       sal,
       RANK() OVER(ORDER BY sal DESC) "RANK",
       DENSE_RANK() OVER(ORDER BY sal DESC) "DENSE_RANK",
       ROW_NUMBER() OVER (ORDER BY sal DESC) "ROW_NUMBER",
       ROWID
FROM emp
;