--�޷� �����
SELECT  weekno,
        MAX(DECODE(day,'SUN',dayno,null)) "SUN",
        MAX(DECODE(day,'MON',dayno,null)) "MON",
        MAX(DECODE(day,'TUE',dayno,null)) "TUE",
        MAX(DECODE(day,'WED',dayno,null)) "WED",
        MAX(DECODE(day,'THU',dayno,null)) "THU",
        MAX(DECODE(day,'FRI',dayno,null)) "FRI",
        MAX(DECODE(day,'SAT',dayno,null)) "SAT"
FROM cal
GROUP BY weekno
ORDER BY weekno
;