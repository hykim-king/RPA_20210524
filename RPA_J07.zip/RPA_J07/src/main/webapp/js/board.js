/**
 * 
 */
function doRetrieve(){
  console.log("doRetrieve");
  
  var frm = document.boardFrm;
  
  frm.method = "get"; 
  frm.action = "/RPA_J07/board/board.do";
  alert("doRetrieve");
  frm.submit();
}   