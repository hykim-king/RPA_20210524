/**
 * let 변수1 = new 클래스명(매개변수1값, 매개변수2값,…);
 */
 
 class SubjectInfo{
  
  constructor(subject,credit){
    this.subject = subject;
    this.credit  = credit;
    
    this.days = [80,120,140];
    this.day  = this.days[0];
  }
  
  printOut(){
    return `과목:${this.subject},학점:${this.credit},수업일:${this.day}`;
  }
  
  get lessonTime(){
    return this.day;
  }
  
  set lessonTime(num){
    this.day = this.days[num];
  }
  
  
};

let sub01 = new SubjectInfo('html',1);

console.log(`sub01.subject:${sub01.subject}`);
console.log(`sub01.printOut():${sub01.printOut()}`);

//getter 호출: get lessonTime() -> this.days[0]
console.log(sub01.lessonTime);

//setter 호출 : ㄴet lessonTime(num) -> this.days[1];
sub01.lessonTime = 1;
console.log(sub01.lessonTime);


let sub02 = new SubjectInfo('css',2);
console.log(`sub02.subject:${sub02.subject}`);

sub02.lessonTime = 2;
console.log(sub02.lessonTime);




