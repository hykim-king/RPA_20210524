/**
 * 객체 생성자 함수(Object constructor function)
   생성자 함수는 일반 함수와 차이를 두기 위해 함수명 첫글자는 대문로 표현.
   Info this는 함수를 통해 생성되는 객체를 의미.
 */
 
 function Info(subject, credit){
  this.subject = subject;
  this.credit  = credit;
  
  this.printOut= function(){
    
    return this.subject +", "+this.credit +'학점';
  };
  
 };
 
 
 let subject01 = new Info('html',1);
 
 console.log(`subject01.subject:${subject01.subject}`);
 console.log(`subject01.credit:${subject01.credit}`);
 console.log(`subject01.printOut():${subject01.printOut()}`);
 
 let subject02 = new Info('css',2);
 console.log(`subject02.subject:${subject02.subject}`);
 console.log(`subject02.credit:${subject02.credit}`);
 console.log(`subject02.printOut():${subject02.printOut()}`);