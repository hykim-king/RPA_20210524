/**
 * property                                               
  객체의 메서드의 경우 다른 속성처럼 값의 변화가 없기 때문에 불필요하게 상속 시켜                                             
  메모리를 낭비 할 필요가 없습니다.                                             
  객체의 메서드를 생성자 함수내 추가하지 않고 추가, 호출.                                              
 */
 
 function Triangle(b,h){
  this.base = b;
  this.height = h;
}

Triangle.prototype.area = function(){
  return (this.base * this.height)/2;
}

Triangle.prototype.printOut = function(){
  return '밑변:'+this.base+' 높이:'+this.height +' 넓이:'+this.area();
}


let triangle01 = new Triangle(10,5);
console.log(`triangle01.area():${triangle01.area()}`);
console.log(`triangle01.printOut():${triangle01.printOut()}`);

