/**
 * static 키워드 
 */
/*
 class Article{
  static publisher = "한빛출판사";
  
  constructor(articleNumber){
    
    this.articleNumber = articleNumber;
    
  }
  
  static printPublisher(){
    
    console.log(Article.publisher);
  }
  
}

const ariticle01 = new Article(100);
console.log(`Article.publisher:${Article.publisher}`);
Article.printPublisher();
*/
