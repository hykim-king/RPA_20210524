/**
 * Shape(Parent)
 * Rectancle(Child), Triangle(Child)
 * 상속 
 */
 
 class Shape{
   constructor(width, height,color){
      this.width = width;
      this.height= height;
      this.color = color;
    
   }
  
   draw(){
     console.log(`drawing ${this.color} color!`);     
   }
   
   getArea(){
     return this.width * this.height;
  }
   
}

class Rectangle extends Shape{
  
}

const  rectangle = new Rectangle(20,20,'skyblue');

rectangle.draw();
console.log(rectangle.getArea());


class Triangle extends Shape{
  draw(){
    super.draw();
    console.log('red');
    
  }  
  
  getArea(){
    return (this.width * this.height)/2;
    
  }
  
  toString(){
    return `Triangle:color:${this.color}`;
    
  }
}

const triangle = new Triangle(20,20,'red');

triangle.draw();
console.log(triangle.getArea());

//instance of
console.log(`rectangle instanceof Shape:${rectangle instanceof Shape}`);
console.log(`triangle instanceof Shape:${triangle instanceof Shape}`);
console.log(`triangle instanceof Rectangle:${triangle instanceof Rectangle}`);








