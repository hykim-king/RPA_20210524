/**
 * 
 */
 
 window.onload = function(){
  
    let gnb = document.getElementById('gnb');
    //console.log(`gnb:${gnb}`);
    
    console.log(`gnb.parentNode: ${gnb.parentNode}`);
    //alert(gnb.parentNode);
    
    console.log(`gnb.children[0]: ${gnb.children[0]}`);
    console.log(`gnb.children[0].children[0]: ${gnb.children[0].children[0]}`);
    
    console.log(`gnb.children[0].children[0].nextElementSibling: ${gnb.children[0].children[0].nextElementSibling}`);
    console.log(`gnb.children[0].children[2].previousElementSibling: ${gnb.children[0].children[2].previousElementSibling}`);
    
    
    console.log(`gnb.children[0].firstChild: ${gnb.children[0].firstChild}`);
    console.log(`gnb.children[0].lastChild: ${gnb.children[0].lastChild}`);
    console.log(`gnb.id: ${gnb.id}`);
     console.log(`gnb.children[0].children[0].className: ${gnb.children[0].children[0].className}`);
};