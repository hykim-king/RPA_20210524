/**
 * 
 */
 
 window.onload = function(){
  let frm = document.frm;
  
  let date = new Date();
  let curYear = date.getFullYear();//년도 4자리
  
  console.log(`curYear:${curYear}`);
  //1970 ~ 2021까지 년도 생성
  for(let i=1970;i<=curYear;i++){
    frm.year.add(new Option(i,i));//동적으로 년도 추가
  }
  
  //월 추가: 1 ~12
  for(let i=1;i<=12;i++){
    frm.month.add(new Option(i,i));
    
  }
  
  //option을 3개로 
  frm.sub.length = 3;
  
};