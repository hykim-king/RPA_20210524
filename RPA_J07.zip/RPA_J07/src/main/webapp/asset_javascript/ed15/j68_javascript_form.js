/**
 * 
 */
window.onload = function() {
  console.log('window.onload');

  let frm01 = document.frm01;
  let frm02 = document.frm02;

  console.log(`frm01.search.placeholder:${frm01.search.placeholder}`);


  console.log(`frm02.subject.placeholder:${frm02.subject.placeholder}`);
  console.log(`frm02.credit.placeholder:${frm02.credit.placeholder}`);


  //form을 배열로
  
  console.log(document.forms[0].elements[0].placeholder);
  console.log(document.forms[1][1].placeholder);
  console.log(document.forms[1]['subject'].placeholder);
}
