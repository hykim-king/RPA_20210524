/**
 * 
 */
 
 window.onload = function(){
  
  let loginFrm = document.login;
  
  loginFrm.onsubmit = function(){
    //console.log('loginFrm.onsubmit()');
    //id입력 check
    if(!loginFrm.id.value){
      alert('아이디를 입력 하세요.');
      loginFrm.id.focus();
      
      return false;
    }  
    
    //비번 check
    if(!loginFrm.passwd.value){
      alert('비번을 입력 하세요.');
      loginFrm.passwd.focus();
      
      return false;
    }    
  };
  
};