/**
 * 
 */
 /* 입력 */
 //prompt('입력제목', "입력내용.");
 //document.write("자바스크립트!");
 //confirm("정말로 삭제 하시겠습니까?");
 alert("아이디를 입력 하세요.");
 console.log("자바스크립트");    
 