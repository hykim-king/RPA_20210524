/**
 * 가변인자
 */
 
 function showSubject(){
  
  for(let i=0;i<arguments.length;i++){
    console.log(`arguments[${i}]: ${arguments[i]}`);
  } 
  
 }
 
 
 showSubject('html','css','javascript');
 //arguments[0]: html
 //arguments[1]: css
 //arguments[2]: javascript
 
 showSubject('java','oracle','html','css','javascript');

 //arguments[0]: java
 //arguments[1]: oracle
 //arguments[2]: html
 //arguments[3]: css
 //arguments[4]: javascript