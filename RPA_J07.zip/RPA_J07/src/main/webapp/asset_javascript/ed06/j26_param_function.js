/**
 * 함수 parameter
 */
 
 function getAvg(s1,s2){
  let avg = (s1+s2)/2; 
  return avg;
 }
 
 //일반함수 param전달
 let avgResult = getAvg(90,95);
 console.log(`avgResult: ${avgResult}`);//avgResult: 92.5
 
 //익명함수 param전달
 let getAvgAnony = function(s1,s2){      
     return (s1+s2)/2
 };
 
 let avgResultAnony = getAvgAnony(90,95);
 console.log(`avgResultAnony:${avgResultAnony}`);//avgResultAnony:92.5
 
 //즉시 실행 함수 param전달
 (function(s1,s2){
    let avg = (s1+s2); 
    console.log(`avg:${avg}`);//avg:185
 })(90,95);