/**
 * 삼항 연산자
 */
 const name = "pcwk";
 console.log( name==="pcwk"?"Yes":"No");