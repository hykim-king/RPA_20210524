 //4. 대입 연산자
 let  x = 11;
 let  y = 13;
 
 x+=y;//x=x+y;
 console.log(`x+=y --> ${x}`);
 
 x = 11;
 y = 13;
 x-=y;//x=x-y;
 console.log(`x-=y --> ${x}`)
 
 x = 11;
 y = 13;
 x*= y;//x=x*y;
 console.log(`x*=y --> ${x}`); 
 
 x = 11;
 y = 13;
 x/= y; //x=x/y;
 console.log(`x/=y --> ${x}`)