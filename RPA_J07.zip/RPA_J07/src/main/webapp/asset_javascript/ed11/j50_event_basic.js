/**
 * 
 */
 
 var bt = document.getElementById("btnSave");
 console.log(bt);
 
 bt.onclick = function(){
     alert('btnSave click'); 
 };
         