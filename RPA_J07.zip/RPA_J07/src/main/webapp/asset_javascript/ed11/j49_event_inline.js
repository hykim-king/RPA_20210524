/**
 * 
 */
 
 function sum(n){
  alert(n); 
 }