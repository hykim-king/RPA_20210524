package com.pcwk.board;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.pcwk.ed01.BoardDao;
import com.pcwk.ed01.BoardVO;
import com.pcwk.ed01.SearchVO;

/**  
 * Servlet implementation class BoardController
 */
@WebServlet(description = "게시판", urlPatterns = { "/board/board.do" })
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final Logger LOG = Logger.getLogger(getClass());
	
	//Dao
	private BoardDao  dao;  
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardController() {
        super();
        LOG.debug("1. BoardController()");
        dao = new BoardDao();
        
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("2. doGet()");
		serviceHandler(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("2. doPost()");
		serviceHandler(request,response);
	}
    /**
     * method분기
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void serviceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	LOG.debug("3. serviceHandler()");
    	//request encoding: utf-8
    	request.setCharacterEncoding("utf-8");
    	//응답처리
    	response.setContentType("text/html; charset=utf-8");
    	
    	//작업분기
    	String workDiv = request.getParameter("work_div");
    	LOG.debug("workDiv:"+workDiv);
    	switch(workDiv) {
    		case  "doRetrieve" :
    			doRetrieve(request,response);
    			break;
    	}
    	
    	
    }
    

//	doReadCnt()
//	doRetrieve()
//	doUpdate()
//	doSelectOne()
//	doDelete()
//	doInsert()
    
    public void doRetrieve(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	SearchVO inVO =new SearchVO();
    	inVO.setSearchDiv("");
    	inVO.setPageNum(1);
    	inVO.setPageSize(10);
    	LOG.debug(" doRetrieve()");
    	List<BoardVO> list = dao.doRetrieve(inVO);
    	for(BoardVO vo:list) {
    		LOG.debug(vo);
    	}
    	
    	
    	
    }
    
    
    


}
