package com.pcwk.ed02.treemap;



public class MemberTreeMapMain {

	public static void main(String[] args) {
		MemberTreeMap memberTreeMap=new MemberTreeMap();
		
		Member  member03=new Member(1003, "������");
		Member  member01=new Member(1001, "BTS");
		Member  member02=new Member(1002, "������");
//key�� memberId(Integer) Comparable�� ������ �Ǿ� ����.		
//public final class Integer extends Number	implements Comparable<Integer>
		
		memberTreeMap.addMember(member03);
		memberTreeMap.addMember(member01);
		memberTreeMap.addMember(member02);
		
		memberTreeMap.showAllMember();
		memberTreeMap.removeMember(1002);
		memberTreeMap.showAllMember();
	}

}
