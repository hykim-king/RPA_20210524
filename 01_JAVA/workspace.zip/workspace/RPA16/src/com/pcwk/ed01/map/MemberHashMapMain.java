package com.pcwk.ed01.map;

public class MemberHashMapMain {

	public static void main(String[] args) {
		MemberHashMap memberHashMap=new MemberHashMap();
		
		Member  member01=new Member(1001, "BTS");
		Member  member02=new Member(1002, "������");
		Member  member03=new Member(1003, "������");

		
		memberHashMap.addMember(member01);
		memberHashMap.addMember(member02);
		memberHashMap.addMember(member03);
		
		memberHashMap.showAllMember();
		//����
		memberHashMap.removeMember(1002);
		memberHashMap.showAllMember();
	}

}
