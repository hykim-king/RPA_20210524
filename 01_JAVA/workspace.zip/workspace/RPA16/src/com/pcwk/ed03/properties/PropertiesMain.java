package com.pcwk.ed03.properties;

import java.util.Enumeration;
import java.util.Properties;
public class PropertiesMain {

	public static void main(String[] args) {
		Properties  prop=new Properties();
		//prop�� (key,value)�� ����
		prop.setProperty("timeout", "30");
		prop.setProperty("language", "kr");
		prop.setProperty("size", "10");

		
		//prop�� ����� ��ҵ��� 
		Enumeration<String> keys=  (Enumeration<String>) prop.propertyNames();
		
		while(keys.hasMoreElements()) {
			String key =keys.nextElement();
			System.out.println(key+","+prop.getProperty(key));
		}
		
	}

}
//size,10
//timeout,30
//language,kr