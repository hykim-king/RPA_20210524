package com.pcwk.ed03.properties;

import java.util.*;

import org.apache.log4j.Logger;

public class SystemPropertiesMain {
    static Logger  LOG = Logger.getLogger(SystemPropertiesMain.class);
    
    
	public static void main(String[] args) {
		Properties  sysProp = System.getProperties();
		//System.out.println(sysProp.getProperty("java.version"));
		LOG.info(sysProp.getProperty("java.version"));
		
		//prop�� ����� ��ҵ��� 
		Enumeration<String> keys=  (Enumeration<String>) sysProp.propertyNames();
		
		while(keys.hasMoreElements()) {
			String key =keys.nextElement();
			//System.out.println(key+","+sysProp.getProperty(key));
		}		
	}

}
