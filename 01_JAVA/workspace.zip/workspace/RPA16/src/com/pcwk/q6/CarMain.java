package com.pcwk.q6;

public class CarMain {

	public static void main(String[] args) {
		//�̱������� ��ü ����.
		CarFactory  factory = CarFactory.getInstance();

		Car sonata01 = factory.createCar("���� ��");
		Car sonata02 = factory.createCar("���� ��");
		
		System.out.println("sonata01==sonata02  =>"+(sonata01==sonata02));
		
		Car avante01 = factory.createCar("�¿� ��");
		Car avante02 = factory.createCar("�¿� ��");		
		System.out.println("avante01==avante02  =>"+(avante01==avante02));
		
		System.out.println("sonata01==avante01  =>"+(sonata01==avante01));
	}

}
//sonata01==sonata02  =>true
//avante01==avante02  =>true
//sonata01==avante01  =>false