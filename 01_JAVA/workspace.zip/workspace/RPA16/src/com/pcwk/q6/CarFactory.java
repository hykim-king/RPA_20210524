package com.pcwk.q6;

import java.util.HashMap;

public class CarFactory {

	private static CarFactory  carFactory = new CarFactory();
	private HashMap<String,Car> hashMap   = new HashMap<>();
	
	private CarFactory() {}
	
	public static CarFactory  getInstance() {
		
		if(carFactory==null) {
			return new CarFactory();
		}
		
		return carFactory;
		
	}
	
	public Car createCar(String name) {
		//hashMap Car��ü�� ã�´�.
		if(hashMap.containsKey(name)) {
			return hashMap.get(name);
		}
		
		
		Car car=new Car(name);
		hashMap.put(name, car);
		return car;
	}
	
}
