package com.pcwk.q6;

public class Car {

	String name;

	public Car() {
		super();
	}

	public Car(String name) {
		super();
		this.name = name;
	}
	
	
	
}
