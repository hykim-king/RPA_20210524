package com.pcwk.ed06.exceptions;

public class ExceptionWorkFlowMain {

	public static void main(String[] args) {
		System.out.println("1");
		System.out.println("2");
		try {
			System.out.println("3");
			System.out.println(1/0);
			System.out.println("4");//������� ����.
		}catch(ArithmeticException e) {
			//java.lang.ArithmeticException: / by zero
			//e.printStackTrace();
			System.out.println("5");
		}

		System.out.println("6");
	}

}
//1
//2
//3
//5
//6