package com.pcwk.q5;

public class Student {

	private String studentId;
	private String studentName;
	
	public Student(String studentId, String studentName) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
	}
	
	
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	@Override
	public String toString() {
		return studentId+" : "+studentName;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result += prime *  Integer.parseInt(studentId);
		return result;
	}
	@Override
	public boolean equals(Object obj) {

		Student other = (Student) obj;
		if (studentId == null) {
			if (other.studentId != null)
				return false;
		} else if (!studentId.equals(other.studentId))
			return false;
		return true;
	}
	
	
}
