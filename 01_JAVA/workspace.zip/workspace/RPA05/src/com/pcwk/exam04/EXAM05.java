package com.pcwk.exam04;

public class EXAM05 {

	public static void main(String[] args) {
		int lineCount  = 7;//�ܺ� for
		int spaceCount = 5;//�����  
		int starCount  = 1;//��
		
		char start     ='*';
		char blank     =' ';   
		//	      *     
		//	     ***    
		//	    *****   
		//	   *******  
		//	    *****   
		//	     ***    
		//	      *     

		for (int i = 0; i < lineCount; i++) {
			//
			for (int j = 0; j < spaceCount; j++) {
				System.out.print(blank);
			}
			for (int j = 0; j < starCount; j++) {
				System.out.print(start);
			}
			for (int j = 0; j < spaceCount; j++) {
				System.out.print(blank);
			}
			
			if(i<spaceCount) {//
				spaceCount -= 1;//space�� ����
				starCount  += 2;//���� 2�� ����
			}else {
				spaceCount += 1;//
				starCount  -= 2;//���� 2�� ����
			}
			System.out.println();
		}

	}

}
