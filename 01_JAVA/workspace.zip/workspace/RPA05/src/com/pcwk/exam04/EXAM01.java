package com.pcwk.exam04;

public class EXAM01 {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 2;
		
		double result = 0;
		char  operator = '+';
		
		if(operator == '+') {
			result = num1+num2;
		}else if(operator == '-') {
			result = num1-num2;
		}else if(operator == '*') {
			result = num1*num2;
		}else if(operator == '/') {
			result = num1/num2;
		}else {
			System.out.println("�����ڸ� Ȯ�� �ϼ���.");
			return;
		}

		
		System.out.println(num1+(""+operator)+num2+"="+result);
	}

}
