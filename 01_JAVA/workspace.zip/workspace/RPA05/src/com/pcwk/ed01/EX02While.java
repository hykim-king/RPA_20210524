package com.pcwk.ed01;

public class EX02While {

	public static void main(String []args) {
		int num =1;
		int sum =0;
		
		while(num<=10) {
			//System.out.println(num);
			sum+=num;//sum=sum+num
			//System.out.println(sum);
			num++;
		}
		System.out.println("1���� 10���� ���� "+sum+"�Դϴ�.");
	}
}
