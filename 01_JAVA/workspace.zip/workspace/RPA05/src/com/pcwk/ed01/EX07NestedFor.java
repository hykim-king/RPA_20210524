package com.pcwk.ed01;

public class EX07NestedFor {
    //����:ctrl+F11
	//�����:F11
	public static void main(String[] args) {
		// 3~7�� ���
		int dan;
		int times;
		
		for(dan=3;dan<=7;dan++) {
			
			for(times=1;times<=9;times++) {
				System.out.println(dan+"*"+times+"="+(dan*times));
			}
			System.out.println();
			
		}
		

	}

}
