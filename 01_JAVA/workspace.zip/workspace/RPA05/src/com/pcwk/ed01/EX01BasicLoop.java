package com.pcwk.ed01;

public class EX01BasicLoop {

	public static void main(String[] args) {
		// 1 ~ 10����
		int num =1;
		num +=2;//num = num +2;
		num +=3;//num = num +3;
		num +=4;
		num +=5;
		num +=6;
		num +=7;
		num +=8;
		num +=9;
		num +=10;
		System.out.println("1~10���� ���� "+num+" �Դϴ�.");

	}

}
