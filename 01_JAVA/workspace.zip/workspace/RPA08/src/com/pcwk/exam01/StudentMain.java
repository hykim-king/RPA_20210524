package com.pcwk.exam01;



public class StudentMain {

	public static void main(String[] args) {
		Student student01=new Student();
		student01.setStudentName("ȫ�浿");
		System.out.println(Student.getSerialNum());
		System.out.println(Student.getStudentCard());
		System.out.println(student01.studentName+" �й�:"+student01.studentId+" �л�ī���ȣ:"+Student.getStudentCard());
		System.out.println("===============================================");
		
		
		Student student02=new Student();
		student02.setStudentName("�̻�");
		System.out.println(Student.getSerialNum());
		System.out.println(Student.getStudentCard());
		System.out.println(student02.studentName+" �й�:"+student02.studentId+" �л�ī���ȣ:"+Student.getStudentCard());
				
	}

}
//1001
//1101
//ȫ�浿 �й�:1001 �л�ī���ȣ:1101
//===============================================
//1002
//1102
//�̻� �й�:1002 �л�ī���ȣ:1102