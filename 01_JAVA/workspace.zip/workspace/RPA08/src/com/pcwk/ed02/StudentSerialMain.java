package com.pcwk.ed02;

public class StudentSerialMain {

	public static void main(String[] args) {
		Student   student01=new Student();
		student01.setStudentName("�̽�ȯ");
		System.out.println(student01.serialNum);
		System.out.println(student01.getStudentName()+" �й�:"+student01.studentId);
		System.out.println("====================================================");
		
		Student   student02=new Student();
		student02.setStudentName("��ȿ��");
		System.out.println(student02.serialNum);
		System.out.println(student02.getStudentName()+" �й�:"+student02.studentId);
	}

}
//1001
//�̽�ȯ �й�:1001
//====================================================
//1002
//��ȿ�� �й�:1002