package com.pcwk.ed03;

public class StudentMain {

	public static void main(String[] args) {
		Student student01=new Student();
		student01.setStudentName("�̽�ȯ");
		System.out.println(Student.getSerialNum());//static �޼��� ȣ��
		System.out.println(student01.studentName+" �й�:"+student01.studentId);
		System.out.println("===============================================");
		
		Student student02=new Student();
		student02.setStudentName("��ȿ��");
		System.out.println(Student.getSerialNum());//static �޼��� ȣ��
		System.out.println(student02.studentName+" �й�:"+student02.studentId);
	}

}
