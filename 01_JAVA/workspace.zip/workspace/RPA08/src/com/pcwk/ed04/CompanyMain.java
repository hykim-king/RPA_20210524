package com.pcwk.ed04;

public class CompanyMain {

	public static void main(String[] args) {
		//The constructor Company() is not visible
		//Company company=new Company();

		
		Company company01= Company.getInstance();
		Company company02= Company.getInstance();
		
		System.out.println(company01==company02);
		System.out.println("company01:"+company01);
		System.out.println("company02:"+company02);
	}

}
//true
//company01:com.pcwk.ed04.Company@15db9742
//company02:com.pcwk.ed04.Company@15db9742