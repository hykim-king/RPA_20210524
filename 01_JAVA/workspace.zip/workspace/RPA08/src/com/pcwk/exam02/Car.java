package com.pcwk.exam02;

public class Car {
	
	private static int carSerialNum = 10_001;//�ø��� ��ȣ
	private int carNum;//�ڵ��� ��ȣ

	public Car() {
		carSerialNum++;
		carNum = carSerialNum;
	}

	public int getCarNum() {
		return carNum;
	}

	public void setCarNum(int carNum) {
		this.carNum = carNum;
	}
	


}
