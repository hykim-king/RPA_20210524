package com.pcwk.exam02;

import com.pcwk.ed04.Company;

public class CarFactory {

	private static CarFactory  instance=new CarFactory();
	
	private CarFactory() {
		
	}
	
	public static CarFactory getInstance() {
		if(null == instance) {
			instance =new CarFactory();
		}
		
		return instance;
	}
	
	
	
	public Car createCar() {
		return new Car();
	}
	
}
