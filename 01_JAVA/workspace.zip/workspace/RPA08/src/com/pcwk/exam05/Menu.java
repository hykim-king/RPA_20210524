package com.pcwk.exam05;

public class Menu {
	//StarCoffee
	public static final int STAR_AMERICANO = 4_000;
	public static final int STAR_LATTE = 4_300;
	
	//BeanCoffee
	public static final int BEAN_AMERICANO = 4_100;
	public static final int BEAN_LATTE = 4_500;
	

}
