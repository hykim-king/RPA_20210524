package com.pcwk.exam07;

public class Card {

	
	private static int serialNum = 10_000;//�ø��� ��ȣ
	private int cardNum ;//ī���ȣ
	
	public Card() {
		serialNum++;
		cardNum = serialNum;
	}

	public int getCardNum() {
		return cardNum;
	}

	public void setCardNum(int cardNum) {
		this.cardNum = cardNum;
	}
	
	
}
