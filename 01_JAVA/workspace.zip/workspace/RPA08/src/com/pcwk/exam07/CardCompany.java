package com.pcwk.exam07;

public class CardCompany {

	private static CardCompany  instance=new CardCompany();
	
	private CardCompany() {
		
	}
	
	
	public static CardCompany getInsternce() {
		if(null == instance) {
			instance = new CardCompany();
		}
		
		return instance;		
	}
	
	//Card return 
	public Card createCard() {
		return new Card();
	}
}
