package com.pcwk.exam07;

public class CardCompanyMain {

	public static void main(String[] args) {
		CardCompany  cardCompany= CardCompany.getInsternce();
		
		Card card01 = cardCompany.createCard();
		Card card02 = cardCompany.createCard();
		
		System.out.println(card01.getCardNum());
		System.out.println(card02.getCardNum());

	}

}
//10001
//10002
