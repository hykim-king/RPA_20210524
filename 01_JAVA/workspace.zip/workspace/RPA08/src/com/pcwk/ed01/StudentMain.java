package com.pcwk.ed01;

public class StudentMain {

	public static void main(String[] args) {
		Student  student01=new Student();
		student01.setStudentName("������");
		
		System.out.println(student01.getStudentName());
		System.out.println(student01.serialNum);
		System.out.println("=======================");
		student01.serialNum++;
		
		
		Student  student02=new Student();
		student02.setStudentName("��");
		System.out.println(student02.getStudentName());
		System.out.println(student02.serialNum);
	}

}
