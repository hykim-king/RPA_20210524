package com.pcwk.ed01;

public class Student {

	public static int serialNum = 100;//static������ �ν��Ͻ� ������ ����
	
	public int studentId;
	public String studentName;
	public int grade;
	public String address;
	
	
	public Student() { }
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
}
