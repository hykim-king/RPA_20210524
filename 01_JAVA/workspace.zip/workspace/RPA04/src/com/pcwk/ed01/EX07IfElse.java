package com.pcwk.ed01;

public class EX07IfElse {

	public static void main(String[] args) {
		int score = 89;
		char grade = ' ';
		
		if(score>=90) {
			grade = 'A';
		}else {
			grade = 'B';
		}
		
		System.out.println("grade="+grade);
		
		//--------------------------------
		// ���� ������(���� ������)
		//--------------------------------
		grade = (score>=90) ? 'A':'B';
		System.out.println("grade="+grade);
	}

}
