package com.pcwk.ed01;

public class EX02IfElse {

	public static void main(String[] args) {
		char gender = 'M';
		
		if(gender=='F') {
			System.out.println("���� �Դϴ�.");
		}else {
			System.out.println("���� �Դϴ�.");
		}

	}

}
