package com.pcwk.ed03;

public class EX08SwitchCase {

	public static void main(String[] args) {
		int ranking = 3;//���
		
		char medalColor;//�޴޻���
		
		switch(ranking) {
			case 1:
				medalColor = 'G';
				break;
			case 2:
				medalColor = 'S';
				break;
			case 3:
				medalColor = 'B';
				break;		
			default:
				medalColor = ' ';
				break;
		}

		System.out.println(ranking+"�� �޴��� ������ "+medalColor+"�Դϴ�.");
	}

}
