package com.pcwk.ed03;

public class EX12SwitchCase {

	public static void main(String[] args) {
		int floor = 5;

		String shopName = "";

		switch (floor) {
			case 1:
				shopName = "�౹";
				break;
			case 2:
				shopName = "�����ܰ�";
				break;
			case 3:
				shopName = "�Ǻΰ�";
				break;
			case 4:
				shopName = "ġ��";
				break;
			case 5:
				shopName = "�ｺ Ŭ��";
				break;
			default:
				shopName = "";
				break;
		}

		System.out.println(floor + "�� " + shopName + " �Դϴ�.");
	}

}
