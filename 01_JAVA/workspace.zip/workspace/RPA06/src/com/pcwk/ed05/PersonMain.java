package com.pcwk.ed05;

public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person();

		Person personName=new Person("������");
	
		System.out.println(personName.name);
		
		Person person03=new Person("������",165.5F,45.0F);
		System.out.println(person03.name);
		System.out.println(person03.height);
		System.out.println(person03.weight);
	}

}
