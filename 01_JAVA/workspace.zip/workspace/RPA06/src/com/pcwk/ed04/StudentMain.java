package com.pcwk.ed04;

public class StudentMain {

	public static void main(String[] args) {
		Student student=new Student();
		student.name = "�̻�";
		
		System.out.println(student.name);
		System.out.println(student.getName());

		
		Student student02=new Student();
		student02.name = "�㳭��";
		System.out.println(student02.name);
		System.out.println(student02.getName());
		
		//heap �޸� �ּ� 
		System.out.println("student:"+student);
		System.out.println("student02:"+student02);
		
	}

}
