package com.pcwk.ed01;

public class Student {

	//------------------------------//
	//-�Ӽ�                          //
	//------------------------------//
	int studentId; //�й�
	String name;   //�̸�
	int grade;     //�г�
	String address;//�ּ�
	
	//------------------------------//
	//-method,function              //
	//------------------------------//	
	public void showStudentInfo() {
		System.out.println(name+","+address);//�̸��� �ּҸ� ���
	}
	
	
}
