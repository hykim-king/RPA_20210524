package com.pcwk.ed01;

public class EX02FunctionMain {

	public static void main(String[] args) {
		int first = 10;
		int second= 13;
		
		
		int sum = add(first,second);
		System.out.println(first+"+"+second +"="+sum);

	}
	
	
	public static int add(int num01,int num02) {
		int result = num01+num02;
		
		return result;
	}

}
