package com.pcwk.ed07;

public class StringEx02Main {

	public static void main(String[] args) {
		String javaStr=new String("java");
		String webStr =new String("Web");
		
		System.out.println("javaStr �ּ�:"+System.identityHashCode(javaStr));
		System.out.println(javaStr);
		System.out.println(webStr);
		
		javaStr=javaStr.concat(webStr);
		
		
		System.out.println(javaStr);
		System.out.println("javaStr �ּ�:"+System.identityHashCode(javaStr));
	}

}
//javaStr �ּ�:366712642
//java
//Web
//javaWeb
//javaStr �ּ�:1829164700
