package com.pcwk.ed09;

public class WrapperEx01Main {

	public static void main(String[] args) {
		Integer  iValue =new Integer(100);
		
		int myValue     =iValue.intValue();
		
		System.out.println("myValue:"+myValue);
		
		
		String num01 = "100";
		
		int num01Re = Integer.parseInt(num01);
		System.out.println( num01Re+10 );
		
		System.out.println("int �ִ밪:"+Integer.MAX_VALUE);
		System.out.println("int MIN_VALUE:"+Integer.MIN_VALUE);
		System.out.println("=Byte==============================");
		System.out.println("Byte.MAX_VALUE:"+Byte.MAX_VALUE);
		System.out.println("Byte.MIN_VALUE:"+Byte.MIN_VALUE);
		
	}

}
//int �ִ밪:2147483647
//int MIN_VALUE:-2147483648