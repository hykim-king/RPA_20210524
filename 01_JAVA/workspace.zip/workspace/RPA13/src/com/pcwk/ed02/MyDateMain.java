package com.pcwk.ed02;

public class MyDateMain {

	public static void main(String[] args) {
		MyDate date01=new MyDate(10, 6, 2021);
		MyDate date02=new MyDate(10, 6, 2021);
		//true
		System.out.println(date01.equals(date02));

	}

}
