package com.pcwk.ed06;

public class CloneMain {

	public static void main(String[] args) throws CloneNotSupportedException {
		Circle circle      = new Circle(10, 20, 5);
		Circle cloneObject = (Circle) circle.clone();

		
		System.out.println(circle);
		System.out.println(cloneObject);
		
		System.out.println(System.identityHashCode(circle));
		System.out.println(System.identityHashCode(cloneObject));
	}

}
//Circle [point=Point [x=10, y=20], radius=5]
//Circle [point=Point [x=10, y=20], radius=5]
//366712642
//1829164700


