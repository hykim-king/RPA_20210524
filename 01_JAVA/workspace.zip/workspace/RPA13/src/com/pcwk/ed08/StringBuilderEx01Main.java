package com.pcwk.ed08;

public class StringBuilderEx01Main {

	public static void main(String[] args) {
		
		String javaStr=new String("java");
		System.out.println("javaStr:"+System.identityHashCode(javaStr));
		
		
		StringBuilder  buffer=new StringBuilder(javaStr);
		System.out.println("buffer:"+System.identityHashCode(buffer));
		
		buffer.append(" and");
		buffer.append(" android");
		buffer.append(" progamming is fun!!");
		
		System.out.println("buffer:"+System.identityHashCode(buffer));
		System.out.println(buffer.toString());
		System.out.println("================================");
		javaStr = buffer.toString();
		System.out.println(javaStr);
		System.out.println("javaStr:"+System.identityHashCode(javaStr));
		
	}

}
