package com.pcwk.ed04;

public class Student {
	private int studentId;     //�й�
	private String studentName;//�̸�
	
	public Student() {
		super();
	}
	public Student(int studentId,String studentName) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
//	@Override
//	public String toString() {
//		return "Student [studentId=" + studentId + ", studentName=" + studentName + "]";
//	}
	
	@Override
	public int hashCode() {
		return studentId;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Student) {
			Student std = (Student)obj;
			
			if(this.studentId == std.studentId) {
				return true;
			}else {
				return false;
			}
		}
		
		
		return false;
		
	}
	
}
