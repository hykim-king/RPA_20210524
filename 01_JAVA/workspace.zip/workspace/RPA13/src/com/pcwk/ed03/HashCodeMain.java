package com.pcwk.ed03;

public class HashCodeMain {

	public static void main(String[] args) {
		String str01=new String("abc");
		String str02=new String("abc");
		
		//������ �����ʹ� ������ hashcode ����
		System.out.println(str01.hashCode());
		System.out.println(str02.hashCode());

		
		Integer  i01=new Integer(100);
		Integer  i02=new Integer(100);
		
		System.out.println(i01.hashCode());
		System.out.println(i02.hashCode());
		
		
	}

}
//96354
//96354
//100
//100