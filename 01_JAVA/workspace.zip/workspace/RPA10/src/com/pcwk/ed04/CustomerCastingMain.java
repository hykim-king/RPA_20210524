package com.pcwk.ed04;

import com.pcwk.ed02.VIPCustomer;
import com.pcwk.ed02.Customer;
public class CustomerCastingMain {

	public static void main(String[] args) {
		Customer  vc = new VIPCustomer();
		

	}

}
