package com.pcwk.ed02;

public class CustomerMain {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.setCustomerId(10010);
		customer.setCustomerName("�̼���");
		customer.setBonusPoint(1_000);
		
		System.out.println(customer.showCustomerInfo());
		
		System.out.println("=============================");
		VIPCustomer vipCustomer=new VIPCustomer();
		vipCustomer.setCustomerId(10020);
		vipCustomer.setCustomerName("������");
		vipCustomer.setBonusPoint(10_000);
		System.out.println(vipCustomer.showCustomerInfo());
	}

}
