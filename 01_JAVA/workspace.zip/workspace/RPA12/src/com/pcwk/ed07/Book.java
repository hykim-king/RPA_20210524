package com.pcwk.ed07;

public class Book {

	int bookNumber;
	String bookTitle;
	
	
	public Book(int bookNumber, String bookTitle) {
		super();
		this.bookNumber = bookNumber;
		this.bookTitle = bookTitle;
	}


	@Override
	public String toString() {
		return "Book [bookNumber=" + bookNumber + ", bookTitle=" + bookTitle + "]";
	}


//alt+shift+s
	
}
