package com.pcwk.ed07;

public class ToStringMain {
    
	public static void main(String[] args) {
		Book book=new Book(2, "����");
		
		System.out.println(book.toString());
		//ũ�����̸�@�ؽ��ڵ�
		//com.pcwk.ed07.Book@15db9742
		System.out.println(book);

		System.out.println("====================================");
		String str =new String("������");
		System.out.println("str:"+str.toString());
		
		Integer inte=new Integer("100");
		System.out.println("inte:"+inte);
		
	}

}
