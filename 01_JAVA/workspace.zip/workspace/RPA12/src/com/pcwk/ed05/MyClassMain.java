package com.pcwk.ed05;

public class MyClassMain {

	public static void main(String[] args) {
		MyClass mClass=new MyClass();
		X x=mClass;
		x.x();
		
		Y y=mClass;
		y.y();

		System.out.println("===============================");
		
		MyInterface myInter = mClass;
		myInter.x();
		myInter.y();
		myInter.myMethod();
	}

}
