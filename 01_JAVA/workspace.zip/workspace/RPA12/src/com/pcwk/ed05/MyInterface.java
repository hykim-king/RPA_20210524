package com.pcwk.ed05;

public interface MyInterface extends X, Y {
	void myMethod();
}
