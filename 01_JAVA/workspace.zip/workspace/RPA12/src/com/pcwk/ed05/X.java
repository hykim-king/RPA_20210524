package com.pcwk.ed05;

public interface X {
	void x();
}
