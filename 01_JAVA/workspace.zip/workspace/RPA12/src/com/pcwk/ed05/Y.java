package com.pcwk.ed05;

public interface Y {
	void y();
}
