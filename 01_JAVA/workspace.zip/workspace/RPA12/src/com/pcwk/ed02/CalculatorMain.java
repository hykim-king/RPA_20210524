package com.pcwk.ed02;

public class CalculatorMain {

	public static void main(String[] args) {
		int num1 =10;
		int num2 =5;
		
		CompleteCalculator   calc=new CompleteCalculator();
		System.out.println("num1="+num1);
		System.out.println("num2="+num2);
		System.out.println("���ϱ�="+calc.add(num1, num2));
		System.out.println("����="+calc.substract(num1, num2));
		System.out.println("���ϱ�="+calc.times(num1, num2));
		System.out.println("������="+calc.divide(num1, num2));

		
		calc.description();
		
		int [] arr= {1,2,3,4,5,6,7,8,9,10};
		System.out.println(Calc.total(arr));
	}

}
