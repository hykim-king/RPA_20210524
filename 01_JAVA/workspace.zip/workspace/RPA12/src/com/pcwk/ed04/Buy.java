package com.pcwk.ed04;

public interface Buy {

	void buy();
	
	default void order() {
		System.out.println("�����ֹ�");
	}
}
