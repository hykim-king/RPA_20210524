package com.pcwk.ed04;

public class CustomerMain {

	public static void main(String[] args) {
		Customer  customer=new Customer();
		
		Buy buyer=customer;
		
		buyer.buy();
		buyer.order();
		
		Sell seller = customer;
		seller.sell();
		seller.order();
		System.out.println(seller instanceof Customer);
		if(seller instanceof Customer) {
			Customer cust02=(Customer) seller;
			cust02.buy();
			cust02.sell();
		}
		
		customer.order();

	}

}
