package com.pcwk.ed08;

public class Student {
    //setter,getter ����Ű
	//alt+shift+s
	int studentId;  //�й�
	private String name;    //�̸�
	int grade;      //�г�
	String address; //�ּ�
	
	public Student() {}
	
	public Student(int studentId, String name) {
		super();
		this.studentId = studentId;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", grade=" + grade + ", address=" + address + "]";
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String pName) {
		name = pName;
	}

	public int getStudentId() {   
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	
	
	
	
}
