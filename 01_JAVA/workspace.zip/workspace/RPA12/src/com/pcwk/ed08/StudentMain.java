package com.pcwk.ed08;

public class StudentMain {

	public static void main(String[] args) {
		Student student=new Student();
		//student.name = "ȫ�浿";
		
		student.setName("ȫ�浿");
		
		System.out.println(student.getName());
		System.out.println("============================");
		//System.out.println(student);
		
		Student student02=new Student(10020,"�̻�");
		System.out.println(student02);
	}

}
