package com.pcwk.ed03;

public interface Sell {
	void sell();
}
