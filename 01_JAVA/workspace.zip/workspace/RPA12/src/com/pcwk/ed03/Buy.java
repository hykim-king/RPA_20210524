package com.pcwk.ed03;

public interface Buy {

	void buy();
}
