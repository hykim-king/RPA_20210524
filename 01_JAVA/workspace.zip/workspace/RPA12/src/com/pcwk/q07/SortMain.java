package com.pcwk.q07;

import java.io.IOException;
import java.util.Arrays;

public class SortMain {

	public static void main(String[] args) throws IOException {
		System.out.println("���� ����� ���� �ϼ���.");
		System.out.println("B: BubbleSort ");
		System.out.println("H: HeapSort ");
		System.out.println("Q: QuickSort ");
		
		int ch = System.in.read();
		
		Sort sort = null;
		
		if(ch=='B' || ch=='b') {
			sort = new BubbleSort();
		}else if(ch=='H' || ch=='h') {
			sort = new HeapSort();
		}else if(ch=='Q' || ch=='q') {
			sort = new QuickSort();
		}else {
			System.out.println("�������� �ʴ� ��� �Դϴ�.");
			return;
		}
		
		//int[] arr = {10,9,7,8,1,2,3,4,5,6};
		int[] arr = {7,4,5,1,3};
		//Arrays API
		Arrays.sort(arr);
		System.out.println("========================");
		System.out.println(Arrays.toString(arr));
		System.out.println("========================");
		//----------------------------------------------
		
		sort.ascending(arr);
		sort.descending(arr);
		sort.description();

	}

}
