package com.pcwk.q07;

public class BubbleSort implements Sort {

	@Override
	public void ascending(int[] numArray) {
		System.out.println("BubbleSort ascending");
	
		int n = numArray.length -1;
		
		for(int i=n;i>0;i-- ) {
			//i=4,3,2,1
			for( int j=0;j<i;j++) {
				//0,1,2,3
				//0,1,2
				//0,1
				//0
				//asc
				if(numArray[j]>numArray[j+1]) {
					int tempNum = numArray[j];
					numArray[j] = numArray[j+1];
					numArray[j+1] = tempNum;
				}
			}
			
		}
		
		printArray(numArray);
	}
	
	
	//���� ��� ���
	public void printArray(int[] numArray) {
		for(int i=0;i<numArray.length;i++) {
			System.out.print(numArray[i]+",");
		}
		System.out.println();		
	}
	
	

	@Override
	public void descending(int[] numArray) {
		System.out.println("BubbleSort descending");
		int n = numArray.length -1;
		
		for(int i=n;i>0;i-- ) {
			for( int j=0;j<i;j++) {
				if(numArray[j]<numArray[j+1]) {
					int tempNum = numArray[j];
					numArray[j] = numArray[j+1];
					numArray[j+1] = tempNum;
				}
			}
		}
		
		printArray(numArray);		

	}

	@Override
	public void description() {
		
		Sort.super.description();
		System.out.println("BubbleSort �Դϴ�.");

	}

}
