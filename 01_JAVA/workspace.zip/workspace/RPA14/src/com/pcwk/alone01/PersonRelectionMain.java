package com.pcwk.alone01;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PersonRelectionMain {

	public static void main(String[] args) throws ClassNotFoundException {
		Class strClass = Class.forName("com.pcwk.alone01.Person");
		
		Constructor[]  cons = strClass.getConstructors();
		
		//���� for: ��� ������ ���
		int i=1;
		for(Constructor c  :cons) {
			System.out.println(i+"."+c);
			i++;
		}
		System.out.println("=================================================");
		
		//�޼��� ���� ���
		Method[] methods = strClass.getMethods();
		i=1;
		for(Method m  :methods) {
			System.out.println(i+"."+m);
			i++;
		}
		System.out.println("=================================================");
		
		//�������:public ������ ���
		Field[] fileds = strClass.getFields();
		for(Field f   :fileds) {
			System.out.println(f);
		}		

	}

}
