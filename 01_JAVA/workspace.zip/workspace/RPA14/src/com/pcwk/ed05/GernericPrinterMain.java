package com.pcwk.ed05;

public class GernericPrinterMain {

	public static void main(String[] args) {
		GenericPrinter<Powder> powderPrinter=new GenericPrinter<>();
		powderPrinter.setMaterial(new Powder());
		System.out.println(powderPrinter.toString());
		System.out.println("===========================");
		
		GenericPrinter<Plastic> plasticPrinter=new GenericPrinter<>();
		plasticPrinter.setMaterial(new Plastic());
		System.out.println(plasticPrinter.toString());		
		
		//Water Material�� ��� ���� �����Ƿ� 
		//GenericPrinter<Plastic> plasticPrinter=new GenericPrinter<>();
		//GenericPrinter<Water> waterPrinter=new GenericPrinter<>();

	}

}
