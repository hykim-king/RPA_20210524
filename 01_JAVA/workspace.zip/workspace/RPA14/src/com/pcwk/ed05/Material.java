package com.pcwk.ed05;

public abstract class Material {

	public abstract void doPrinting();
	
}
