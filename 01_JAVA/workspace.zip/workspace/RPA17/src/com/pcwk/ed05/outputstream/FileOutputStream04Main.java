package com.pcwk.ed05.outputstream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStream04Main {

	public static void main(String[] args) {
		//try - with - resource: close() �ڵ� ȣ��(�ڿ��ݳ� �ڵ����� ó��)
		//try(FileOutputStream fos=new FileOutputStream("output02.txt");){
		try(FileOutputStream fos=new FileOutputStream("output03.txt",true)){
			byte[] alpha=new byte[26];
			byte  data   = 65;//�빮�� A
			
			//A~Z alpha �迭�� �Է�
			for(int i=0;i<alpha.length;i++) {
				alpha[i] = data;
				data++;
			}
			//�迭�� �ι�°(B) 10�� ���
			fos.write(alpha,1,10);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("��� �Ϸ�");

	}

}
//BCDEFGHIJK