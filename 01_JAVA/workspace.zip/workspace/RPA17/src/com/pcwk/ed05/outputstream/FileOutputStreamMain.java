package com.pcwk.ed05.outputstream;

import java.io.*;

public class FileOutputStreamMain {

	public static void main(String[] args) {
		//���Ͽ� 1byte�� ���
		//65->A
		
		try(FileOutputStream fos=new FileOutputStream("output.txt");) {
			fos.write(65);
			fos.write(66);
			fos.write(67);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		System.out.println("���� ���� �Ϸ�.");
		
	}

}
