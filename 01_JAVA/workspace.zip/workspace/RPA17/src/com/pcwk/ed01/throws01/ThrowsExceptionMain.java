package com.pcwk.ed01.throws01;

import org.apache.log4j.*;
import java.io.*;

public class ThrowsExceptionMain {

	final static Logger  LOG = Logger.getLogger(ThrowsExceptionMain.class);
	/**
	 * ���� ������
	 * @param fileName
	 * @param className
	 * @return
	 * @throws FileNotFoundException
	 * @throws ClassNotFoundException 
	 */
	public Class loadClass(String fileName,String className) throws FileNotFoundException, ClassNotFoundException  {
		
		FileInputStream fis=new FileInputStream(className);
		Class c =Class.forName(className);
		return c;
	}
	
	
	public static void main(String[] args) {
		LOG.debug("===============================");
		LOG.debug("log4j");
		LOG.debug("===============================");
		
		ThrowsExceptionMain throwsExceptionMain=new ThrowsExceptionMain();
		//�޼��带 ȣ���� ������ ����ó��

		try {
			throwsExceptionMain.loadClass("b.txt", "java.lang.String");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
