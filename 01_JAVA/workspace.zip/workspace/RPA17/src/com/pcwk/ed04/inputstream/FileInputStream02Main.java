package com.pcwk.ed04.inputstream;

import java.io.*;

public class FileInputStream02Main {

	public static void main(String[] args) {
	   //�ѱ�
	   //D:\\RPA_20210524\\01_JAVA\\workspace\\RPA17\\src\\com\\pcwk\\ed04\\inputstream\\FileInputStream02Main.java
		

	   //try - with - resource
       try(FileInputStream fis=new FileInputStream("input.txt");) {
	   //try(FileInputStream fis=new FileInputStream(args[0]);) {
    	   
    	   int i ;
    	   //the next byte of data, or -1 if the end of the file is reached.
    	   while(   (i=fis.read()) !=-1) {
    		   System.out.print((char)i);
    	   }
    	   System.out.println();
       }catch(FileNotFoundException e) {
    	   System.out.println(e.getMessage());
       }catch(IOException e) {
    	   System.out.println(e.getMessage());
       }

       System.out.println("end");
	}

}
