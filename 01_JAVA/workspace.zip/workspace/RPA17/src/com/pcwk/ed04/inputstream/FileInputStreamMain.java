package com.pcwk.ed04.inputstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamMain {

	public static void main(String[] args) {
		FileInputStream  fis = null;
		
		try {
			//File Read
			//D:\RPA_20210524\01_JAVA\workspace\RPA17\input.txt
			//fis =new FileInputStream("input.txt");
			fis =new FileInputStream("D:\\RPA_20210524\\01_JAVA\\workspace\\RPA17\\input.txt");
			System.out.println((char)fis.read());
			System.out.println((char)fis.read());
			System.out.println((char)fis.read());
		} catch (FileNotFoundException e) {//FileInputStream ����ó�� 
			e.printStackTrace();
		} catch (IOException e) {//read�� ���� ����ó�� 
			e.printStackTrace();
		} finally {
			//�ڿ� �ݳ�
			if(null !=fis) {
				try {
					fis.close();
					System.out.println("finally �ڿ��ݳ�");
				} catch (IOException e) {
					
				}
			}
		}
		
		System.out.println("end");

	}

}
