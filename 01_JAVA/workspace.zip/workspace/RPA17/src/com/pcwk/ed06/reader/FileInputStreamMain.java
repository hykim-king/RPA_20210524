package com.pcwk.ed06.reader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;
public class FileInputStreamMain {
    final static Logger  LOG = Logger.getLogger(FileInputStreamMain.class);
    
	public static void main(String[] args) {
		//byte ������ read
		try(FileInputStream fis=new FileInputStream("reader.txt")){
			
			int i;
			while(  ( i=fis.read()) !=-1) {
				System.out.println((char)i);
			}
			
			
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			LOG.debug(e.getMessage());
		} catch (IOException e) {
			//e.printStackTrace();
			LOG.debug(e.getMessage());
		}

		System.out.println("End");
		
		
	}

}

//?
//?
//��
//?
//��
//?
// 
//��
//?
//?
//?
// 
//?
//?
//��
//?
//��
//��
//��
//?
// 
//��
//?
//��
//��
//End
