package com.pcwk.ed02.alone01;

public class PasswordException extends Exception {

	public PasswordException(String message) {
		super(message);
	}
}
