package com.pcwk.ed02.alone01;

public class PasswordExceptionMain {
	private String password;
	
	public String getPassword() {
		return password;
	}




	public void setPassword(String password) throws PasswordException {
		if(null == password) {
			throw new PasswordException("��й�ȣ�� null �Դϴ�.");
		}else if(password.length()<5) {
			throw new PasswordException("��й�ȣ ���� 5�̻� �̾�� �մϴ�.");
		}else if(password.matches("[a-zA-Z]+")) {
			throw new PasswordException("��й�ȣ�� ���ڿ� ���� ȥ���̾�� �մϴ�.");
		}		
		this.password = password;
	}




	public static void main(String[] args) {
		PasswordExceptionMain passwordExceptionMain=new PasswordExceptionMain();
		String pass = null;
//		try {
//			passwordExceptionMain.setPassword(pass);
//		} catch (PasswordException e) {
//			System.out.println(e.getMessage());
//		}

//		pass ="a123";
//		try {
//			passwordExceptionMain.setPassword(pass);
//		} catch (PasswordException e) {
//			System.out.println(e.getMessage());
//		}		
//		
		pass ="abcdef1";
		try {
			passwordExceptionMain.setPassword(pass);
		} catch (PasswordException e) {
			System.out.println(e.getMessage());
		}		
		System.out.println("��й�ȣ ����");
	}

}
