package com.pcwk.ed03;

public class BirthDayMain {

	public static void main(String[] args) {
		BirthDay  bDay=new BirthDay();
		bDay.setYear(2021);
		
		System.out.println("bDay:"+bDay);
		bDay.printThis();
	}

}
//com.pcwk.ed03.BirthDay@15db9742
//com.pcwk.ed03.BirthDay@15db9742