package com.pcwk.ed02.exam01;

import com.pcwk.ed01.Student;

public class StudentMain {

	public static void main(String[] args) {
		Student student=new Student();
		//student.name = "ȫ�浿";
		
		student.setName("ȫ�浿");
		
		System.out.println(student.getName());
	}

}
