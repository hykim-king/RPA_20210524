package com.pcwk.ed02.exam04;

import java.util.Calendar;

public class MyDateMain {

	public static void main(String args[]) {
		MyDate  myDate=new MyDate(2020,2,28);

		myDate.isValid();

	}
}
