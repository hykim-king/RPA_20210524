package com.pcwk.ed02;

public class MyDateMain {

	public static void main(String args[]) {
		MyDate  myDate=new MyDate();
		
		myDate.year = 2021;
		myDate.month= 2;
		myDate.setDay(31);
		
		
	}
}
