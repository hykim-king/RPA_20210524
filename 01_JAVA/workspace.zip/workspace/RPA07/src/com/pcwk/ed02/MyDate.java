package com.pcwk.ed02;

public class MyDate {
	//2021/2/31
	public int year;
	public int month;
	private int day;
	public void setDay(int day) {
		if(month==2) {
			if(day<1 || day>28) {
				System.out.println("�ϼ��� Ȯ�� �ϼ���.");
			}else {
				this.day = day;
			}
		}
	}
	
	public int getDay() {
		return day;
	}

}
