package com.pcwk.ed01;

public class StudentMain {

	public static void main(String[] args) {
		Student student=new Student();
		//student.name = "ȫ�浿";
		
		student.setName("ȫ�浿");
		
		System.out.println(student.getName());
	}

}
