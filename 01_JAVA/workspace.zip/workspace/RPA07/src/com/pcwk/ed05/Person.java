package com.pcwk.ed05;

public class Person {
	String name;
	int age;
	
	
	public Person() {
		this("�̸� ����",1);
	}
	
	public Person(String name,int age) {
		this.name = name;
		this.age  = age;
	}
	
	Person resultSelf() {
		return this;
	}
}
