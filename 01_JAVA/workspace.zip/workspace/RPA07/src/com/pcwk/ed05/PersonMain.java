package com.pcwk.ed05;

public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person();
		System.out.println(person.name);
		System.out.println(person.age);
		
		
		System.out.println("-------------------------");
		Person itSelfPerson = person.resultSelf();
		
		System.out.println(person);
		System.out.println(itSelfPerson);
		System.out.println(itSelfPerson.name);

	}

}
//�̸� ����
//1
//-------------------------
//com.pcwk.ed05.Person@15db9742
//com.pcwk.ed05.Person@15db9742
//�̸� ����