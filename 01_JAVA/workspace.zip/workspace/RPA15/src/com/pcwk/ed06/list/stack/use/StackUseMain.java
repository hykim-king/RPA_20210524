package com.pcwk.ed06.list.stack.use;

import java.util.EmptyStackException;
import java.util.Stack;

public class StackUseMain {

	public static void main(String[] args) {
		// main(String[] args) �Է� �ޱ�
		if(args.length <1) {
			System.out.println("use :((2+3)*1)+3))");
			System.exit(0);
		}
		
//		for(String param :args) {
//			System.out.println(param);
//		}
		
		
		String expression = args[0];
		System.out.println("expression:"+expression);
		//expression
		Stack   st=new Stack();
		try {
			for(int i=0;i<expression.length();i++) {
				char ch = expression.charAt(i);
				System.out.println(ch);
				
				if(ch=='(') {
					st.push(ch);
				}else if(ch==')') {
					st.pop();
				}
				
			}
				
			
			if(st.isEmpty()==true) {
				System.out.println("��ȣ�� ��ġ �մϴ�.");
			}else {
				System.out.println("��ȣ�� ����ġ �մϴ�.");
			}
		
		}catch(EmptyStackException e) {
			System.out.println("��ȣ�� ����ġ �մϴ�.");
		}
		
	}

}
