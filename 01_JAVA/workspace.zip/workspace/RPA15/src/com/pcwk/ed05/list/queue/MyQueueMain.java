package com.pcwk.ed05.list.queue;

public class MyQueueMain {

	public static void main(String[] args) {
		MyQueue myQueue=new MyQueue();
		
		//�߰�: �ǳ��� ����
		myQueue.enQueue("A");
		myQueue.enQueue("B");
		myQueue.enQueue("C");
		
		System.out.println("�Է� ��Ȳ:"+myQueue.toString());
		
		System.out.println(myQueue.deQueue());
		System.out.println(myQueue.deQueue());
		System.out.println(myQueue.deQueue());
		
		System.out.println("��Ȳ:"+myQueue.toString());
	}

}
