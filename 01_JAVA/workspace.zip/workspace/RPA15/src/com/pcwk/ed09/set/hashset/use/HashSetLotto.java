package com.pcwk.ed09.set.hashset.use;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
public class HashSetLotto {
	//�ߺ�����
	public static void main(String[] args) {
		
		Set set =new HashSet();
		
		for(int i=0;set.size()<6;i++) {
			//1~45���� ���� ����
			int num = (int)(Math.random()*45)+1;
			System.out.println(num);
			set.add(new Integer(num));
		}
		System.out.println("Before sort");
		System.out.println(set);
		
		System.out.println("Sort");
		List list = new LinkedList<>(set);
		Collections.sort(list);
		System.out.println(list);
		
		

	}

}

