package com.pcwk.ed11.set.treeset.use;

public class Member implements Comparable<Member> {
	private int memberId;     //ȸ�� ���̵�
	private String memberName;//ȸ�� �̸�
	
	
	public Member(int memberId, String memberName) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
	}


	public int getMemberId() {
		return memberId;
	}


	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + "]";
	}


	@Override
	public int compareTo(Member o) {
		//���� ũ�� ��� :ASC
		//������ 0
		//�ڿ��� ũ�� ����
		return (this.memberId - o.getMemberId())*-1;
	}
	
	
}
