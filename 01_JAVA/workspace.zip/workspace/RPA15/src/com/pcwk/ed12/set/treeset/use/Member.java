package com.pcwk.ed12.set.treeset.use;

import java.util.Comparator;

public class Member implements Comparator<Member> {
	private int memberId;     //ȸ�� ���̵�
	private String memberName;//ȸ�� �̸�
	
	
	public Member(int memberId, String memberName) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
	}


	public int getMemberId() {
		return memberId;
	}


	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}


	public String getMemberName() {
		return memberName;
	}


	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}


	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + "]";
	}


	@Override
	public int compare(Member o1, Member o2) {
		// �ΰ��� �Ű� ������ ��		
		return o1.getMemberId() - o2.getMemberId();
	}


//	@Override
//	public int compareTo(Member o) {
//		//���� ũ�� ��� :ASC
//		//������ 0
//		//�ڿ��� ũ�� ����
//		return (this.memberId - o.getMemberId())*-1;
//	}
	
	
}
