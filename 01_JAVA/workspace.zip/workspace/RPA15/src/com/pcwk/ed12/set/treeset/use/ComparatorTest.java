package com.pcwk.ed12.set.treeset.use;

import java.util.Comparator;
import java.util.*;

class MyCompare implements Comparator<String>{

	@Override
	public int compare(String o1, String o2) {
		return (o1.compareTo(o2))*-1;//desc����
	}
	
}



public class ComparatorTest {

	public static void main(String[] args) {
		Set<String>  set = new TreeSet<>(new MyCompare());
		set.add("a");
		set.add("b");
		set.add("c");
		
		System.out.println(set.toString());
		
		

	}

}
