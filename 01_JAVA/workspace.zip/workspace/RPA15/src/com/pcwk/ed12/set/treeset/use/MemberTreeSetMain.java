package com.pcwk.ed12.set.treeset.use;

import java.util.*;

public class MemberTreeSetMain {

	public static void main(String[] args) {
		MemberTreeSet memberTreeSet=new MemberTreeSet();

		Member member01=new Member(1001,"�ڹ�");
		Member member02=new Member(1002,"WEB");
		Member member03=new Member(1003,"DB");
		
		memberTreeSet.addMember(member02);
		memberTreeSet.addMember(member01);
		memberTreeSet.addMember(member03);
		
		memberTreeSet.showAllMember();
		Member member04=new Member(1003,"Spring");
		memberTreeSet.addMember(member04);
		
		memberTreeSet.showAllMember();
	}

}
//�ߺ���� ���� �ʴ´�.
//sort
//Member [memberId=1001, memberName=�ڹ�]
//Member [memberId=1002, memberName=WEB]
//Member [memberId=1003, memberName=DB]
//
//Member [memberId=1001, memberName=�ڹ�]
//Member [memberId=1002, memberName=WEB]
//Member [memberId=1003, memberName=DB]

//desc
//return (this.memberId - o.getMemberId())*-1;
//Member [memberId=1003, memberName=DB]
//Member [memberId=1002, memberName=WEB]
//Member [memberId=1001, memberName=�ڹ�]
//
//Member [memberId=1003, memberName=DB]
//Member [memberId=1002, memberName=WEB]
//Member [memberId=1001, memberName=�ڹ�]