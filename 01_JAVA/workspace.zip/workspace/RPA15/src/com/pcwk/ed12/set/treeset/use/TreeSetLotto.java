package com.pcwk.ed12.set.treeset.use;
import java.util.*;

public class TreeSetLotto {

	public static void main(String[] args) {
		Set set =new TreeSet<>();
		
		for(int i=0;set.size()<6;i++) {
			int num = (int)(Math.random()*45)+1;//1<=x<46
			set.add(new Integer(num));
		}

		System.out.println(set);
		
	}

}
//[5, 9, 10, 13, 15, 30]