package com.pcwk.ed12.set.treeset.use;
import java.util.Iterator;
import java.util.TreeSet;


public class MemberTreeSet {
	private TreeSet<Member> treeSet;

	public MemberTreeSet() {
		super();
		treeSet = new TreeSet<Member>();
	}
	
	/**
	 * ȸ�� �߰� �޼���
	 * @param member
	 */	
	public void addMember(Member member) {
		//ception in thread "main" java.lang.ClassCastException: com.pcwk.ed11.set.treeset.use.Member cannot be cast to java.lang.Comparable
		treeSet.add(member);
	}
	
	/**
	 * ȸ�� ����
	 * @param memberId
	 * @return true/false
	 */
	public boolean removeMember(int memberId) {
		Iterator<Member> iter = treeSet.iterator();
		while(iter.hasNext()) {
			Member member = iter.next();
			int tmpMember = member.getMemberId();
			
			if(tmpMember == memberId) {
				treeSet.remove(member);
				
				return true;
			}
		}
		
		System.out.println(memberId+"�� �������� �ʽ��ϴ�.");
		
		
		return false;
	}
	
	/**
	 * ��ü ȸ������ ���
	 */
	public void showAllMember() {
		for(Member member  :treeSet) {
			System.out.println(member);
		}
		System.out.println();
		
	}
}
