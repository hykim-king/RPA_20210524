package com.pcwk.ed10.set.treeset;
import java.util.*;

public class TreeSetMain {

	public static void main(String[] args) {
		TreeSet<String>   treeSet=new TreeSet<String>();
		treeSet.add("ȫ�浿");
		treeSet.add("������");
		treeSet.add("�̼���");
		

        
		System.out.println(treeSet.toString());
		//System.out.println( disp(treeSet));
	}

    public static  String disp(TreeSet<String>   treeSet) {
        Iterator<String> it = treeSet.iterator();
        if (! it.hasNext())
            return "[]";

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (;;) {
        	String e = it.next();
            sb.append( e);
            if (! it.hasNext())
                return sb.append(']').toString();
            sb.append(',').append(' ');
        }
    }
	
}
