package com.pcwk.ed04.list.stack;

public class MyStackMain {


	
	public static void main(String[] args) {
		MyStack myStack=new MyStack();
		myStack.push("A");
		myStack.push("B");
		myStack.push("C");
		
		System.out.println(myStack.toString());

		System.out.println(myStack.pop());
		System.out.println(myStack.pop());
		System.out.println(myStack.pop());
	}

}
