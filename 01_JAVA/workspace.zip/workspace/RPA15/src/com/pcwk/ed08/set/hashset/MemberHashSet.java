package com.pcwk.ed08.set.hashset;

import java.util.HashSet;
import java.util.Iterator;
public class MemberHashSet {

	private HashSet<Member>  hashSet;
	
	public MemberHashSet() {
		hashSet = new HashSet<>();
	}
	
	/**
	 * ȸ�� �߰� �޼���
	 * @param member
	 */	
	public void addMember(Member member) {
		hashSet.add(member);
	}
	/**
	 * ȸ�� ����
	 * @param memberId
	 * @return true/false
	 */	
	public boolean removeMember(int memberId) {
		Iterator<Member> iter = hashSet.iterator();
		
		while(iter.hasNext()) {
			Member member = iter.next();
			int tmepMemberId = member.getMemberId();
			if(memberId==tmepMemberId) {
				boolean isDeleted = hashSet.remove(member);
				return isDeleted;
			}
		}
		
		System.out.println(memberId+"�� �������� �ʽ��ϴ�.");
		
		return false;
	}
	
	/**
	 * ��ü ȸ������ ���
	 */
	public void showAllMember() {
		for(Member member  :hashSet) {
			System.out.println(member);
		}
		System.out.println();
	}
	
	
	
	
	
}
