/**
* ��Ű��:com.pcwk.ed01
* ���ϸ�:EX14Casting.java
* ������:2021-05-26
* version: 1.0
*/
package com.pcwk.ed01;

/**
 * @author HKEDU
 *
 */
public class EX14Casting {

	/**
	 * 69page �������� 4,5
	 */
	public static void main(String[] args) {
		//�������� 4
		int iNum = 10;
		double dNum = 2.0;
		
		int resultPlus = iNum + (int)dNum;
		int resultMinus = iNum - (int)dNum;
		int resultMul = iNum * (int)dNum;
		int resultDiv = iNum / (int)dNum;
		System.out.println("resultPlus="+resultPlus);
		System.out.println("resultMinus="+resultMinus);
		System.out.println("resultMul="+resultMul);
		System.out.println("resultDiv="+resultDiv);
		
		//�������� 5
		char ch01 = '\uAE00';
		System.out.println("ch01="+ch01);
		
	}

}
//resultPlus=12
//resultMinus=8
//resultMul=20
//resultDiv=5