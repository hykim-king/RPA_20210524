package com.pcwk.ed01;

public class VariableChar06 {

	public static void main(String[] args) {
		char ch01 = '��';
		char ch02 = '\uD55C';
		
		char ch03 ='\uAC00';
		
		System.out.println(ch01);
		System.out.println(ch02);
		System.out.println(ch03);
	}

}
