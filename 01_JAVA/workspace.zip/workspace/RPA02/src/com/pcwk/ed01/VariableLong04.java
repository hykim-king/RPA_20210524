package com.pcwk.ed01;

public class VariableLong04 {

	public static void main(String[] args) {
		//int num = 12345678900;
		//long num02 = 12345678900;
		
		long num02 = 12345678900L;

	}

}
