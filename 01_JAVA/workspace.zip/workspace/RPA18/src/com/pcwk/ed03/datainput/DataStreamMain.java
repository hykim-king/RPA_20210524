package com.pcwk.ed03.datainput;

import java.io.*;

public class DataStreamMain {

	public static void main(String[] args) {
//      DataInputStream/DataOutputStream																		
//		(각 기본 자료형 값을 16진수로 표현하여 저장한다.													
//		예를 들어 int값을 저장하면 4byte의 16진수로 저장)								

		try (FileOutputStream fos = new FileOutputStream("data.txt");
				DataOutputStream dos = new DataOutputStream(fos);) {
			dos.writeByte(100);
			dos.writeChar('A');
			dos.writeInt(10);
			dos.writeFloat(3.14f);
			dos.writeUTF("점심 맛나게 드세요.");

		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("파일 생성 완료");

		try (FileInputStream fis = new FileInputStream("data.txt"); 
				DataInputStream dis = new DataInputStream(fis);) {
			System.out.println(dis.readByte());
			System.out.println(dis.readChar());
			System.out.println(dis.readInt());
			System.out.println(dis.readFloat());
			System.out.println(dis.readUTF());
			
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

}
