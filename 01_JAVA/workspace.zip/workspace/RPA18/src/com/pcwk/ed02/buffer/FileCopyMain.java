package com.pcwk.ed02.buffer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyMain {

	public static void main(String[] args) {
//		Buffered 스트림															
//		내부적으로 1028 *8 바이트 배열을 가지고 읽거나 쓰기 기능을 제공.														
//		속도가 빨라짐.
//      Buffer없이 파일 copy경과 시간 출력.		
		long millisecond = 0;

		try (FileInputStream fis = new FileInputStream("JAVA_PCWK.xls");
				FileOutputStream fos = new FileOutputStream("COPY_JAVA_PCWK_02.xls");) {
			//시작 시간
			millisecond = System.currentTimeMillis();
			System.out.println("파일을 Copy합니다.");
			
			int i;
			while( (i=fis.read()) !=-1) {
				fos.write(i);
				System.out.print(i);
			}

			
			
			//종료 시간
			millisecond = System.currentTimeMillis() - millisecond;
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("Copy완료 "+millisecond+" milliseconds 소요되 었습니다.");

	}

}
