package com.pcwk.ed02.buffer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class BufferdReaderMain {

	public static void main(String[] args) {
//		Buffered 스트림	(char stream)														
//		내부적으로 1028 *8 바이트 배열을 가지고 읽거나 쓰기 기능을 제공.														
//		속도가 빨라짐.
//      Buffer사용

		FileReader      fr = null;//기반 스트림
		BufferedReader  br = null;//보조 스트림
		try {
			
			fr =new FileReader("D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src\\com\\pcwk\\ed02\\buffer\\BufferdReaderMain.java");
			
			br =new BufferedReader(fr);
			String line = "";
			while( (line = br.readLine()) != null) {
				System.out.println(line);
			}
			
			
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}finally {
			
			if(null !=br) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		
	}

}
