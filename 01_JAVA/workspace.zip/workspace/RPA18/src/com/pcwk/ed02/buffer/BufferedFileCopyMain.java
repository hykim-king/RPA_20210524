package com.pcwk.ed02.buffer;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedFileCopyMain {

	public static void main(String[] args) {
//		Buffered 스트림															
//		내부적으로 1028 *8 바이트 배열을 가지고 읽거나 쓰기 기능을 제공.														
//		속도가 빨라짐.
//      Buffer사용
		
		
		long millisecond = 0;
		try(FileInputStream fis=new FileInputStream("JAVA_PCWK.xls");
			FileOutputStream fos=new FileOutputStream("Buffered_JAVA_PCWK.xls");
			BufferedInputStream  bis=new BufferedInputStream(fis);
			BufferedOutputStream bos=new BufferedOutputStream(fos);	
				) {
			millisecond  = System.currentTimeMillis();
			int i;
			while( (i=bis.read()) !=-1  ) {//buffer통해서 파일 read
				bos.write(i);//buffer통해서 파일에 write
			}
			
			
			millisecond  = System.currentTimeMillis() - millisecond;
		}catch(IOException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("수행 완료"+millisecond +" millisecond 경과 되었습니다.");
	}

}
//Buffer사용전 시간
//Copy완료 215093 milliseconds 소요되 었습니다.
//Buffer사용 이후 시간
//수행 완료384 millisecond 경과 되었습니다.
