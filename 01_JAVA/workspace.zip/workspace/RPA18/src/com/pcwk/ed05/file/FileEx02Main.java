package com.pcwk.ed05.file;

import java.io.*;
public class FileEx02Main {

	public static void main(String[] args) {
		// 특정 디렉토리에 파일과 디렉토리 목록을 출력!
		
		if(args.length !=1) {
			System.out.println("사용: 디렉토리명");
			System.exit(0);
		}
		//D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src99
		//D:\\RPA_20210524
		String path = args[0];
		System.out.println("path:"+path);
		
		File f=new File(path);
		
		if(!f.exists() || !f.isDirectory()) {
			System.out.println("유효 하지 않은 디렉터리 입니다.");
			System.exit(0);
		}
		
		File[] files = f.listFiles();
		
		for( int i=0;i<files.length;i++) {
			String fileName = files[i].getName();
			//디렉토리이면?[fileName]:fileName
			System.out.println(files[i].isDirectory()?"["+fileName+"]":fileName);
		}

	}

}
//특정 디렉토리에 파일과 디렉토리 목록
//path:D:\\RPA_20210524
//[00_출석부]
//[01_JAVA]
//[02_ORACLE]
//[03_HTML_CSS_JSP]
//[04_SPRING]
//[05_PYTHON]
//[70_zoom_vod]
//[88_개인]
//[99_교무]
//[app]
//[doc]
//RPA_20210524_할일.txt
