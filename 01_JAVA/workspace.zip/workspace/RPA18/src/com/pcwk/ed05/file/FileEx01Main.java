package com.pcwk.ed05.file;

import java.io.*;

public class FileEx01Main {

	public static void main(String[] args) throws IOException {
		File file =new File("D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\serial99.out");
		file.createNewFile();// 실제파일 생성.

		
		System.out.println(file.isFile());//true;
		System.out.println(file.isDirectory());//false
		//파일 이름
		System.out.println(file.getName());
		
		//파일에 경로
		System.out.println(file.getAbsolutePath());
		
		
		System.out.println(file.getPath());
		
		//파일권한:읽을수 있는 권한
		System.out.println(file.canRead());
		
		//파일권한:쓰기 권한
		System.out.println(file.canWrite());
		
		//파일 삭제
		file.delete();
		
	}

}
