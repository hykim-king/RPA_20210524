package com.pcwk.ed05.file;

import java.io.*;
import java.util.ArrayList;
public class FileEx03Main {
    //전체 파일 수
	static int totalFiles = 0;
	//전체 디렉터리 수
	static int totalDirs  = 0;
	public static void main(String[] args) {

		// 특정 디렉토리에 파일과 디렉토리 Count
		if(args.length !=1) {
			System.out.println("사용: 디렉토리명");
			System.exit(0);
		}
		//D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src99
		//D:\\RPA_20210524
		String path = args[0];
		System.out.println("path:"+path);
		
		File f=new File(path);
		
		if(!f.exists() || !f.isDirectory()) {
			System.out.println("유효 하지 않은 디렉터리 입니다.");
			System.exit(0);
		}
		
		printFileList(f);

		System.out.println("총 "+totalFiles+" 개의 파일");
		System.out.println("총 "+totalDirs+" 개의 디렉터리");
	}
	
	/**
	 * 
	 * @param dir : 디렉토리
	 */
	public static void printFileList(File dir) {
		//디렉트리 : path
		System.out.println(dir.getAbsolutePath()+" 디렉토리");
		File[]  files = dir.listFiles();
		
		//하브 디렉토리 저장 arrayList 변수: 디렉토리저장
		ArrayList<String> subDir=new ArrayList<>();
		
		for(int i=0;i<files.length;i++) {
			String fileName = files[i].getName();//file,디렉토리명
			
			//디렉토리면 subDir저장
			if(files[i].isDirectory()==true) {
				fileName = "["+fileName+"]";
				//subDir의 인덱스 저장.
				subDir.add(Integer.toString(i));
			}
			
			System.out.println(fileName);
			
		}//--for
		
		//현재 파일, 디렉토리 수 계산.
		int dirNum  = subDir.size();//하부 Dir count
		int fileNum = files.length - dirNum;//file count
		
		//total 파일, 디렉토리 
		totalFiles +=fileNum;
		totalDirs  +=dirNum;
		//"D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src"
		System.out.println(fileNum+"개의 파일, "+dirNum+"개의 디렉토리");
		System.out.println();
		
		//subdir에서 재귀 호출
		for(int i=0;i<subDir.size();i++) {
			String idx=subDir.get(i);
			int index = Integer.parseInt(idx);
			printFileList(files[index]);
			
		}
		
		
				
	}//--printFileList
	
	
	
	
	

}

