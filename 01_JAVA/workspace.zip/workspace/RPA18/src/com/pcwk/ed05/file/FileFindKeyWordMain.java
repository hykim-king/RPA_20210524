package com.pcwk.ed05.file;

import java.io.*;

/**
 * 특정 디렉토리에 특정파일(*.java)내에 특정 keyword(if) 건수 출력
 * 
 * @author HKEDU
 *
 */
public class FileFindKeyWordMain {

	static int cnt = 0; // keyword find 건수 저장

	/**
	 * 파일 디렉토를 순회하면서 파일에 keyword를 찾는 함수
	 * 
	 * @param dirs
	 * @param keyword
	 */
	public static void findFiles(File dirs, String keyword) {
		// 디렉토리 내 파일,directory를 읽는다.
		// directory이면 findFiles call
		// 파일이면 라인별로 읽어 keyword를 찾는다.

		File[] files = dirs.listFiles();// 현재 디렉토리에 파일, 디렉토리 목록

		for (int i = 0; i < files.length; i++) {
			// 디렉토리 내 파일,directory를 읽는다.

			// 디렉토리
			if (files[i].isDirectory() == true) {
				findFiles(files[i], keyword);
				// 파일
			} else {

				String fileName = files[i].getName();
				int idx = fileName.indexOf(".");// '.'위치 찾기
				String ext = fileName.substring(idx + 1);// 'java'

				// 확장자가 'java'를 읽도록
				if (ext.equals("java")) {

					try (FileReader fr = new FileReader(files[i].getAbsolutePath());
							BufferedReader br = new BufferedReader(fr);) {

						String data = "";
						int lineNo  =  0;
						
						while(   (data =br.readLine()) !=null) {
							lineNo++;
							
							
							//읽은 line에서 특정 단어 찾기
							if(data.indexOf(keyword) !=-1) {
								cnt++;
								System.out.println(files[i].getAbsolutePath()+"====>"+lineNo+" "+data);
							}
							
						}
						
						
					} catch (IOException io) {

					}

				} // if

			}

		} // --for

	}// --findFiles()

	public static void main(String[] args) {
		// param call : path,keyword
		// "D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18 if"
		if (args.length != 2) {
			System.out.println("usage: path keyword");
			System.exit(0);
		}

		String path = args[0];// path
		String keyword = args[1];// keyword
		System.out.println("path:" + path);
		System.out.println("keyword:" + keyword);

		// 디렉토리가 유효한지 check
		File dir = new File(path);

		if (dir.exists() == false || !dir.isDirectory()) {
			System.out.println("유효한 디렉토리가 아닙니다.");
			System.exit(0);
		}

		// 파일 디렉토를 순회하면서 파일에 keyword를 찾는 함수
		findFiles(dir, keyword);

		System.out.println("총건수: " + cnt);
		System.out.println("====================");
		System.out.println("정상 종료");

	}

}
