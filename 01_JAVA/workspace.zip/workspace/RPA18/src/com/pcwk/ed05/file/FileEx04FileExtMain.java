package com.pcwk.ed05.file;

import java.io.*;

public class FileEx04FileExtMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        //파일경로
		//"D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src\\com\\pcwk\\ed05\\file\\FileEx04FileExtMain.java"
		
		String fileName = "D:\\RPA_20210524\\01_JAVA\\workspace\\RPA18\\src\\com\\pcwk\\ed05\\file\\FileEx04FileExtMain.java";
		String keyword  = "if";
		
		//String fileName = "FileEx04FileExtMain.java";
		int idx = fileName.indexOf(".");
		System.out.println("idx:"+idx);
		String ext = fileName.substring(idx+1);
		System.out.println("ext:"+ext);
		
		if(ext.equals("java")) {
			
			FileReader fr = null;    //기반 스트림
			BufferedReader br = null;//buffer 보조 스트림
			
			
			try {
				fr = new FileReader(fileName);
				br = new BufferedReader(fr);
				
				String data = "";
				while( (data = br.readLine())!=null) {
					
					//특정 단어 찾기
					if(data.indexOf(keyword) !=-1) {
						System.out.println(data);
					}
				}
				
				
			}catch(IOException e) {
				e.printStackTrace();
			}finally {
				if(null !=br) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			
			
		}
		
		//FileReader, BufferedReader통해 
		
		
	}

}
