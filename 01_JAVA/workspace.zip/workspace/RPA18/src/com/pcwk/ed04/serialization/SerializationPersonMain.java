package com.pcwk.ed04.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationPersonMain {

	public static void main(String[] args) {
		Person person01 = new Person("이상무", "IT Developer");
		Person person02 = new Person("김상무", "컨설턴트");
		// 객체 직열화 해서 파일에 기록
		try (FileOutputStream fos = new FileOutputStream("serial.out");
				ObjectOutputStream oos = new ObjectOutputStream(fos);) {

			oos.writeObject(person01);
			oos.writeObject(person02);

		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("serialization 성공");

		// 객체 unserialization 해서 파일에서 읽기

		try (FileInputStream fis = new FileInputStream("serial.out");
				ObjectInputStream ois = new ObjectInputStream(fis);) {
			Person unPerson01 = (Person) ois.readObject();
			Person unPerson02 = (Person) ois.readObject();
			
			System.out.println("unPerson01:"+unPerson01);
			System.out.println("unPerson02:"+unPerson02);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
		
		
		

	}

}
//java.io.NotSerializableException: com.pcwk.ed04.serialization.Person
//at java.io.ObjectOutputStream.writeObject0(Unknown Source)
//at java.io.ObjectOutputStream.writeObject(Unknown Source)
//at com.pcwk.ed04.serialization.SerializationPersonMain.main(SerializationPersonMain.java:14)
