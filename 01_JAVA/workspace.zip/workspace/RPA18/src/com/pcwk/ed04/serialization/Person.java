package com.pcwk.ed04.serialization;

import java.io.Serializable;

public class Person implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2448028979496045830L;
//	cd D:\RPA_20210524\01_JAVA\workspace\RPA18\bin
//
//	serialver com.pcwk.ed04.serialization.Person	
//private static final long serialVersionUID = 2448028979496045830L;
	
	
	//transient String job; //직열화 대상에서 제거
	String name;
	String job;
	
	
	
	
	public Person() {}
	
	public Person(String name,String job) {
		this.name = name;
		this.job  = job;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", job=" + job + "]";
	}
	
	
}
