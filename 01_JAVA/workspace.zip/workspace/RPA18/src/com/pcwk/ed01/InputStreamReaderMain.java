package com.pcwk.ed01;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class InputStreamReaderMain {

	public static void main(String[] args) {
//		바이트 단위로 읽거나 쓰는 자료를 문자로 변환해주는 보조 스트림															
//		FileInputStream(바이트 스트림)으로 읽은 자료를 문자로 변환.															

		//한글도 잘 읽어 드림.
		try(InputStreamReader isr =new InputStreamReader(new FileInputStream("reader.txt"))) {
		//try(FileInputStream isr =new FileInputStream("reader.txt")) { //한글 부분은 깨짐
			
			
			
			int i ;
			
			while( (i=isr.read()) !=-1  ) {
				System.out.print((char)i);
			}
			System.out.println();
		}catch(IOException e) {
			System.out.println(e.getMessage());
			//e.printStackTrace();
		}

		System.out.println("성공적으로 처리");
	}

}
