package com.pcwk.ex03;

public class EX03Array {

	public static void main(String[] args) {
		int []numArray=new int[5];
		
		int idx = 0;//numArray index
		int sum = 0;//�հ�
		
		for(int i=1;i<=10;i++) {
			
			if( i%2==0) {
				numArray[idx]=i;
				idx++;
			}		
		}
		
		
		for(int num:numArray) {
			sum+=num;
			System.out.println(num);
		}

		System.out.println("sum="+sum);
	}

}
