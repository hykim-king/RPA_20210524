package com.pcwk.ed04.alone;

public class StudentArrayMain {

	public static void main(String[] args) {
		Student[] stdArray=new Student[3];
		stdArray[0]=new Student(1001,"James");
		stdArray[1]=new Student(1002,"Tomas");
		stdArray[2]=new Student(1003,"Edward");
		
		for(int i=0;i<stdArray.length;i++) {
			stdArray[i].showStudentInfo();
		}
	}

}
//1001,James
//1002,Tomas
//1003,Edward