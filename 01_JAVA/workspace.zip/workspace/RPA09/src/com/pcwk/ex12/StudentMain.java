package com.pcwk.ex12;

public class StudentMain {

	public static void main(String[] args) {
		//Lee
		Student  stdLee=new Student(1001,"Lee");
		stdLee.addSubject("����", 100);
		stdLee.addSubject("����", 50);
		stdLee.showStudentInfo();
		//Kim

	}

}
