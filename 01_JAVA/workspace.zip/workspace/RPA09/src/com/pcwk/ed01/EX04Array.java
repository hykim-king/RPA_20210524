package com.pcwk.ed01;

public class EX04Array {

	public static void main(String[] args) {
//		���� �迭											
//		A~Z ���� �� �ִ� �迭 �����ϰ�, ���										

		char[] alphabets = new char[26];
		char ch ='A';//ascii code 65
		
		for(int i=0;i<alphabets.length;i++,ch++) {
			alphabets[i] = ch;
		}
		
		for(int i=0;i<alphabets.length;i++) {
			System.out.println(alphabets[i]+"->"+(int)alphabets[i]);
		}
		
		
		
	}

}
//A->65
//B->66
//C->67
//...
//X->88
//Y->89
//Z->90
