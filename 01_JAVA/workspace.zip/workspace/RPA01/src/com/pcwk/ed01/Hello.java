package com.pcwk.ed01;

public class Hello {

	public static void main(String[] args) {
		
		System.out.println("Hello, world!");

	}

}
