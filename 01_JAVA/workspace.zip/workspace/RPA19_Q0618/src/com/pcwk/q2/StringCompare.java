package com.pcwk.q2;

public class StringCompare {

	public static void main(String[] args) {
		String str1 = "HanKyung";
        String str2 = new String("HanKyung");
        String str3 = "Han" + "Kyung";
        String s1 = "Han";
        String s2 = "Kyung";
        String str6 = s1+s2;
        
        System.out.println(str1 == str2);//false
        System.out.println(str2 == str3);//false
        System.out.println(str3 == str6);//false
        System.out.println(str2.toString() == str3.toString());
        System.out.println("====================");
//        System.out.println(str1);
//        System.out.println("str2="+str2);
//        System.out.println("str3="+str3);
//        System.out.println("str6="+str6);
        
	}

}
