package com.pcwk.q6;

public class Parents {
	public Parents() {
		System.out.println("�θ��");
	}

	public void print() {
		System.out.println("�ڹ�");
	}
}
