package com.pcwk.q6;

public class InheritanceMain {

	public static void main(String[] args) {
        Parents c = new Child();
        c.print();


	}

}
//�θ��
//Java
//�ڹ�