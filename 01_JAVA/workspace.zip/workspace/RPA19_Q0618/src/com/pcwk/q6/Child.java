package com.pcwk.q6;

public class Child extends Parents {
	public Child() {
		super();
	}
	@Override
    public void print() {
         System.out.println("Java");
         super.print();
    }
}

