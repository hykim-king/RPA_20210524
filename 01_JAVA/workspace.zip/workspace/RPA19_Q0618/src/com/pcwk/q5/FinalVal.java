package com.pcwk.q5;

public class FinalVal {
	//The blank final field F may not have been initialized
	//private final int F;

//	public FinalVal() {
//		F = 99;
//	}
	
	public void inVal() {
		final int k;
	}
}
