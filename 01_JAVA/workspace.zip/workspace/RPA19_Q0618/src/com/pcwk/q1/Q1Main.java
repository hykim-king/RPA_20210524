package com.pcwk.q1;

public class Q1Main {

	public static void main(String[] args) {
		char c = ' ';
//		byte b = 200; //Type mismatch: cannot convert from int to byte
		//char c = 'biz';//Invalid character constant
//		float f = 3.14; //Type mismatch: cannot convert from double to float       
		int i = (char)96;           
		char dd = 65;
//		boolean isc = 1;//Type mismatch: cannot convert from int to boolean
//		int i = (2014+1)+"11";//Type mismatch: cannot convert from String to int
		
		
	}

}
