package com.pcwk.q4;

import java.util.ArrayList;
import java.util.List;

public class SelectAll {
	private List<Dto> list;
    private Dto dto;
    public SelectAll(){
        list = new ArrayList<Dto>();
    }
    public void addDTO(){
        String[] name = {"�ϴ�","�ٶ�","��","��"};
        int count =1;
        for(String s : name){
              dto = new Dto(count++,s);
             list.add(dto);
         }
    }
    public List<Dto> getList(){
        return list;
    }
}

