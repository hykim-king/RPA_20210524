package com.pcwk.q4;

public class Process {

	public static void main(String[] args) {
		SelectAll sa = new SelectAll();
        System.out.println(sa.getList());


	}

}
//[]