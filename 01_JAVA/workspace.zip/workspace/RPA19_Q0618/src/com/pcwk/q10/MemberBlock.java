package com.pcwk.q10;

public class MemberBlock {
	private static String aField = "";
    private String bField="";
    
    //static block
    static{
        aField += "A";
    }
 
    //instance block
    {
        aField += "B";
        bField += "B";
    }
 
    public MemberBlock(){
        aField += "C";
        bField += "C";
    }
    public void append(){
        aField += "D";
        bField += "D";
    }
    //���� ����
    //static {}
    
    //{}
    //������ 
    
    public static void main(String[] args){
        System.out.println(aField);//
        MemberBlock mb = new MemberBlock();
        mb.append();
        System.out.println(aField);
        System.out.println(mb.bField);
    }
}

//A
//ABCD
//BCD