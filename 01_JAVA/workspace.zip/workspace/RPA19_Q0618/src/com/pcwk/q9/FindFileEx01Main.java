package com.pcwk.q9;
import java.io.*;
public class FindFileEx01Main {
	static int cnt = 0;//�� ��
	//JAVA_1228 PROJECT�� JAVA������ 1���� ��ó �����.AllJava_1228.java
	public static void findFiles(File dirs,String keyword) {
		File[] files = dirs.listFiles();
		
		for(int i=0;i<files.length;i++) {
			
			if(files[i].isDirectory()) {//���丮
				findFiles(files[i],keyword);//��� ȣ��
			}else {//file�б�
				String fileName = files[i].getName();
				
				int idx =fileName.indexOf(".");
				String ext = fileName.substring(idx+1);
				
				//if(!ext.equals("java"))continue;
				if(ext.equals("java")) {//Ȯ���ڰ� *.java�� ���ϸ� ����
				    	FileReader     fr= null;
				    	BufferedReader br= null;
				    	
				    	try {
				    		//String fullPath = dirs.getAbsolutePath()+File.separator+fileName;
				    		String fullPath = files[i].getAbsolutePath();
				    		fr =new FileReader(fullPath);
				    		br = new BufferedReader(fr);
				    		String data = "";
				    		int lineNum = 0;
				    		while( (data=br.readLine() ) !=null) {
				    			lineNum++;
				    			if(data.indexOf(keyword) !=-1) {
				    				cnt++;
				    				System.out.println("<"+fileName+">"+" :line("+lineNum+")"+data);
				    			}
				    		}
				    	}catch(IOException e) {
				    		System.out.println("=====================");
				    		System.out.println("=IOException="+e.getMessage());
				    		System.out.println("=====================");
				    		e.printStackTrace();
				    	}finally{
				    		if(null !=br) {
				    			try {
									br.close();
								} catch (IOException e) {
									e.printStackTrace();
								}
				    		}
				    	}
					
				}//--if
				
			}
			
		}//--for i
		
	}//--findFiles
	
	
	public static void main(String[] args) {
		if(args.length!=2) {
			System.out.print("usage: path keyword");
			System.exit(0);
		}

		//D:\\RPA_20210524\\01_JAVA\\workspace for
		String path = args[0];
		String keyword = args[1];

		
		File dir =new File(path);
		if(dir.exists()==false || !dir.isDirectory() ) {
			System.out.print("��ȿ���� ���� ���丮 �Դϴ�.");
			System.exit(0);
		}
		findFiles(dir,keyword);
		
		System.out.println("path:"+path);
		System.out.println("keyword:"+keyword);
		System.out.println("�Ѽ�:"+cnt);
		
		System.out.println("��������");
		
	}

}
