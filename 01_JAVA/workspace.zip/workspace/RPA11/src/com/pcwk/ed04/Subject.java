package com.pcwk.ed04;

public class Subject {

}
