package com.pcwk.ed08;

public class DefineMain {

	public static void main(String[] args) {
		System.out.println(Define.GOOD_MORNING_CLASS_3);
		System.out.println("MAX="+Define.MAX);
		System.out.println("MIN="+Define.MIN);
	}

}
