package com.pcwk.ex05;

public class Triangle extends Shape {
	public void draw() {
		System.out.println("Triangle");
	}
}
