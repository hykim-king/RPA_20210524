package com.pcwk.ex05;

public class Shape {
	public void draw() {
		System.out.println("Shape");
	}
}
