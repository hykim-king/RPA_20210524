package com.pcwk.ex05;

public class Circle extends Shape {
	public void draw() {
		System.out.println("Circle");
	}
}
