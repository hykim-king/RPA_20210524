package com.pcwk.ed02;

public class CustomerMain {

	public CustomerMain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Customer customerLee=new Customer();
		customerLee.setCustomerId(10010);
		customerLee.setCustomerName("�̻�");
		customerLee.setBonusPoint(1000);
		
		System.out.println(customerLee.showCustomerInfo());
		
		System.out.println("=================================");
		Customer customerKim = new VIPCustomer(10020, "ȫ�浿", 12345);
		customerKim.setBonusPoint(1_000_000);
		System.out.println(customerKim.showCustomerInfo());
		
		
		int price  = 9_000_000;//Mac Book Pro 16inch
		
		int leePrice = customerLee.calcPrice(price);
		int kimPrice = customerKim.calcPrice(price);
		
		System.out.println(customerLee.getCustomerName()+"���� "+leePrice+"�� �����ϼ̽��ϴ�.");
		System.out.println(customerKim.getCustomerName()+"���� "+kimPrice+"�� �����ϼ̽��ϴ�.");
	}

}
