package com.pcwk.ed03;

public class GoldCustomer extends Customer {

	double saleRatio;
	
	public GoldCustomer(int customerID,String customerName) {
		super(customerID,customerName);
		
		super.customerGrade = "GOLD";
		super.bonusRatio    = 0.02;//2%����
		this.saleRatio      = 0.1;//10%����
		
	}
	
	
	public int calcPrice(int price) {
		super.bonusPoint += price * bonusRatio;
		return price - (int)(price*saleRatio);
	}

}
