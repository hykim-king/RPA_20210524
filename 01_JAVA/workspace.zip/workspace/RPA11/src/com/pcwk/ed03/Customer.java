package com.pcwk.ed03;

public class Customer {

		protected int customerId;
		protected String customerName;
		protected String customerGrade;
		
		int bonusPoint;
		double bonusRatio;
		
		//default������
		public Customer() {
			initCustomer();
		}
		
		public Customer(int customerId,String customerName) {
			this.customerId   = customerId;
			this.customerName = customerName;
			
			initCustomer();		
		}
		
		
		
		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public String getCustomerGrade() {
			return customerGrade;
		}

		public void setCustomerGrade(String customerGrade) {
			this.customerGrade = customerGrade;
		}

		public int getBonusPoint() {
			return bonusPoint;
		}

		public void setBonusPoint(int bonusPoint) {
			this.bonusPoint = bonusPoint;
		}

		public double getBonusRatio() {
			return bonusRatio;
		}

		public void setBonusRatio(double bonusRatio) {
			this.bonusRatio = bonusRatio;
		}

		public void initCustomer() {
			//������� �ʱ�ȭ
			customerGrade = "SILVER";
			bonusRatio    = 0.01;				
		}
		
		public int calcPrice(int price) {
			bonusPoint += price * bonusRatio;
			
			return price;
		}
		
		
		public String showCustomerInfo() {
			//OO�Կ� ����� OO�̰�, ���ʽ� ����Ʈ��OO�Դϴ�.
			
			return customerName+"�Կ� ����� "+customerGrade+"�̰�, ���ʽ� ����Ʈ�� "+bonusPoint+"�Դϴ�.";			
		}
}




