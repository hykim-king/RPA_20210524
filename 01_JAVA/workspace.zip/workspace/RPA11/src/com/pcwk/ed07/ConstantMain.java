package com.pcwk.ed07;

import com.pcwk.ed08.Define;

import static com.pcwk.ed08.Define.GOOD_MORNING_CLASS_3;
import static com.pcwk.ed08.Define.MAX;

public class ConstantMain {
	int num = 10;
	final int NUM = 100;//���
	
	public static void main(String[] args) {
		ConstantMain cMain=new ConstantMain();
		cMain.num = 20;
		//The final field ConstantMain.NUM cannot be assigned
		//cMain.NUM = 200;

		System.out.println(cMain.num);
		System.out.println(cMain.NUM);
		
		System.out.println(Define.GOOD_MORNING_CLASS_3);
		System.out.println("MAX="+MAX);
	}

}
