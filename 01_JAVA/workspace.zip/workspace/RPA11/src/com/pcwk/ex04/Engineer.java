package com.pcwk.ex04;

public class Engineer extends Employee {

	
	private String skillset;

	public Engineer() {
		
	}
	public String getSkillset() {
		return skillset;
	}

	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}
	
	
}
