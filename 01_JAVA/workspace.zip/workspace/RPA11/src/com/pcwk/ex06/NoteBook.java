package com.pcwk.ex06;

public abstract class NoteBook extends Computer {


	@Override
	void typing() {
		System.out.println("NoteBook typing()");
		
	}

}
