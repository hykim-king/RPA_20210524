package com.pcwk.ex06;

public class MyNoteBook extends NoteBook {

	@Override
	void dispaly() {
		System.out.println("MyNoteBook dispaly()");
		
	}

}
