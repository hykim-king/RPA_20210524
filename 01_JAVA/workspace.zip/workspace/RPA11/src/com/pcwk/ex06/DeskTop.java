package com.pcwk.ex06;

public class DeskTop extends Computer {

	@Override
	void dispaly() {
		System.out.println("DeskTop dispaly()");
		
	}

	@Override
	void typing() {
		System.out.println("DeskTop typing()");
		
	}



}
