package com.pcwk.ed10;

public class CalculatorMain {

	public static void main(String[] args) {
		int num1 = 10;
		int num2 = 5;
		
		Calculator  calc=new Calculator();
		System.out.println("���ϱ�:"+calc.add(num1, num2));
		System.out.println("����:"+calc.substract(num1, num2));		
		System.out.println("���ϱ�:"+calc.times(num1, num2));		
		System.out.println("������:"+calc.divide(num1, 0));
		
		//
		//System.out.println(num1/0);
	}

}
