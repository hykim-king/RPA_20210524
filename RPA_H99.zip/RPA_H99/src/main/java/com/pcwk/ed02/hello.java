package com.pcwk.ed02;

public class hello {

	public static void main(String[] args) {

		System.out.println("hello,mj!!");
		System.out.println("hello,mj!!2");
	}

}
