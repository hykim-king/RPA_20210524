package com.pcwk.ed07;

public class Hello_java {

	public static void main(String[] args) {
				System.out.println("Hello!~ JAVA~ Yo");

	}

}
