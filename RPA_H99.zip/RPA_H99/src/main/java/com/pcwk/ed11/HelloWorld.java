package com.pcwk.ed11;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("요한");
		System.out.println("강사");
	}

}
