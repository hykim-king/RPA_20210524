package com.pcwk.ed01;

public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello, world.");
		System.out.println("Hello, world.2");
		System.out.println("Hello, world.3");
		System.out.println("Hello, world.4정훈");
		System.out.println("Hello, world.4강사");
		System.out.println("Hello, world.5강사");
		System.out.println("Hello, world.7강사");
		System.out.println("Hello, world.8보선");
		System.out.println("Hello, world.8강사");
	}

}
