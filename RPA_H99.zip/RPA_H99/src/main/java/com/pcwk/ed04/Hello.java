package com.pcwk.ed04;

public class Hello {

	public static void main(String[] args) {
		System.out.println("HELLO WORLD 1");
		System.out.println("HELLO WORLD 2");
	}

}
