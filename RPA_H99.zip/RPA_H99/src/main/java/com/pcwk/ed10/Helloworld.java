package com.pcwk.ed10;

public class Helloworld {

	public static void main(String[] args) {
		System.out.println("Hello! SeoYeon");
		System.out.println("Hello! 강사");
	}

}
