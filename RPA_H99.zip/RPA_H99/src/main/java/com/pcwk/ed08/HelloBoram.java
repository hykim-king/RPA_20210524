package com.pcwk.ed08;

public class HelloBoram {

	public static void main(String[] args) {
		System.out.println("SVN TEST BORAM");
	}

}
