/**
 * 
 */
 
 window.onload = function(){
    console.log(`location.host:${location.host}`);
    console.log(`location.port:${location.port}`);
    console.log(`location.href:${location.href }`);
    console.log(`location.protocol:${location.protocol }`);
    console.log(`location.pathname:${location.pathname }`);
    
    let w = screen.width;
    let h = screen.height;
    console.log(`screen.width:${screen.width }`);
    console.log(`screen.height:${screen.height }`);
};