/**
 * 
 */
 
 setTimeout(function(){
  alert('setTimeout 함수 실행');
  
},2000);