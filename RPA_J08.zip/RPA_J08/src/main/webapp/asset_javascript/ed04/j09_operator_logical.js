/**
 * 논리 연사자
 */
 'use strict'
 
 let logical01, logical02, logical03, logical04, logical05;
 
 logical01 = (3 > 2) && ( 5 > 3);
 console.log(`logical01=${logical01}`);
 
 logical02 = (3 < 2) || ( 5 > 3);
 console.log(`logical02=${logical02}`);
 
 logical03 = !(3 < 2);
 console.log(`logical03=${logical03}`);
 
 // || : 첫번째 연산이 true면 그 이하 연산은 수행 하지 않음.
 
 const value01 = true;//true
 const value02 = 13<11;//false
 
 
 function checkValue(){
  
  for(let i=0;i<10;i++){
    console.log('*');
  }
  
  return true;
 }

 console.log(`or: ${  value01 || value02 || checkValue() }` );
 
 //console.clear();
 // && : 첫번째 연산이 false이면 이 그하 연산을 수행 하지 않음.
 console.log(`and: ${  value01 && value02 && checkValue() }`);












