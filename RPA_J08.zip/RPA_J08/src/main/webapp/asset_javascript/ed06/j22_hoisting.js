/**
 * hoisting : 함수 및 변수(var)가 선언된 위치에서
   최상단으로 끌어 올려 지는것.
 */
 
 //변수 hoisting
 console.log(`num:${num}`);//num:undefined
 var num =10;
 //let num =10;//Uncaught ReferenceError: Cannot access 'num' before initialization
 
 
 
 //함수 hoisting
 //compute();
 
 function compute(){
  let x = 10;
  let y = 100;
  
  let result = x / y;
  console.log(`result:${result}`);
 }
 
 compute();