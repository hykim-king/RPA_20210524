/**
 * 
 */
 
 window.onload = function(){
  //console.log('window.onload');
  let content = document.getElementById('content');
  
  content.style.width = '200px';
  content.style.height = '200px';
  content.style.border ='4px solid #718c00';
  content.style.textAlign = 'center';
  content.style.lineHeight = '200px';
};