/**
 * 
 */
 
 function createEle(){
    
  //console.log('createEle()');
  let bt = document.getElementById('bt');
  //console.log(`bt:${bt}`);
  
  function popup(){
    //console.log(`popup`);
    let div = document.createElement('div');
    let a = document.createElement('a');
    let txt = document.createTextNode('PCWK_class');
    
    a.appendChild(txt);
    
    //a attribute추가
    a.setAttribute('href','https://cafe.daum.net/pcwk');
    a.setAttribute('target','_blank');
    a.setAttribute('title','새창');
    
    //div에 자식으로 a 태그 추가
    div.appendChild(a);
    
    
    //body자식으로 div 추가
    document.body.appendChild(div);
  }
  
  bt.onclick = popup;
 }
 
 
 addEventListener('load',createEle);