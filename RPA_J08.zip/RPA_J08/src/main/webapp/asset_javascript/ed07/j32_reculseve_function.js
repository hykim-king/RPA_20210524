/**
 * 재귀함수                 
  함수 안에서 자신의 함수를 호출               
 */
 
 function factorial(n){
  
  if(n === 0){
    console.log("호출 끝");
    
  }else{
    console.log(`n=${n}`);
    factorial(n-1);
  }
}

factorial(10);