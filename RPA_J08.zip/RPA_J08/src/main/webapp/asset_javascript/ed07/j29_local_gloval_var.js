/**
 * 전역변수
 */
 
 //전역변수
/* var kor = 90;
 
 function getScore(){
    kor = 100; 
    console.log(kor);
 }
 
 getScore();
 
 console.log(`kor: ${kor}`);*/
 
/*
 var kor = 90;
 
 function getScore(){
    var kor = 100;  //지역변수 
    console.log(kor);//100
 }
 
 getScore();
 
 console.log(`kor: ${kor}`);//kor: 90*/
 
 function getScore(){
    var kor = 100;  //지역변수 
    console.log(kor);//100
 }
 
 getScore();
 console.log(`kor: ${kor}`);//Uncaught ReferenceError: kor is not defined
