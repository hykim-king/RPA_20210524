/**
 * encodeURIComponent()               영문,숫자,( ),-,_,.~,!,*,'을 제외한 문자를 인코딩.                            
   decodeURIComponent()                encodeURIComponent()처리한 문자를 원래대로 복원                           
 */
 
 
 let encodeStr = '자바스크립트_html5';
 
 //encodeStr: %EC%9E%90%EB%B0%94%EC%8A%A4%ED%81%AC%EB%A6%BD%ED%8A%B8_html5
 console.log(`encodeStr: ${encodeURIComponent(encodeStr)}`);
 
 let decodeStr = encodeURIComponent(encodeStr);
 //decodeStr: 자바스크립트_html5
 console.log(`decodeStr: ${decodeURIComponent(decodeStr)}`);
 
 /**
isNaN()          "숫자인지 판별하는 함수. 숫자가 아니면 true, 숫자이면
                 false"                            
isFinite()       "유/문한 판별하는 함수. 유한 값이면 true 그렇치 않으면
                 false"                            
  */
  
let num01 ='숫자';

if(isNaN(num01)){
  console.log(`숫자가 아니면 true : isNaN(num01)`);//숫자가 아니면 true : isNaN(num01)  
}else{
  console.log(`숫자이면 false: isNaN(num01)`);
} 

let num02 = 1 / 0;
if(isFinite(num02)){
  console.log(`유한: ${isFinite(num02)}`);
}else{
  
  console.log(`무한: ${isFinite(num02)}`);//무한: false
}

/**
숫자 문자 변환 함수
Number()                숫자로 변환해 주는 함수.                            
parseInt()              숫자와 문자가 혼합된 경우 정수 부분만 숫자로 변환.                           
parseFloat()           숫자와 문자가 혼합된 경우 실수 부분 까지 숫자로 변환.                           
String()                문자로 바꾸어 주는 함수.
 */

let num03 ='10';

console.log(`num03:${num03}, type:${typeof num03}`);//num03:10, type:string
//Number로 변환
console.log(`num03:${Number(num03)}, type:${typeof Number(num03)}`);//num03:10, type:number

let num04 = '100px';
console.log(`num04: ${num04}, type:${typeof num04}`);
//parseInt()
//parseInt(num04): 100, type:number
console.log(`parseInt(num04): ${parseInt(num04)}, type:${typeof parseInt(num04)}`);

let num05 = '33.3%';
//parseFloat()
//parseFloat(num05):33.3, type:number
console.log(`parseFloat(num05):${parseFloat(num05)}, type:${typeof parseFloat(num05)}`);

let num06 = 100000000;
console.log(typeof num06);
console.log(`num06:${num06},type:${typeof String(num06)}`);

/**
 문자열을 자바스크립트 코드로 변경.
 */
 
let str01 = "var num07 = 10;";
let str02 = "var num08 = 12;";

eval(str01);
eval(str02);
//num07+num08=22
console.log(`num07+num08=${num07+num08}`);















