/**
 * if ~ else if else
 */
 
  let age = prompt('나이를 입력 하세요.',"");
  console.log(`age: ${age}, type:${typeof age}`);
  
  let admissionFee = '';
  
  if(age < 13){
    admissionFee = "2,000원";
  }else if(age<=20){
    admissionFee = "4,000원";
    
  }else if(age<65){
    admissionFee = "6,000원";
  }else{
    admissionFee = "1,500원";
  }
  
  console.log(`admissionFee:${admissionFee}`);
  