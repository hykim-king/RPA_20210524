/**
 * 
 */
 
 let guguTable = "<table>";
 
   for(let i = 2; i<=9; i++){
      guguTable += "<tr>";
    
      for(let j=1;j<=9; j++){
        guguTable +="<td>"+i+"*"+j+"="+(i*j)+"</td>";
      }
      
      guguTable += "</tr>";
   }
 
 guguTable +="</table>";
 
 document.write(guguTable);