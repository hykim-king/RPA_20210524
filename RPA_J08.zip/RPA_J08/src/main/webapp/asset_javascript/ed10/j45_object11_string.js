/**
 * var str =new String('javascript');
   let str01 = 'javascript'; 
 */
 
 let str01 = 'Javascript';
 
 //문자열의 길이
 console.log(`str01.length:${str01.length}`);
 
 //chartAt(n): n번째 인덱스에 해당하는 문자 반환
 console.log(`str01.charAt(0):${str01.charAt(0)}`);
 
 //indexOf('a'): 왼쪽부터 검색하여 일치하는 index반환 없으면 -1
 console.log(`str01.indexOf('a'): ${str01.indexOf('a')}`);
 console.log(`str01.indexOf('q'): ${str01.indexOf('q')}`);
 
 //lastIndexOf('a'): 오른쪽부터 검색하여 일치하는 index반환 없으면 -1
 console.log(`str01.lastIndexOf('a'): ${str01.lastIndexOf('a')}`);  
 
 //substring():
 console.log(`str01.substring(4,9): ${str01.substring(4,9)}`);//scrip
 console.log(`str01.substring(4): ${str01.substring(4)}`);//script
 
 //split(): 문자를 기준으로 문자를 잘라 배열로 변환
 str01 = "Javascript_Jquery";
 var division = str01.split("_");
 console.log(division[0]+","+division[1]);
 
 //trim(): 양쪽에 공백 제거
 str01 = " javascript ";
 console.log(str01);
 console.log(str01.trim());
 
 //subStr(4,6) : index번호 4번 부터 6개의 문자를 반환.
 str01 = 'javascript';  
 console.log(str01.substr(4,6));//script
 
 
 
 
 
  