/**
 * 
 */
 window.onload = function(){
    let outer = document.getElementById("outer");
    //console.log(outer);
    let inner = document.getElementById("inner");
    console.log(inner);
    
    outer.onclick = function(){
        alert('부모 이벤트');
    };


    inner.onclick = function(event){
        alert('자식 이벤트');
        //무모 이벤트가 수행되는 것을 방지
        event.stopPropagation();
    };    
};