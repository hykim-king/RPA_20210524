/**
 * 
 */
 window.onload  = function(){
  let pcwk = document.getElementById("pcwk");
  console.log(`pcwk:${pcwk}`);
  pcwk.onclick = function(event){
    alert('PCWK');
    //a 태그에 화면이동 기능을 막는다.
    event.preventDefault();
  };
}