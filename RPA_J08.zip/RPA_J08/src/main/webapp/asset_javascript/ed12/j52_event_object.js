/**
 * 
 */
 
window.onload = function(){
   let bt = document.getElementById("bt");
   console.log(`bt:${bt}`);
   
   bt.onclick = function(event){
     console.log(`event.target;${event.target}`);
     console.log(`event.type:${event.type}`);
     console.log(`event.clientX:${event.clientX}`);
     console.log(`event.clientY:${event.clientY}`);
     
     console.log(`event.screenX:${event.screenX}`);
     console.log(`event.screenY:${event.screenY}`);
  };
  
  //div event
  let area = document.getElementById("area");
  console.log(area); 
  
  area.onmousedown = function(event){
     //마우스 왼쪽(0), 가운데(1),오른쪽(2)
     console.log(event.button);
  };
  
  
  
}; 