/**
 * 
 */
function doRetrieve(){
  //alert("doRetrieve");  
  var frm = document.searchFrm;
  //검색 목록조회를 찾아 가도록 작업구분(doRetrieve) 
  frm.work_div.value = 'doRetrieve';
  frm.method = "get";
  frm.action = "/RPA_J08/board/board.do";
  alert("frm.work_div.value:"+frm.work_div.value);
  frm.submit();  
  
}