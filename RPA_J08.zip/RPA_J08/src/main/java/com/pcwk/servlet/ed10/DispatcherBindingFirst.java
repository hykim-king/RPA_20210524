package com.pcwk.servlet.ed10;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class ForwordFirst
 */
@WebServlet(description = "redirect", urlPatterns = { "/dispatcher_binding/first" })
public class DispatcherBindingFirst extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final Logger LOG = Logger.getLogger(getClass());       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DispatcherBindingFirst() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		serviceHandler(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		serviceHandler(request, response);
	}
	
	public void serviceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("JavaScript location:");
		response.setContentType("text/html; charset=utf-8");
		
		List<String> list =new ArrayList<String>();
		list.add("java");
		list.add("html");
		list.add("css");
		
		//binding
		request.setAttribute("name", "a goodman");
		request.setAttribute("list", list);
		                                                             ///RPA_J08 붙이면 않됨.
		RequestDispatcher  dispatcher = request.getRequestDispatcher("/dispatcher_binding/second");
		dispatcher.forward(request, response);
		
		

	}
}

    












