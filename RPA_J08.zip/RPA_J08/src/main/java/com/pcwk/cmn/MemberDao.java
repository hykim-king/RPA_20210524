/**
 * 
 */
package com.pcwk.cmn;

import java.util.List;

import com.pcwk.ed01.BoardVO;
import com.pcwk.ed01.DTO;

/**
 * @author HKEDU
 *
 */
public class MemberDao implements WorkDiv<BoardVO> {

	@Override
	public List<BoardVO> doRetrieve(DTO vo) {
		// TODO Auto-generated method stub
		return null; 
	}

	@Override
	public int doUpdate(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BoardVO doSelectOne(BoardVO vo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int doDelete(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int doInsert(BoardVO vo) {
		// TODO Auto-generated method stub
		BoardVO inVO = vo;
		
		return 0;
	}



}
