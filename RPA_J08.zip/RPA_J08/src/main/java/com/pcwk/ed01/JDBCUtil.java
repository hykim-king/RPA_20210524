package com.pcwk.ed01;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class JDBCUtil {
    final static Logger LOG = Logger.getLogger(JDBCUtil.class);
    
	final static String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	final static String USER_ID= "scott"; //아이디
	final static String USER_PASS= "pcwk";//비번
	

	
	
	/**
	 * PreparedStatement 자원 반납
	 * @param pstmt
	 */
	public static void close(PreparedStatement pstmt) {
		if(null != pstmt) {
			try {
				LOG.debug("=PreparedStatement close()=============");
				pstmt.close();
			} catch (SQLException e) {
				LOG.debug("=PreparedStatement=============");
				LOG.debug(e.getMessage());
				LOG.debug("=PreparedStatement=============");
			}
		}
	}
	
	public static void close(Connection con) {
		if(null != con) {
			try {
				LOG.debug("=Connection close()=============");
				con.close();
			} catch (SQLException e) {
				LOG.debug("=SQLException=============");
				LOG.debug(e.getMessage());
				LOG.debug("=SQLException=============");
			}
		}
	}
	
	public static void close(ResultSet rs) {
		if(null != rs) {
			try {
				rs.close();
			} catch (SQLException e) {
				LOG.debug("=SQLException=============");
				LOG.debug(e.getMessage());
				LOG.debug("=SQLException=============");
			}
		}		
	}
	
	
	
	
	
	
	
	
	
}
