/**
 * 
 */
 
//데이터 타입
// ->변수에 저장되는 데이터 유형. 
//데이터 유형 : Primitive(원시),Object(객체)
//1. Primitive : number,string,boolean,undefined,null,symbol
//2. Object : function, object, array

//1.1.number : 정수, 실수, 지수
let num01 = 10;//정수
let num02 = 10.5;//실수
let num03 = 1e+2;//1*10에 2승
//console.log("num01="+num01);

console.log(`num01:${num01}, type:${typeof num01}`);
console.log(`num02:${num02}, type:${typeof num02}`);
console.log(`num03:${num03}, type:${typeof num03}`);

//1.2. string : string데이터 '',""으로 표현할 수 있다.
//              java의 char, String 모두 표현

//Console was cleared
console.clear();


let str01 = '오늘은 수요일.';
let str02 = "내일은 즐거운 목요일.";

console.log(`str01:${str01}, type:${typeof str01}`);  
console.log(`str02:${str02}, type:${typeof str02}`);

//특수한 목적을 가지는 문자.
//-------------------------------------------------
// 이스케이프 문자           |  설명
//-------------------------------------------------
// \n                    |  행 바꿈  
//-------------------------------------------------
// \t                    | 탭문자
//-------------------------------------------------
// \\                    | 역슬러시
//-------------------------------------------------
// \'                    | 작은따옴표
//-------------------------------------------------
// \"                    | 큰따옴표
//-------------------------------------------------
//Console was cleared
console.clear();
let str10 = 'you \'re to smart. ';
console.log(`str10:${str10}`);

//alert 행 바꿈 
//alert('수요일에는 \n빨간 장미를.');


//1.3. boolean(논리) 데이터
//-> true(참), false(거짓)
// boolean은 0은 false, 이외 숫자,문자는 true

//Console was cleared
console.clear();
let flag01 = (5>4);
let flag02 = (5<4);

console.log(`flag01:${flag01}, type:${typeof flag01}`);
console.log(`flag02:${flag02}, type:${typeof flag02}`);

let flag10 = 0;// 0은 boolean은 false를 의미 합니다.
let flag20 = 1;// 1은 boolean은 true를 의미 합니다.
//Boolean() 변수의 값을 false,true로 변환 시켜주는 함수.
console.log(`flag10:${Boolean(flag10)},type:${typeof Boolean(flag10)}`);
console.log(`flag20:${Boolean(flag20)},type:${typeof Boolean(flag20)}`);

  

















































