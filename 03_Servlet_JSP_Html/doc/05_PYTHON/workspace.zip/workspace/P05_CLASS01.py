class FourCal:
    pass


a = FourCal()
type(a)

