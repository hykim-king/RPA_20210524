from FourCal import FourCal

#메소드 오버라이딩
class SafeFourCal06 (FourCal):
    def div(self):
        if self.second == 0:
            return 0
        else:
            return self.first / self.second



k = SafeFourCal06(3,0)
print(k.div())