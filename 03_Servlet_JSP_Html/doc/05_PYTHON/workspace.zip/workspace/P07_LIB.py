import calendar
#그해의 전체 달력 출력
#print(calendar.calendar(2021))

#년월 달려
print(calendar.prmonth(2021,9))
