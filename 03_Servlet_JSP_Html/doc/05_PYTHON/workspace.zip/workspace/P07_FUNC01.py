print(abs(3))
print(abs(-3))

#a
print(chr(97))

#객체가 자체적으로 가지고 있는 변수나 함수 반환
print(dir([1,2]))

#문자열로 파이썬 함수나 클래스를
#동적으로 실행할 때 사용
#a
print(eval('chr(97)'))
