import datetime
from bs4 import BeautifulSoup
from urllib.request import urlopen

now = datetime.datetime.now()
nowDate = now.strftime("%Y-%m-%d %H:%M")
print("Python crawling \n")
print(nowDate)
#오늘에 날씨
naverWetherUrl = "https://weather.naver.com/today/09545101"
html = urlopen(naverWetherUrl)
bsObject = BeautifulSoup(html,"html.parser")
temps = bsObject.find("strong","current")
print("-->서울:",temps.get_text())
#오늘 코로나 현황
print("#오늘 코로나 현황")
todayCovid19 = "http://ncov.mohw.go.kr/"
html = urlopen(todayCovid19)

bsObject = BeautifulSoup(html,"html.parser")
temps    = bsObject.find("span","data")
allInfo  = bsObject.find('span','num')

print("-->오늘 신규확진자:",temps.get_text())
print("-->현재 누적 확진자:",allInfo.get_text())

#naver 핫토픽

naverHot="https://www.naver.com/"
html = urlopen(naverHot)
bsObject=BeautifulSoup(html,"html.parser")
print("#naver 핫토픽")
for temps  in    bsObject.find_all("a","issue"):
    print("-->",temps.get_text())











