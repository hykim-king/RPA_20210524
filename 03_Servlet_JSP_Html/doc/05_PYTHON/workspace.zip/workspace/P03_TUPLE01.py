#튜플(Tuple)이란?
#리스트와 유사한 자료형
#값 변경 불가능
#()
t1 = (1,2,3)
#(1, 2, 3)
print(t1)

#튜플의 요솟값은 한 번 정하면 지우거나 변경할 수 없음!
#TypeError: 'tuple' object doesn't support item deletion
del t1[0]

t2 = (1,)

