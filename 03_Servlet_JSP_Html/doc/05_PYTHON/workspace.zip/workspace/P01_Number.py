#숫자형 사용법

a = 123
print(a)

a = -178
print(a)

#실수
b = 1.2
print(b)


b=4.24E10
print(b)


b=4.24e-10
print(b)


#진수
#8진수 : 숫자 0 + 알파벳 o 소문자, 대문자 O
a = 0o177
print(a)

#16진수 : 숫자 0 + 알파벳 x 소문자
a = 0x8ff
print(a)
