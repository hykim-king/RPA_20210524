from urllib.request import urlopen
from bs4 import BeautifulSoup

html = urlopen("https://www.naver.com/")
bsObject = BeautifulSoup(html,"html.parser")

#모든 내용 가지고 오기
#print(bsObject)

# for meta in bsObject.head.find_all('meta'):
#     print (meta.get('content'))

#원하는 태그 내용 가져 오기
#<meta content="IE=edge" http-equiv="X-UA-Compatible"/>
print(bsObject.head.find("meta",{"name":"description"}))