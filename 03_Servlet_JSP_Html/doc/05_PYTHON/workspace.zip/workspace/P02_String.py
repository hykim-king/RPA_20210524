#문자열 : 문자열 안에 작은 따옴표,큰 타옴표 포함 하기

food = "Python's favorite foot is perl "
#Python's favorite foot is perl 
print(food)


say = '"Python is very easy." he says.'

#"Python is very easy." he says.
print(say)


food = 'Python\'s favorite foot is perl'
print(food)
