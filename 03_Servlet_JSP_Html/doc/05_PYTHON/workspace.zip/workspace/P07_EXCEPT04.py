#오류 메시지 사용하기

class  MyError(Exception):
    def __str__(self):
        return "허용되지 않는 별명 입니다."

def sayNick(nick):
    if nick =='바보':
        raise MyError()

    print(nick)
# 천사
# 허용되지 않는 별명 입니다.
try:
    sayNick("천사")
    sayNick("바보")
except MyError  as e:
    print(e)