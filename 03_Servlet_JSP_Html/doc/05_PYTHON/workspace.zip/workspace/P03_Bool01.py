#bool : 참(True),거짓(False)을 나타내는 자료형
a = True
b = False

print(a)
print(b)

#조건문의 반환 값으로도 사용됨
#True
print(1 == 1)
#False
print(1 != 1)

#bool( ) 함수 : 자료형의 참/거짓을 식별하는 내장 함수
#True
print(bool('python'))

#False
print(bool(''))

var01 = [1,2,3]
#id(변수) : 2369255720256(주소번지)
print(id(var01))




