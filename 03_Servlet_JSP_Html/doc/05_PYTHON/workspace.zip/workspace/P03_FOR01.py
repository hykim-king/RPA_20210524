

test_list = ['one','two','three']

for i in test_list :
    print(i)

#range( )
#숫자 리스트를 자동으로 만들어주는 함수
a = range(22)
print(a)

b = range(1,11)
print(b)

for i in range(1,11):
    print(i)

#리스트 내포
#리스트 안에 for문 포함하기

numArray01 = [1,2,3,4]
result= []
for num in numArray01:
    result.append(num*3)

#[3, 6, 9, 12]
print(result)

#예제 3
#리스트 내포 안에 ‘if 조건’ 사용 가능
#[1, 2, 3, 4] 중에서 짝수에만 3을 곱하여 담도록 수정

numArray02 = [1,2,3,4]
result02 = [ num*3 for num in numArray02 if num % 2== 0]
#[6, 12]
print(result02)


















