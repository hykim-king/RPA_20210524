#숫자  연산자
#시칙연산

a = 3
b = 4
print(a+b)
print(a-b)
print(a*b)
print(a/b)

#// : 나눗셈 후 몫 반환
a =7
b= 4
print(7 // 4)

# ** 제곱
a = 3
b = 4
print(a ** b)

# 나머지 연산자
print( a % b)
