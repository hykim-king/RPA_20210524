import P06_MOD01

#24
print(P06_MOD01.add(11,13))

#-2
print(P06_MOD01.sub(11,13))