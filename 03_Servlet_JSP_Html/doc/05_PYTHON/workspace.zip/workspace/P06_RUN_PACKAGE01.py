#import game.sound.echo
#game.sound.echo.echo_test()

#__init__.py : 해당 디렉토리가 패키지의 일부임을 알려 준다.
# python 3.3 부터는 필요 없다.(단 호완성 때문에 넣어주는게 유리)
from game.sound import echo
echo.echo_test()