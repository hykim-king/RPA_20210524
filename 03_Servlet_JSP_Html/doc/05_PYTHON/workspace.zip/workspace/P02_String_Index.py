#문자열 인덱싱
strArray = "Life is too short, You need Python."

#문자열 왼쪽 부터
print(strArray[0])

#문자열 뒤부터 indexing
print(strArray[-1])


#슬라이싱
#strArray[시작번호:끝번호]
#끝 번호는 포함하지 않음

#Life
print(strArray[0:4])

strArray01 = "20210913Rainy"
date = strArray01[:8]
#20210913
print(date)

weather = strArray01[8:]
#Rainy
print(weather)

