#딕셔너리 쌍 추가, 삭제하기

dic01= {1:'a'}
#{1: 'a'}
print(dic01)

#추가
dic01[2] = 'b'
#{1: 'a', 2: 'b'}
print(dic01)

#삭제 : del
del dic01[1] #key가 1인 key:value 쌍 삭제
#{2: 'b'}
print(dic01)

#딕셔너리에서 Key 사용해 Value 얻기
grade = {'pay':10,'julliet':99}
#10
print(grade['pay'])

#딕셔너리 관련 함수
#keys()

dic02 = {'name':'pey','phone':'01012345678','birth':'0914'}
#dict_keys(['name', 'phone', 'birth'])
print(dic02.keys());

for k in dic02.keys():
    print(k)
    print(dic02[k])

#dict_keys 객체를 리스트로 변환하는 방법
listDic = list(dic02.keys())
#['name', 'phone', 'birth']
print(listDic)

















