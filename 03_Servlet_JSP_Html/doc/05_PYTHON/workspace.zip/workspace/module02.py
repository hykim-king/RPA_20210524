import mod2
print(mod2.PI)

a = mod2.Math()
print(a.solv(10))

