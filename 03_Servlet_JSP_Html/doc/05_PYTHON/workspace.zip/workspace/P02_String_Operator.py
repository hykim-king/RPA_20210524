#문자열 연산

head = "Python"
tail = " is fun "

#Python is fun 
print(head + tail)


#문자열 곱하기
a = "Python"
print(a*10)

a = "-"
print(a*20)
print(head)
print(a*20)

#문자열 길이
a = "Life is too short"
print(len(a))
