from FourCal import FourCal

class SafeFourCal(FourCal):
    def div(self):
        if self.second ==0 :
            return 0
        else:
            return self.first/self.second


b = SafeFourCal(4,0)
print(b.div())
