#예외 만들기

class MyError(Exception):
    pass


def sayNick(nick):
    if nick =='바보':
        raise MyError()

    print(nick)


#sayNick("바보")

# 천사
# 허용되지 않는 별명 입니다.
try:
    sayNick("천사")
    sayNick("바보")
except MyError:
    print("허용되지 않는 별명 입니다.")



