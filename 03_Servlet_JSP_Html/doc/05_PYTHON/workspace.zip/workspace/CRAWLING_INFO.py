from datetime import datetime
from urllib.request import urlopen
from bs4 import BeautifulSoup

now = datetime.now()
nowDate = now.strftime("%Y-%m-%d %H:%M")

print("\n  Python crawing \n")
print(nowDate)
#오늘의 날씨
print('#오늘의 날씨')
naverWetherUrl = "https://weather.naver.com/today/09545101"

html = urlopen(naverWetherUrl)
bsObject = BeautifulSoup(html,"html.parser")
temps = bsObject.find('strong','current');
print('-->서울날씨 :', temps.get_text())

#오늘 코로나 현황
print('#오늘 국내 코로나 현황')
url = "http://ncov.mohw.go.kr/"

html = urlopen(url)
bsObject = BeautifulSoup(html,"html.parser")
temps = bsObject.find('span','data');
allInfo = bsObject.find('span','num');

print('-->오늘의 신규 확진자 :', temps.get_text())
print('-->현재까지  확진자 :', allInfo.get_text())

# 오늘의 핫토픽
print('#오늘의 핫토픽')
url = "https://www.naver.com/"

html = urlopen(url)
bsObject = BeautifulSoup(html,"html.parser")
for temps in bsObject.find_all('a',"issue"):
    print('--> ' , temps.get_text())

