#문자열 내장 함수
strString = "hobby"
#문자 개수 세는 함수
#2
print(strString.count("b"))

#찾는 문자열이 처음 나온 위치 반환
#없으면 -1반환
#2
print(strString.find('b'))

strString02 = " Hi "
#Hi
print(strString02.strip())

strString03 = "Life is too short."
#replace(바뀌게 될 문자열, 바꿀 문자열)
#Your leg is too short.
print(strString03.replace("Life","Your leg"))

strString04 = "Life is too short."
#공백 또는 특정 문자열을 구분자로 해서
# 문자열 분리된 문자열은 리스트로 반환됨
#['Life', 'is', 'too', 'short.']
print(strString04.split())





