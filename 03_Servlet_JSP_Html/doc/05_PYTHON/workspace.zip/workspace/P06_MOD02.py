PI = 3.141592

#원넓이는 구하는 Math클래스
class Math:
    def solv(self,r):
        return PI * (r ** 2)

def add(a,b):
    return a+b

