a = 123
print(a)