# 숫자 바로 대입 %d
# 문자열 포맷 코드 %s

strString = "I eat %d apples." % 3
# 숫자 바로 대입
#I eat 3 apples.
print(strString)

strString = "I eat %s apples." % "five"
#I eat five apples.
print(strString)

number =10
day    ="three"
strString = "I ate %d apples. so I was sick for %s days." %(number,day)
#I ate 10 apples. so I was sick for three days.
print(strString)

#정렬과 공백
#%s를 숫자와 함께 사용하면, 공백과 정렬 표현 가능
strString= "%10s" % "hi"
#양수면 오른쪽 정렬
#________hi
print(strString)

strString= "%-10s" % "hi"
#hi________
print(strString)

floatStr = "%0.4f"  % 3.123456
#3.1235
print(floatStr)
floatStr = "%10.4f"  % 3.123456
#____3.1235
print(floatStr)

name ="이상무"
age  = 22

strString = f"나의 이름은 {name} 입니다. 나이는 {age}입니다."
#나의 이름은 이상무 입니다. 나이는 22입니다.
print(strString)



