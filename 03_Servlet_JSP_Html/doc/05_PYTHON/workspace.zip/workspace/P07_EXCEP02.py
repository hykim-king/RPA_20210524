#여러 개의 오류 처리 하기

try:
   a = [1,2]
   print(a[3])
   4/0
except ZeroDivisionError:
    print("0으로 나눌수 없습니다.")
except IndexError:
    print("인덱싱을할 수 없습니다.")