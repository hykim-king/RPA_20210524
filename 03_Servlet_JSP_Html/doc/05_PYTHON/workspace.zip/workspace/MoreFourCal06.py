from FourCal import FourCal

#메소드 추가 
class MoreFourCal06(FourCal):
    def pow(self):
        result = self.first ** self.second
        return result


a = MoreFourCal06(3,4)
#
# print(a.add())
# print(a.mul())
#81
print(a.pow())


