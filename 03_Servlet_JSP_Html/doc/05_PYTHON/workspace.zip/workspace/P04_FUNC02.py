#매개변수에 초깃값을 미리 설정

def say_myself(name,old,man=True):
    print("나에 이름은 %s 입니다." % name)
    print("나이는 %d살 입니다." % old)

    if man :
        print("남자 입니다.")
    else :
        print("여자 입니다.")


#say_myself("이상무",23)
say_myself("이상무",23,False)