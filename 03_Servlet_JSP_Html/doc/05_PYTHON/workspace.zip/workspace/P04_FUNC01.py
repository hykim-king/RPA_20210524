#함수
# def : 함수를 만들 때 사용하는 예약어
# 함수 이름은 임의로 생성 가능
# 매개변수는 함수에 입력으로 전달되는 값을 받는 변수

def add(a,b):
    return a+b

a = 3
b = 4
c = add(a,b)
#7
print(c)

#함수 호출 시 매개변수 지정 가능
result = add(a=3, b=7)
#10
print(result)


