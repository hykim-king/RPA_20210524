class FourCal:
    #생성자

    def __init__(self,first,second):
        self.first = first
        self.second = second

    def setdata(self,first,second):
        self.first = first
        self.second = second

    def add(self):
        result = self.first + self.second
        return result

    def mul(self):
        result = self.first * self.second
        return result

    def div(self):
        result = self.first / self.second
        return result;

    def sub(self):
        result = self.first - self.second
        return result;

# a = FourCal()
# a.setdata(10,20)
# #30
# print(a.add())
# print(a.mul())
# print(a.div())
# print(a.sub())

# b = FourCal(3,5)
# print(b.add())
