#클래스 변수 : java에 static변수
#공유변수
class Family:
    lastName = "Kim"


print(Family.lastName)

k = Family()
j = Family()

Family.lastName ="김"

#Kim
print(k.lastName)
#Kim
print(j.lastName)

#2734227771264
print(id(k.lastName))
#2734227771264
print(id(j.lastName))