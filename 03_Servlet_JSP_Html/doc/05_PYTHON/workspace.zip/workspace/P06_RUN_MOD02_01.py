import P06_MOD02

result = P06_MOD02.add(11,13)
print(result)

k = P06_MOD02.Math()
print(k.solv(10))