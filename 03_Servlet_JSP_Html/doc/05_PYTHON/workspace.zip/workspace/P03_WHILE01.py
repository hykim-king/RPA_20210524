#while문 기본 구조
#열 번 찍어 안 넘어가는 나무 없다’는 속담 구현
treeHit = 0
while treeHit < 10:
    treeHit=treeHit+1

    print("나무를 %d번 찍었습니다." % treeHit)

    if treeHit == 10 :
        print('나무 넘어 갑니다.')