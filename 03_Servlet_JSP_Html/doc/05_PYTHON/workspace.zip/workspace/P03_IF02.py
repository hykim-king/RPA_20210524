pocket =['paper','cellphone']
card  = True

if 'money'  in pocket:
    print('택시를 타고 가라')
elif card :
    print('택시를 타고 가라')
else:
    print('걸어 가라')
