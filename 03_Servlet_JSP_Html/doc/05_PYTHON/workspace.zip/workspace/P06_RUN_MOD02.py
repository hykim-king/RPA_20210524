#from P06_MOD01 import add,sub

#모듈 내에 있는 모든 함수 사용.
from P06_MOD01 import *

print(add(11,13))
print(sub(11,13))