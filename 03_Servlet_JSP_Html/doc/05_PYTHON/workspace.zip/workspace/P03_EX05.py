a = [70,60,55,75,95,90,80,80,85,100]

total = 0

for  score  in a:
    total +=score

average = total / len(a)
print(average)