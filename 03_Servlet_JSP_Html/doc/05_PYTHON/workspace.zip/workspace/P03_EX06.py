numbers = [1,2,3,4,5]
#홀수에만 2를 곱하고 저장 하세요.
result = [  n * 2 for n in numbers if n % 2 ==1]
#[2, 6, 10]
print(result)
