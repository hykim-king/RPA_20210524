#여러 줄인 문자열 변수에 대입

multiline = "Life is too short\nYou need python."
#Life is too short
#You need python.
print(multiline)


multiline =  '''
Life is too short
You need python.
'''

#Life is too short
#You need python.
print(multiline)
