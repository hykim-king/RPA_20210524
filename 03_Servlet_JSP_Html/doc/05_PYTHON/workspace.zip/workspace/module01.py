import mod1

print(mod1.add(3,5))

print(mod1.sub(3,5))