/**
 * Class 객체지향언어 : class와 object
 * 
class Person{
	name;
	age;
	
	speak();
}

class
 -templage
 -declare once
 -no data in


object
 -instance of class
 -created many times
 -data in
 */

'use strict'
// object-oriendted programming
// class : template
// object: instance of a class
// javascript classes
 
// -introduced in ES6
// -syntatical sugar over prototype-based inheritable

// 1. class declarations
class Person{
	//fields
	
	//constructor
	constructor(name,age){
		//fields
		this.name =name;
		this.age  =age;
	}
 
	//methods
    speak(){
		console.log(`${this.name}: hello!`);
	}
	
}

const ellie = new Person('james',23);
console.log(ellie.name);
console.log(ellie.age);
console.log(ellie.speak());


//2. Getter and setters
class User{
	
	constructor(firtName, lastName,age){
		this.firstName = firtName;
		this.lastName  = lastName;
		this.age = age
	}
	
	get age(){
		return this._age;
	}
	
	set age(value){
		if(value<0){
			throw Error('age can not be negative');
		}
		this._age = value;
	}
}


const  user01 =new User('Steve','Job',-1);
console.log(user01.age);
console.log(user01.firstName );






















