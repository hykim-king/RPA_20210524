/**
* <pre>
* com.sist.eclass.reply.controller
* Class Name : ReplyDao.java
* Description:
* Author: HB
* Since: 2021/03/13
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/13 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.reply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.dao.BoardDao;
import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.cmn.ConnectionMaker;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.JDBCUtil;
import com.sist.eclass.cmn.WorkStandard;
import com.sist.eclass.cmn.search.domain.SearchVO;
import com.sist.eclass.reply.domain.ReplyVO;

/**
 * @author HB
 *
 */
public class ReplyDao implements WorkStandard {
	final Logger LOG = Logger.getLogger(ReplyDao.class);
	
	
	public ReplyDao() {
		
	}
	
	
	@Override
	public List<?> doRetrieve(DTO param) {
		List<ReplyVO>  list = new ArrayList<ReplyVO>();
		//------------------------------
		ReplyVO  inVO = (ReplyVO) param;
		LOG.debug("0.param:" + inVO);
		
		Connection connection    = null;
		PreparedStatement  pstmt = null;   
		ResultSet          rs    = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb=new StringBuffer(2000);
			sb.append(" SELECT                                    \n");
			sb.append("     rep_seq,                              \n");
			sb.append("     rep_contents,                         \n");
			sb.append("     reg_id,                               \n");
			sb.append("     TO_CHAR(reg_dt,'YYYY/MM/DD') reg_dt   \n");
			sb.append(" FROM   reply                              \n");
			sb.append(" WHERE seq = ?                             \n");
			sb.append(" ORDER BY rep_seq ASC                      \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			  
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setInt(1, inVO.getSeq());  
			  
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			while(rs.next()==true) {
				ReplyVO  reply=new ReplyVO();
				reply.setRepSeq(rs.getInt("rep_seq"));
				reply.setRepContents(rs.getString("rep_contents"));
				reply.setRegId(rs.getString("reg_id"));
				reply.setRegDt(rs.getString("reg_dt"));
				
				list.add(reply);
			}
			//조회 데이터 확인    
			LOG.debug("==========================");
			for(ReplyVO vo :list) {
				LOG.debug(vo);
			}
			LOG.debug("=====================조회건수"+list.size());
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();				
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
		}
		
		//------------------------------			
		return list;
	}

	@Override
	public int doUpdate(DTO param) {
		int flag = 0;
		ReplyVO inVO = (ReplyVO) param;
		LOG.debug("0.param:" + inVO);
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" UPDATE reply           \n");
			sb.append(" SET rep_contents = ?   \n");
			sb.append("     ,reg_id = ?        \n");
			sb.append("     ,reg_dt = SYSDATE  \n");
			sb.append(" WHERE rep_seq = ?      \n");
			
			
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			int i=0;
			
			pstmt.setString(++i, inVO.getRepContents()); // VARCHAR2
			pstmt.setString(++i, inVO.getRegId()); // VARCHAR2
			pstmt.setInt(++i,    inVO.getRepSeq());// NUMBER
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);

			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}
		// -------------------------

		return flag;
	}

	@Override
	public DTO doSelectOne(DTO param) {
		ReplyVO  reply = null;
		//------------------------------
		ReplyVO  inVO = (ReplyVO) param;
		LOG.debug("0.param:" + inVO);
		
		Connection connection    = null;
		PreparedStatement  pstmt = null;
		ResultSet          rs    = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb=new StringBuffer(2000);
			sb.append(" SELECT                                    \n");
			sb.append("     rep_seq,                              \n");
			sb.append("     rep_contents,                         \n");
			sb.append("     reg_id,                               \n");
			sb.append("     TO_CHAR(reg_dt,'YYYY/MM/DD') reg_dt   \n");
			sb.append(" FROM   reply                              \n");
			sb.append(" WHERE rep_seq = ?                         \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setInt(4, inVO.getRepSeq());
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			if(rs.next()==true) {
				reply=new ReplyVO();
				reply.setRepSeq(rs.getInt("rep_seq"));
				reply.setRepContents(rs.getString("rep_contents"));
				reply.setRegId(rs.getString("reg_id"));
				reply.setRegDt(rs.getString("reg_dt"));
			}
			//조회 데이터 확인
			LOG.debug("==========================");
			LOG.debug(reply);
			LOG.debug("==========================");
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();				
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
		}
		
		//------------------------------			
		return reply;
	}

	@Override
	public int doDelete(DTO param) {
		int flag = 0;
		ReplyVO inVO = (ReplyVO) param;
		LOG.debug("0.param:" + inVO);
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" DELETE FROM reply   \n");
			sb.append(" WHERE   rep_seq = ? \n");
			
			
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			int i=0;
			pstmt.setInt(++i,    inVO.getRepSeq());// NUMBER
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);

			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}
		// -------------------------

		return flag;
	}

	@Override
	public int doInsert(DTO param) {
		int flag = 0;
		ReplyVO inVO = (ReplyVO) param;
		LOG.debug("0.param:" + inVO);
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" INSERT INTO reply (     \n");
			sb.append("     rep_seq,            \n");
			sb.append("     seq,                \n");
			sb.append("     rep_contents,       \n");
			sb.append("     reg_id              \n");
			sb.append(" ) VALUES (              \n");
			sb.append("     reply_seq.nextval,  \n");
			sb.append("     ?,                  \n");
			sb.append("     ?,                  \n");
			sb.append("     ?                   \n");
			sb.append(" )                       \n");
			
			
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			int i=0;
			//pstmt.setInt(++i,    inVO.getRepSeq());// NUMBER
			pstmt.setInt(++i, inVO.getSeq()); // VARCHAR2
			pstmt.setString(++i, inVO.getRepContents()); // VARCHAR2
			pstmt.setString(++i, inVO.getRegId()); // VARCHAR2
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);
   
			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}
		// -------------------------

		return flag;
	}

}
