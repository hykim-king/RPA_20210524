package com.sist.eclass.jdbc;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.cmn.JDBCUtil;

public class JdbcTestMain02 {
//	JavaCode에서 DB연결														
//	1. JDBC 드라이버 로딩														
//	2. 데이터베이스 커넥션 구함														
//	3. 쿼리 실행 PreparedStatement														
//	4. 쿼리실행														
//	5. 쿼리 실행 결과 처리(select결과가 있으면 결과 처리,int)														
//	6. ResultSet ,PreparedStatement 자원반납														
//	7. 커넥션 자원반납	
	//final static String DB_URL = "jdbc:oracle:thin:@211.238.142.124:1521:xe";
	final static String DB_URL = "jdbc:oracle:thin:@211.238.142.124:1521:xe";
	final static String USER_ID = "SCOTT";
	final static String USER_PASS = "sist";

	final static Logger LOG = Logger.getLogger(JdbcTestMain.class);

	private BoardVO  board01;
	private BoardVO  board02;
	private BoardVO  board03;
//	--2   ,title_2   ,contents_2   ,'eclass_2','eclass_2'
//	--102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
//	--202	
	public JdbcTestMain02() {
		board01 =new BoardVO(2,   "title_2",   "contents_2",   0, "10", "강사", "", "eclass_2", "");
		board02 =new BoardVO(102, "title_102", "contents_102", 0, "10", "강사", "", "eclass_2", "");
		board03 =new BoardVO(202, "title_202", "contents_202", 0, "10", "강사", "", "eclass_2", "");
		
	}
	
	public static void main(String[] args) {

		JdbcTestMain02 jtMain = new JdbcTestMain02();
		jtMain.doDelete(jtMain.board01);
		jtMain.doInsert(jtMain.board01);
		BoardVO outVO = jtMain.doSelectOne(jtMain.board01);
		if(null !=outVO) {
			LOG.debug("outVO:"+outVO);
			LOG.debug("★★★★★★★★★★★★★★★★★★");
			LOG.debug("★등록,단건조회 성공            ★");
			LOG.debug("★★★★★★★★★★★★★★★★★★");
		}
		
		//

	}// --main

	
	public BoardVO doSelectOne(BoardVO param) {
		BoardVO board=null;
	
		BoardVO inVO = param;
		LOG.debug("doSelectOne()");
		LOG.debug("0.param:" + inVO);
		Connection connection   = null;
		PreparedStatement  pstmt = null;
		//Return Value 처리
		ResultSet  rs= null;
		try {
			connection = getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT seq,                                            \n");
			sb.append("        title,                                          \n");
			sb.append("        contents,                                       \n");
			sb.append("        read_cnt,                                       \n");
			sb.append("        div,                                            \n");
			sb.append("        reg_id,                                         \n");
			sb.append("        reg_dt,                                         \n");
			sb.append("        mod_id,                                         \n");
			sb.append("        TO_CHAR(mod_dt,'YYYY-MM-DD HH24:MI:SS') mod_dt  \n");   
			sb.append(" FROM board                                             \n");
			sb.append(" WHERE seq = ?                                          \n");
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setInt(1, inVO.getSeq());
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			
			if(rs.next()==true) {
				board = new BoardVO();//return BoardVO 객체 생성
				
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setContents(rs.getString("contents"));
				board.setReadCnt(rs.getInt("read_cnt"));
				board.setDiv(rs.getString("div"));
				board.setRegId(rs.getString("reg_id"));
				board.setRegDt(rs.getString("reg_dt"));
				board.setModId(rs.getString("mod_id"));
				board.setModDt(rs.getString("mod_dt"));
				
			}
			
			LOG.debug("3.2  board	:" + board);
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		
		return board;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public int doDelete(BoardVO param) {
		int flag = 0;
		BoardVO inVO = param;
		
		LOG.debug("doDelete()");
		LOG.debug("0.param:" + inVO);
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			connection = getConnection();
			// Transaction user가 제어.
			connection.setAutoCommit(false);
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(50);
			sb.append(" DELETE FROM board  \n");
			sb.append(" WHERE seq = ?      \n");
			pstmt = connection.prepareStatement(sb.toString());

			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + pstmt);

			// param set
			pstmt.setInt(1, inVO.getSeq());
			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				LOG.debug("SQLException:" + e1.getMessage());
				e1.printStackTrace();
			}
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
		}

		return flag;
	}

	public int doInsert(BoardVO param) {
		int flag = 0;
		BoardVO inVO = param;
		LOG.debug("0.param:" + inVO);
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" INSERT INTO BOARD ( \n");
			sb.append(" 	seq,            \n");
			sb.append(" 	title,          \n");
			sb.append(" 	contents,       \n");
			sb.append(" 	div,            \n");
			sb.append(" 	reg_id,         \n");
			sb.append(" 	mod_id          \n");
			sb.append(" )VALUES (           \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?               \n");
			sb.append(" )                   \n");
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			pstmt.setInt(1,    inVO.getSeq());// NUMBER
			pstmt.setString(2, inVO.getTitle()); // VARCHAR2
			pstmt.setString(3, inVO.getContents()); // VARCHAR2
			pstmt.setString(4, inVO.getDiv()); // VARCHAR2
			pstmt.setString(5, inVO.getRegId()); // VARCHAR2
			pstmt.setString(6, inVO.getModId()); // VARCHAR2
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);

			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}
		// -------------------------

		return flag;
	}

	/**
	 * Driver로딩,
	 * 
	 * @return Connection
	 * @throws SQLException 
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;

		try {
			//클래스 로더를 통해 해당 데이터베이스 드라이버를 로드
			//JVM에게 해당 클래스의 정보를 로드한다
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			LOG.debug("ClassNotFoundException:" + e.getMessage());
			e.printStackTrace();
		}
		
		LOG.debug("1.JDBC 드라이버 로딩 성공");
		con = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("2.데이터베이스 커넥션 구함:" + con);
		return con;
	}

}// --class
