package com.sist.eclass.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.board.servie.BoardService;
import com.sist.eclass.cmn.StringUtil;
import com.sist.eclass.cmn.search.domain.SearchVO;
import com.sist.eclass.member.controller.MemberController;
import com.sist.eclass.member.service.MemberService;

/**
 * Servlet implementation class MainController
 */
@WebServlet(description = "main", urlPatterns = { "/main/main.do" })
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	BoardService  boardService;
	final Logger LOG = Logger.getLogger(MainController.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainController() {
        super();
        boardService = new BoardService();
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String workDiv = StringUtil.nvl(request.getParameter("work_div"),"doRetrieve");
		LOG.debug("------------------------");
		LOG.debug("-workDiv-"+workDiv);
		LOG.debug("------------------------");
		switch(workDiv) {
			case "main":
				main(request,response);
				break;
		}		
	}

	protected void main(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-main-");
		LOG.debug("------------------------");		
		
		   //검색 목록 데이터 생성.
		   //1.view data 일기
//		      search_div
//		      search_word
//		      page_size
//		      page_num
//		      div
		  String searchDiv = StringUtil.nvl(request.getParameter("search_div"),"");
		  String searchWord = StringUtil.nvl(request.getParameter("search_word"),"");  
		  String pageSize = StringUtil.nvl(request.getParameter("page_size"),"5");
		  String pageNum = StringUtil.nvl(request.getParameter("page_num"),"1");
		  String div = StringUtil.nvl(request.getParameter("div"),"10");//공지사항
		     
		  LOG.debug("searchDiv:"+searchDiv);
		  LOG.debug("searchWord:"+searchWord);
		  LOG.debug("pageSize:"+pageSize);
		  LOG.debug("pageNum:"+pageNum);
		  LOG.debug("div:"+div);
		   
		  SearchVO  inVO=new SearchVO();
		  inVO.setSearchDiv(searchDiv);
		  inVO.setSearchWord(searchWord);
		  inVO.setPageSize(Integer.parseInt(pageSize));
		  inVO.setPageNum(Integer.parseInt(pageNum));
		  inVO.setDiv(div);
		  LOG.debug("======================");
		  LOG.debug("=inVO="+inVO); 
		  LOG.debug("======================"); 
		  
		  //공지사항
		  List<BoardVO>   boardList10 = (List<BoardVO>) this.boardService.doRetrieve(inVO);
		
		  //자유게시판
		  inVO.setDiv("20");
		  List<BoardVO>   boardList20 = (List<BoardVO>) this.boardService.doRetrieve(inVO);
		  
		  
		  request.setAttribute("board_list_10", boardList10);
		  request.setAttribute("board_list_20", boardList20);
		  
		  RequestDispatcher  dispatcher= request.getRequestDispatcher("/main/main.jsp");
		  dispatcher.forward(request, response);			
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
