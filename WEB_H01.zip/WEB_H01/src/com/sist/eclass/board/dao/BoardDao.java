/**
* <pre>
* com.sist.eclass.board.domain
* Class Name : BoardDao.java
* Description: 공지사항,게시판 dao
* Author: sist
* Since: 2021/02/18
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/02/18 최초생성
*
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.board.dao;

import java.io.ObjectInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;

import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.cmn.ConnectionMaker;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.JDBCUtil;
import com.sist.eclass.cmn.WorkStandard;
import com.sist.eclass.cmn.search.domain.SearchVO;

/**
 * @author sist
 *
 */
public class BoardDao implements WorkStandard {

	final Logger LOG = Logger.getLogger(BoardDao.class);

	
	public BoardDao() {
		
	}
	
	/**
	 * 조회 count증가
	 * @param param   
	 * @return 성공:1, 실패:0
	 */
	public int doReadCnt(DTO param){ 
		int flag = 0;
		BoardVO inVO = (BoardVO) param;
		Connection connection = null;
		PreparedStatement  pstmt = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb=new StringBuffer(500);
			sb.append(" UPDATE board                    \n");
			sb.append(" SET read_cnt=NVL(read_cnt,0)+1  \n"); 
			sb.append(" WHERE seq = ?                   \n");
//			3. 쿼리 실행 PreparedStatement			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());			
			pstmt = connection.prepareStatement(sb.toString());
			
			pstmt.setInt(1, inVO.getSeq());
			
			flag =pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
			
		}
		
		
		return flag;
	}
	    
	/**
	 * 목록 조회 
	 * @return
	 */
	@Override
	public List<BoardVO> doRetrieve(DTO param){
		List<BoardVO>  list = new ArrayList<BoardVO>();
		//------------------------------
		SearchVO  inVO = (SearchVO) param;
		LOG.debug("0.param:" + inVO);
		
		Connection connection    = null;
		PreparedStatement  pstmt = null;
		ResultSet          rs    = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sbWhere=new StringBuffer(500);//동적 검색 조건 처리
			//전체("",제목=10,내용=20,내용+제목(30))
			
			//검색조건이 있으면,
			if(null !=inVO && inVO.getSearchDiv()!="" ) {
				
				//제목
				if(inVO.getSearchDiv().equals("10")) {
					sbWhere.append("AND  title like ? ||'%'     \n");
				//내용
				}else if(inVO.getSearchDiv().equals("20")) {
					sbWhere.append("AND  contents like ? ||'%'  \n");
				//사용자 ID	
				}else if(inVO.getSearchDiv().equals("30")) {
					sbWhere.append("AND  reg_id like ? ||'%'    \n");
				//제목+내용	
				}else if(inVO.getSearchDiv().equals("40")) {
					sbWhere.append("AND ( title like   ? ||'%'  OR contents like  ? ||'%'   )  \n");
				}	
				
				
			}
			
			
			
			
			StringBuffer sb=new StringBuffer(2000);
			//--------------------------------------------------
			sb.append(" SELECT a.seq ,a.rnum  ,a.title  ,a.read_cnt,a.div  ,                                                            \n");
			sb.append("       CASE WHEN TO_CHAR(SYSDATE,'YYYY/MM/DD')=TO_CHAR(a.mod_dt,'YYYY/MM/DD')  THEN TO_CHAR(a.mod_dt,'HH24:MI')  \n");
			sb.append("            ELSE TO_CHAR(a.mod_dt,'YYYY/MM/DD')                                                                  \n");
			sb.append("       END mod_dt ,                                                                                              \n");
			sb.append("       a.mod_id  ,b.cnt total_cnt                                                                                \n");
			sb.append(" FROM (                                                                                                          \n");
			sb.append(" 		SELECT TT1.*                                                                                            \n");
			sb.append(" 		FROM (                                                                                                  \n");
			sb.append(" 				SELECT rownum rnum,T1.*                                                                         \n");
			sb.append(" 				FROM (                                                                                          \n");
			sb.append(" 						SELECT *                                                                                \n");
			sb.append(" 						FROM board                                                                              \n");
			sb.append(" 						WHERE seq>0                                                                             \n");
			sb.append(" 						AND  div = ?                                                                            \n");
			//-------------------------------------------------------------------------------------------------------------------------------
			//WHERE조건 
			//-------------------------------------------------------------------------------------------------------------------------------
			
			//**************************
			sb.append(sbWhere.toString());
			//**************************
			
			//-------------------------------------------------------------------------------------------------------------------------------
			sb.append(" 						ORDER BY mod_dt DESC                                                                    \n");
			sb.append(" 				)T1                                                                                             \n");
			sb.append(" 		) TT1                                                                                                   \n");
			sb.append(" 		WHERE rnum BETWEEN ?*(?-1)+1 AND ? * (?-1)+?                                                                             \n");
//			sb.append(" 		--WHERE rnum BETWEEN :PAGE_SIZE*(:PAGE_NUM-1)+1 AND :PAGE_SIZE*(:PAGE_NUM-1)+:PAGE_SIZE                 \n");
			sb.append(" )A CROSS JOIN (                                                                                                 \n");
			sb.append(" --총건수                                                                                                                                                                                                                    \n");
			sb.append(" SELECT COUNT(*) CNT                                                                                             \n");
			sb.append(" FROM board                                                                                                      \n");
			sb.append(" WHERE seq>0                                                                                                     \n");
			sb.append(" AND  div = ?                                                                            \n");
			
			//-------------------------------------------------------------------------------------------------------------------------------
			//WHERE조건 
			//-------------------------------------------------------------------------------------------------------------------------------
			
			//**************************
			sb.append(sbWhere.toString());
			//**************************			

			//-------------------------------------------------------------------------------------------------------------------------------
			sb.append(" )B                                                                                                              \n");			
			
			//--------------------------------------------------
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			//--param set---------------------------------------------------
			// 검색에 관련된 부분은 option
			// paging관련된 부분은 필수
			
			//제목,내용....
			
			//검색조건이 있는 경우
			
			if(null !=inVO && inVO.getSearchDiv()!="") {
				
				//제목:10,내용:20,등록자id:30	
				if(inVO.getSearchDiv().equals("10")
					 ||inVO.getSearchDiv().equals("20")
					 ||inVO.getSearchDiv().equals("30")
				   ) {
					pstmt.setString(1, inVO.getDiv());
					pstmt.setString(2, inVO.getSearchWord());
					
					pstmt.setInt(3, inVO.getPageSize());
					pstmt.setInt(4, inVO.getPageNum());
					pstmt.setInt(5, inVO.getPageSize());
					pstmt.setInt(6, inVO.getPageNum());		
					pstmt.setInt(7, inVO.getPageSize());
					pstmt.setString(8, inVO.getDiv());		
					pstmt.setString(9, inVO.getSearchWord());
					
				//제목+내용:40	
				}else if(inVO.getSearchDiv().equals("40")){
					pstmt.setString(1, inVO.getDiv());
					pstmt.setString(2, inVO.getSearchWord());
					//추가
					pstmt.setString(3, inVO.getSearchWord());
					
					pstmt.setInt(4, inVO.getPageSize());
					pstmt.setInt(5, inVO.getPageNum());
					pstmt.setInt(6, inVO.getPageSize());
					pstmt.setInt(7, inVO.getPageNum());		
					pstmt.setInt(8, inVO.getPageSize());
					pstmt.setString(9, inVO.getDiv());		
					pstmt.setString(10, inVO.getSearchWord());
					//추가
					pstmt.setString(11, inVO.getSearchWord());
				}
				
			
			}else {//검색 조건이 없는 경우(전체)
				//게시판 구분:목록
				//VARCHAR2 는 문자열의 바이트를 기준으로 하기 때문에 ASCII Code 에 있는 문자(!Byte)인지 한글(2BYTE)인지에 따라 저장할 수 있는 단어수가 달라집니다.
				//NVARCHAR2를 사용할 경우 문자열의 바이트가 아닌 문자 갯수 자체를 길이로 취급하므로 한글, 영어, 기타 외국어 여부와 상관없이 처리할 수 있습니다.
				pstmt.setString(1, inVO.getDiv());
				pstmt.setInt(2, inVO.getPageSize());
				pstmt.setInt(3, inVO.getPageNum());
				pstmt.setInt(4, inVO.getPageSize());
				pstmt.setInt(5, inVO.getPageNum());		
				pstmt.setInt(6, inVO.getPageSize());
				//게시판 구분:전체 건수
				pstmt.setNString(7, inVO.getDiv());
			}
			//--param set---------------------------------------------------
			
			
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			
			while(rs.next()==true) {
				BoardVO  board=new BoardVO();
				
				board.setSeq(      rs.getInt("seq"));
				board.setTitle(    rs.getString("title"));
				board.setReadCnt(  rs.getInt("read_cnt"));
				board.setDiv(      rs.getString("div"));
				board.setModId(    rs.getString("mod_id"));
				board.setModDt(    rs.getString("mod_dt"));
				
				board.setNum(     rs.getInt("rnum"));//글번호
				board.setTotalCnt( rs.getInt("total_cnt"));//총글수
				
				//list에 추가
				list.add(board);
			}//--while
			
			//조회 데이터 확인
			LOG.debug("==========================");
			for(BoardVO vo :list) {
				LOG.debug(vo);
			}
			LOG.debug("=====================조회건수"+list.size());
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();				
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
		}
		
		//------------------------------			
		return list;
	}
	
	/**
	 * 수정
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	@Override
	public int doUpdate(DTO param) {
		int flag = 0;
		//------------------------------
		BoardVO inVO = (BoardVO) param;
		LOG.debug("0.param:" + inVO);
		
		Connection connection = null;
		PreparedStatement  pstmt = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			
			StringBuffer sb=new StringBuffer(500);
			sb.append(" UPDATE board                \n");
			sb.append(" SET title = ?,              \n");
			sb.append("     contents = ?,           \n");
			sb.append("     mod_id = ?,             \n");
			sb.append("     mod_dt = SYSDATE,       \n");
			sb.append("     div = ?                 \n");
			sb.append(" WHERE seq = ?               \n");			
//			3. 쿼리 실행 PreparedStatement			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			
			pstmt.setString(1, inVO.getTitle());    // VARCHAR2			
			pstmt.setString(2, inVO.getContents()); // VARCHAR2
			pstmt.setString(3, inVO.getModId()); // VARCHAR2
			pstmt.setString(4, inVO.getDiv()); // VARCHAR2
			pstmt.setInt(5,    inVO.getSeq());// NUMBER
			
			flag =pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
			
		}
		//------------------------------		
		return flag;
	}
	
	/**
	 * 단건조회 
	 * @param param
	 * @return BoardVO
	 */
	@Override
	public BoardVO doSelectOne(DTO param) {
		BoardVO board=null;
	
		BoardVO inVO = (BoardVO) param;
		LOG.debug("doSelectOne()");
		LOG.debug("0.param:" + inVO);
		Connection connection   = null;
		PreparedStatement  pstmt = null;
		//Return Value 처리
		ResultSet  rs= null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT seq,                                            \n");
			sb.append("        title,                                          \n");
			sb.append("        contents,                                       \n");
			sb.append("        read_cnt,                                       \n");
			sb.append("        div,                                            \n");
			sb.append("        reg_id,                                         \n");
			sb.append("        reg_dt,                                         \n");
			sb.append("        mod_id,                                         \n");
			sb.append("        TO_CHAR(mod_dt,'YYYY-MM-DD HH24:MI:SS') mod_dt  \n");   
			sb.append(" FROM board                                             \n");
			sb.append(" WHERE seq = ?                                          \n");
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setInt(1, inVO.getSeq());
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			
			if(rs.next()==true) {
				board = new BoardVO();//return BoardVO 객체 생성
				
				board.setSeq(      rs.getInt("seq"));
				board.setTitle(    rs.getString("title"));
				board.setContents( rs.getString("contents"));
				board.setReadCnt(  rs.getInt("read_cnt"));
				board.setDiv(      rs.getString("div"));
				board.setRegId(    rs.getString("reg_id"));
				board.setRegDt(    rs.getString("reg_dt"));
				board.setModId(    rs.getString("mod_id"));
				board.setModDt(    rs.getString("mod_dt"));
				
			}
			
			LOG.debug("3.2  board	:" + board);
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		
		return board;
	}
	
	
	/**
	 * 게시글 삭제
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	@Override
	public int doDelete(DTO param) {
		int flag = 0;
		BoardVO inVO = (BoardVO) param;
		
		LOG.debug("doDelete()");
		LOG.debug("0.param:" + inVO);
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			connection = ConnectionMaker.getConnection();
			// Transaction user가 제어.
			connection.setAutoCommit(false);
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(50);
			sb.append(" DELETE FROM board  \n");
			sb.append(" WHERE seq = ?      \n");
			pstmt = connection.prepareStatement(sb.toString());

			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + pstmt);

			// param set
			pstmt.setInt(1, inVO.getSeq());
			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				LOG.debug("SQLException:" + e1.getMessage());
				e1.printStackTrace();
			}
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
		}

		return flag;
	}
	
	
	public int getSeq() {

//SELECT BOARD_SEQ.NEXTVAL SEQ
//FROM DUAL;
		int seq =0;
		
		LOG.debug("getSeq()");
		Connection connection   = null;
		PreparedStatement  pstmt = null;
		//Return Value 처리
		ResultSet  rs= null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT BOARD_SEQ.NEXTVAL SEQ                           \n"); 
			sb.append(" FROM DUAL                                             \n");
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			
			if(rs.next()==true) {
				seq =      rs.getInt("seq");
			}
			
			LOG.debug("3.2  seq	:" + seq);
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
			
		
		return seq;
	}
	
	/**
	 * 게시글 등록
	 * @param param
	 * @return 성공:1, 실패:0
	 */
	@Override
	public int doInsert(DTO param) {
		int flag = 0;
		BoardVO inVO = (BoardVO) param;
		LOG.debug("0.param:" + inVO);
		// -------------------------
		Connection connection = null;
		PreparedStatement pstmt = null;
		

		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);

			sb.append(" INSERT INTO BOARD ( \n");
			sb.append(" 	seq,            \n");
			sb.append(" 	title,          \n");
			sb.append(" 	contents,       \n");
			sb.append(" 	div,            \n");
			sb.append(" 	reg_id,         \n");
			sb.append(" 	mod_id          \n");
			sb.append(" )VALUES (           \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?,              \n");
			sb.append(" 	?               \n");
			sb.append(" )                   \n");
			// Statement
			// PreparedStatement : binding sql Statement보다 sql수행 속도가 우수.
			pstmt = connection.prepareStatement(sb.toString());
			// --doInsert():div 10(공지사항), 20(자유게시판)
			// --102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
			// param set
			pstmt.setInt(1,    inVO.getSeq());// NUMBER
			pstmt.setString(2, inVO.getTitle()); // VARCHAR2
			pstmt.setString(3, inVO.getContents()); // VARCHAR2
			pstmt.setString(4, inVO.getDiv()); // VARCHAR2
			pstmt.setString(5, inVO.getRegId()); // VARCHAR2
			pstmt.setString(6, inVO.getModId()); // VARCHAR2
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + connection);

			// 4. 쿼리실행:
			/*
			 * Executes the SQL statement in this PreparedStatement object, which must be an
			 * SQL Data Manipulation Language (DML) statement, such as INSERT, UPDATE or
			 * DELETE
			 */
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}
		// -------------------------

		return flag;
	}


}
