package com.sist.eclass.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.board.servie.BoardService;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.cmn.StringUtil;
import com.sist.eclass.cmn.search.domain.SearchVO;

/**
 * Servlet implementation class BoardController
 */
@WebServlet(description = "게시판", urlPatterns = { "/board/board.do" })
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    final Logger LOG = Logger.getLogger(BoardController.class);   
    
    BoardService  boardService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardController() {
        super();
        boardService = new BoardService();
        
        
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//request에 들어오는 encoding 일괄로 UTF-8
		request.setCharacterEncoding("UTF-8");
		String workDiv = StringUtil.nvl(request.getParameter("word_div"),"doRetrieve");
		LOG.debug("------------------------");
		LOG.debug("-workDiv-"+workDiv);
		LOG.debug("------------------------");
		
		switch(workDiv) {
			case "doRetrieve"://조회
				doRetrieve(request,response);	
				break;
				
			case "doInsert"://등록
				doInsert(request,response);	
				break;
				
			case "moveToReg"://목록으로 이동
				moveToReg(request,response);	
				break;
				
			case "doSelectOne"://단건조회
				doSelectOne(request,response);	
				break;	
				
			case "doDelete"://단건조회
				doDel(request,response);	
				break;		
				
			case "doUpdate"://수정
				doUpdate(request,response);	
				break;					
		}
		  
		
	}
	
	public void doUpdate(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doUpdate");	
		
		String seq   = StringUtil.nvl(request.getParameter("seq"),"-1");
		String title = StringUtil.nvl(request.getParameter("title"), "");
		String div   = StringUtil.nvl(request.getParameter("div"), "10");
		String regId = StringUtil.nvl(request.getParameter("reg_id"), "");
		String contents  = StringUtil.nvl(request.getParameter("contents"), "");
		
		BoardVO  param=new BoardVO();
		param.setSeq(Integer.parseInt(seq));
		param.setTitle(title);
		param.setDiv(div);
		param.setModId(regId);
		param.setContents(contents);
		
		LOG.debug("-param:"+param);
		LOG.debug("------------------------");			
		
		int flag = this.boardService.doUpdate(param);
		
		//메시지
		MessageVO  msgVO=new MessageVO();
		msgVO.setMsgId(String.valueOf(flag));
		
		String msg = "";
		if(1==flag) {
			msg = "수정 성공";
		}else {
			msg = "수정 실패";
		}
		
		msgVO.setMsgContents(msg);
		
		//메시지 to json
		Gson  gson=new Gson();
		String jsonString = gson.toJson(msgVO);
		LOG.debug("-jsonString:"+jsonString);
		
		//화면에 message전달
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);
	}
	
	/**
	 * 삭제
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doDel(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doDel");
		LOG.debug("------------------------");	
		//1.param read
		String seq = StringUtil.nvl(request.getParameter("seq"),"-1");
		
		LOG.debug("-seq:"+seq);		
		//2.
		BoardVO  param=new BoardVO();
		param.setSeq(Integer.parseInt(seq));
		
		LOG.debug("-param:"+param);
		LOG.debug("------------------------");	
		
		int flag =this.boardService.doDelete(param);
		LOG.debug("-flag:"+flag);
		
		MessageVO msgVO=new MessageVO();
		msgVO.setMsgId(String.valueOf(flag));
		
		String msg = "";
		if(1==flag) {
			msg = "삭제 성공";
		}else {
			msg = "삭제 실패";
		}
		msgVO.setMsgContents(msg);
		
		Gson gson=new Gson();
		String jsonString = gson.toJson(msgVO);
		LOG.debug("-jsonString-"+jsonString);
		
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);
	}
	
	
	/**
	 * 단건조회
	 * seq
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void doSelectOne(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-doSelectOne");
		LOG.debug("------------------------");
		
		String seq = StringUtil.nvl(request.getParameter("seq"),"-1");
		BoardVO param=new BoardVO();
		param.setSeq(Integer.parseInt(seq));
		
		LOG.debug("-seq:"+seq);
		LOG.debug("--param-"+param);		
		
		
		BoardVO outVO = this.boardService.doSelectOne(param);
		LOG.debug("--outVO-"+outVO);
		
		//화면에 데이터 전달!
		request.setAttribute("vo", outVO);
		
		RequestDispatcher dispacher = request.getRequestDispatcher("/board/board_mng.jsp");
		dispacher.forward(request, response);
	}
	
	
	/**
	 * 화면 board_list.jsp 등록화면으로 이동
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void moveToReg(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-moveToReg");
		LOG.debug("------------------------");		
		String div   = StringUtil.nvl(request.getParameter("div"),"10");
		LOG.debug("-div-"+div);
		
		
		//화면으로 데이터 전달
		request.setAttribute("div", div);
				
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/board/board_reg.jsp");
		dispatcher.forward(request, response);		
	}
	
	
	public void doInsert(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		LOG.debug("------------------------");
		LOG.debug("-searchDiv-doInsert");
		LOG.debug("------------------------");
		
		String title = StringUtil.nvl(request.getParameter("title"),"");
		String div   = StringUtil.nvl(request.getParameter("div"),"10");
		String regId = StringUtil.nvl(request.getParameter("reg_id"),"");
		String contents = StringUtil.nvl(request.getParameter("contents"),"");
		LOG.debug("------------------------");
		LOG.debug("-title-"+title);
		LOG.debug("-div-"+div);
		LOG.debug("-regId-"+regId);
		LOG.debug("-contents-"+contents);
		LOG.debug("------------------------");		
		
		//VO set
		BoardVO  param =new BoardVO();
		param.setTitle(title);
		param.setDiv(div);
		param.setRegId(regId);
		param.setModId(regId);
		param.setContents(contents);
		
		LOG.debug("-param-"+param);
		LOG.debug("------------------------");	
		
		int flag = boardService.doInsert(param);
		LOG.debug("-flag-"+flag);
		
		
		MessageVO  msgVO=new MessageVO();
		msgVO.setMsgId(String.valueOf(flag));
		
		String msg = "";
		if(1==flag) {
			msg ="등록 성공";
		}else {
			msg ="등록 실패";
		}
		msgVO.setMsgContents(msg);
		
		//VO to JSON
		Gson gson=new Gson();
		String jsonString = gson.toJson(msgVO);
		LOG.debug("-jsonString-"+jsonString);
		
			
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out= response.getWriter();
		out.print(jsonString);
		
		
	}
	
	
	public void doRetrieve(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		//param -> DTO
		String searchDiv  =StringUtil.nvl(request.getParameter("search_div"),"");
		String searchWord =StringUtil.nvl(request.getParameter("search_word"),"");
		String pageSize   =StringUtil.nvl(request.getParameter("page_size"),"10");
		String div        =StringUtil.nvl(request.getParameter("div"),"10");
		String pageNum    =StringUtil.nvl(request.getParameter("page_num"),"1");
		LOG.debug("------------------------");
		LOG.debug("-searchDiv-"+searchDiv);
		LOG.debug("-searchWord-"+searchWord);
		LOG.debug("-pageSize-"+pageSize);
		LOG.debug("-div-"+div);
		LOG.debug("------------------------");		
		//service에 DTO전달
		SearchVO   param=new SearchVO();
		param.setSearchDiv(searchDiv);
		param.setSearchWord(searchWord);
		
		int pageSizeNum = Integer.parseInt(pageSize);
		param.setPageSize(pageSizeNum);
		param.setDiv(div);
		param.setPageNum(Integer.parseInt(pageNum));
		
		
		LOG.debug("-param-"+param);
		//List<DTO> return
		List<BoardVO> list =boardService.doRetrieve(param);
		LOG.debug("-list.size-"+list.size());
		//해당화면에 DATA 전달!
		
		
		LOG.debug("-list-"+list);
		
		//화면으로 데이터 전달
		request.setAttribute("list", list);
		
		//화면으로 param 전달
		request.setAttribute("param", param);
		
		
		request.setAttribute("searchVO", param);
		//총글수
		int totalCnt = 0;
		if(null !=list && list.size()>0) {
			BoardVO totalVO = list.get(0);
			totalCnt = totalVO.getTotalCnt();
		}
		//화면으로 총글수 전달
		request.setAttribute("total_cnt", totalCnt);		
		
		RequestDispatcher  dispatcher= request.getRequestDispatcher("/board/board_list.jsp");
		dispatcher.forward(request, response);
		
		
	}
	
	
	
	
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
