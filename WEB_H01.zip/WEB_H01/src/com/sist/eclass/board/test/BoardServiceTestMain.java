/**
* <pre>
* com.sist.eclass.board.test
* Class Name : BoardServiceTestMain.java
* Description:
* Author: sist
* Since: 2021/02/25
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/02/25 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.board.test;

import org.apache.log4j.Logger;

import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.board.servie.BoardService;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.StringUtil;

/**
 * @author sist
 *
 */
public class BoardServiceTestMain {

	private static final Logger LOG = Logger.getLogger(BoardServiceTestMain.class);
	private BoardService service;
	private BoardVO  board01;
	
	
	public BoardServiceTestMain() {
		service = new BoardService();
		board01 =new BoardVO(22,   "title_2",   "contents_2",   0, "10", "강사", "", "eclass_2", "");
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BoardServiceTestMain testMain=new BoardServiceTestMain();
		//testMain.doSelectOne();
		testMain.pageNation();

	}
	
	public void pageNation() {
		String html = StringUtil.renderPaging(21, 1, 10, 10, "url", "scriptName");
		LOG.debug("\n"+html);
	}
	
	
	public void doSelectOne() {
		LOG.debug("===========================");
		LOG.debug("=doSelectOne=");
		LOG.debug("===========================");
		
		BoardVO outVO = service.doSelectOne(board01);
		LOG.debug(outVO.toString());
	}
	
	
	
	
	
	
	

}
