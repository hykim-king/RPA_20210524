package com.sist.eclass.board.test;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.dao.BoardDao;
import com.sist.eclass.board.domain.BoardVO;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.JDBCUtil;
import com.sist.eclass.cmn.WorkStandard;
import com.sist.eclass.cmn.search.domain.SearchVO;

public class BoardJdbcTestMain {
//	JavaCode에서 DB연결														
//	1. JDBC 드라이버 로딩														
//	2. 데이터베이스 커넥션 구함														
//	3. 쿼리 실행 PreparedStatement														
//	4. 쿼리실행														
//	5. 쿼리 실행 결과 처리(select결과가 있으면 결과 처리,int)														
//	6. ResultSet ,PreparedStatement 자원반납														
//	7. 커넥션 자원반납	

	

	final static Logger LOG = Logger.getLogger(BoardJdbcTestMain.class);

	private BoardVO  board01;
	private BoardVO  board02;
	private BoardVO  board03;
	
	//검색
	private SearchVO search01;
	
	private BoardDao boardDao;
//	--2   ,title_2   ,contents_2   ,'eclass_2','eclass_2'
//	--102 ,title_102 ,contents_102 ,'eclass_102','eclass_102'
//	--202	
	public BoardJdbcTestMain() {
		board01 =new BoardVO(2,   "title_2",   "contents_2",   0, "10", "강사", "", "eclass_2", "");
		board02 =new BoardVO(102, "title_102", "contents_102", 0, "10", "강사", "", "eclass_2", "");
		board03 =new BoardVO(202, "title_202", "contents_202", 0, "10", "강사", "", "eclass_2", "");
		
		search01=new SearchVO("", "", 10, 1,"10");
		
		
		boardDao =new BoardDao();
	}
	
	public static void main(String[] args) {

		BoardJdbcTestMain jtMain = new BoardJdbcTestMain();
		//jtMain.doDelete();
		jtMain.doInsert();
		//jtMain.doSelectOne();
		//jtMain.doUpdate();
		jtMain.doRetrieve();
		//jtMain.doReadCnt();
		
	}// --main

	public void doReadCnt(){
		boardDao.doSelectOne(board01);
		int flag = boardDao.doReadCnt(board01);
		LOG.debug("flag:"+flag);
	}
	
	public void doRetrieve(){
		
		List<BoardVO> resultList  =(List<BoardVO>) boardDao.doRetrieve(search01);
		LOG.debug("doRetrieve() 건수:"+resultList.size());
		
	}
	
	
	public void doUpdate() {
		int flag = 0;
		//--------------------------
		//public BoardVO(int seq, String title, String contents, int readCnt, String div, String regId, String regDt,
		//String modId, String modDt) {
		BoardVO  upData =new  BoardVO();
		upData.setSeq(board01.getSeq());
		
		upData.setTitle(board01.getTitle()+"_U");
		upData.setContents(board01.getContents()+"_U");
		upData.setModId(board01.getModId()+"_U");
		
		flag = boardDao.doUpdate(upData);
		if(1==flag) {
			LOG.debug("★★★★★★★★★★★★★★★★★★");
			LOG.debug("★수정 성공                   ★");
			LOG.debug("★★★★★★★★★★★★★★★★★★");			
		}else {
			LOG.debug("----------------------");
			LOG.debug("| 수정 실패                        |");
			LOG.debug("----------------------");			
		}
		//--------------------------
	}
	
	
	public void doSelectOne() {
		BoardVO board=null;
		board = (BoardVO) boardDao.doSelectOne(board01);
		
		if(   board.getSeq() != board01.getSeq()
		  || !board.getTitle().equals(board01.getTitle())
		  || !board.getContents().equals(board01.getContents())
				) {
			LOG.debug("----------------------");
			LOG.debug("| 실패                              |");
			LOG.debug("----------------------");			
		}else {
			LOG.debug("★★★★★★★★★★★★★★★★★★");
			LOG.debug("★단건조회 성공                   ★");
			LOG.debug("★★★★★★★★★★★★★★★★★★");				
		}
		
	}
	
	
	public void doDelete() {
		int flag = 0;
		flag = boardDao.doDelete(board01);
		// -------------------------
		if(1==flag) {
			LOG.debug("★★★★★★★★★★★★★★★★★★");
			LOG.debug("★삭제 성공                         ★");
			LOG.debug("★★★★★★★★★★★★★★★★★★");		
		}else {
			LOG.debug("----------------------");
			LOG.debug("|삭제 실패                         |");
			LOG.debug("----------------------");
		}
		// -------------------------		
	}

	public void doInsert() {
		int flag = 0;
		flag = boardDao.doInsert(board01);
		// -------------------------
		if(1==flag) {
			LOG.debug("★★★★★★★★★★★★★★★★★★");
			LOG.debug("★등록 성공                         ★");
			LOG.debug("★★★★★★★★★★★★★★★★★★");		
		}else {
			LOG.debug("----------------------");
			LOG.debug("|등록 실패                         |");
			LOG.debug("----------------------");
		}
		// -------------------------

		
	}



}// --class
