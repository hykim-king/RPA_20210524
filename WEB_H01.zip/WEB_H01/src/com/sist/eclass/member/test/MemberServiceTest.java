/**
* <pre>
* com.sist.eclass.member.test
* Class Name : MemberServiceTest.java
* Description:
* Author: sist
* Since: 2021/03/12
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/12 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.member.test;

import org.apache.log4j.Logger;

import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.MessageVO;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.service.MemberService;

/**
 * @author sist
 *
 */
public class MemberServiceTest {
final static Logger LOG = Logger.getLogger(MemberServiceTest.class);
	
	private MemberVO member01;
	private MemberVO member02;
	private MemberService service;
	
	public MemberServiceTest() {
		member01 = new MemberVO("J_124", "이상무", "1234_U", "jamesol@paran.com", "M", "01012345678", "9"
				, "Admin", "", "Admin", "");
		member02 = new MemberVO();
		
		service = new MemberService();
	}
	
	public void doLoginCheck() {
		LOG.debug("======================");
		LOG.debug("=doLoginCheck()=");
		LOG.debug("======================");
		
		//id가 없는 경우
//		member02.setMemberId("없는ID");
//		MessageVO message = service.doLoginCheck(member02);
//		if(message.getMsgId().equals("10")) {
//			LOG.debug(message.getMsgId()+","+message.getMsgContents());
//		}

		//id가 있고, 비번이 다른 경우
		//member01.setMemberId("J_124");
//		member01.setPasswd("비번 없음");
//		MessageVO message = service.doLoginCheck(member01);
//		if(message.getMsgId().equals("20")) {
//			LOG.debug(message.getMsgId()+","+message.getMsgContents());
//		}		
		
		
		MessageVO message = service.doLoginCheck(member01);
		if(message.getMsgId().equals("0")) {
			LOG.debug(message.getMsgId()+","+message.getMsgContents());
			
			MemberVO  loginMember = (MemberVO) service.doSelectOne(member01);
			if(loginMember.getMemberId().equals(member01.getMemberId())
			  && loginMember.getPasswd().equals(member01.getPasswd())		
					) {
				LOG.debug("*************************");
				LOG.debug("로그인 사용자:"+loginMember);
				LOG.debug("*************************");
			}
			
			
		}			
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MemberServiceTest serviceMain=new MemberServiceTest();
		serviceMain.doLoginCheck();
	}

}







