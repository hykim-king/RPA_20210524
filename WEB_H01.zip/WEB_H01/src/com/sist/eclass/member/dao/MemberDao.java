/**
* <pre>
* com.sist.eclass.member.dao
* Class Name : MemberDao.java
* Description:
* Author: sist
* Since: 2021/03/11
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/03/11 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.sist.eclass.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sist.eclass.board.dao.BoardDao;
import com.sist.eclass.cmn.ConnectionMaker;
import com.sist.eclass.cmn.DTO;
import com.sist.eclass.cmn.JDBCUtil;
import com.sist.eclass.cmn.WorkStandard;
import com.sist.eclass.cmn.search.domain.SearchVO;
import com.sist.eclass.member.domain.MemberVO;
import com.sist.eclass.member.domain.SexsualVO;

/**
 * @author sist
 *
 */
public class MemberDao implements WorkStandard {
	final Logger LOG = Logger.getLogger(MemberDao.class);
	
	
	public MemberDao() {
		
	}
	/**
	 * 남여비율
	 * @return
	 */
	public List<SexsualVO> sexsualRatio(){
		List<SexsualVO> list =new ArrayList<SexsualVO>();
		Connection  connection = null;
		PreparedStatement  pstmt = null;
		ResultSet  rs = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT '남' SEX,SUM(DECODE(t1.sex,'M',1,0)) CNT  \n");
			sb.append(" FROM member t1                                  \n");
			sb.append(" UNION                                           \n");
			sb.append(" SELECT '여' SEX,SUM(DECODE(t1.sex,'F',1,0)) CNT  \n");
			sb.append(" FROM member t1                                  \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			
			while(rs.next()) {
				SexsualVO  vo=new SexsualVO();
				vo.setSex(rs.getString("SEX"));
				vo.setCnt(rs.getInt("CNT"));
				list.add(vo);
			}
			
			for(SexsualVO voData   :list) {
				LOG.debug(voData);
			}
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		
		return list;
	}
	
	
	/**
	 * 사용자 ID 유무 확인
	 * @param param
	 * @return 1/0
	 */
	public int idCheck(DTO param) {
		MemberVO  inVO = (MemberVO) param;
		LOG.debug("idCheck()");
		LOG.debug("1.param:"+inVO);
		Connection  connection = null;
		PreparedStatement  pstmt = null;
		ResultSet  rs = null;
		int flag = 0;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT COUNT(*) cnt  \n");
			sb.append(" FROM  member         \n");
			sb.append(" WHERE member_id = ?  \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setString(1, inVO.getMemberId());
			
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			if(rs.next()==true) {
				flag = rs.getInt("cnt");
			}
			LOG.debug("3.2  flag	:" + flag);
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		
		return flag;
	}
	
	/**
	 * 사용자 ID/비번 체크  유무 확인
	 * @param param
	 * @return 1/0
	 */
	public int passwordCheck(DTO param) {
		MemberVO  inVO = (MemberVO) param;
		LOG.debug("idCheck()");
		LOG.debug("1.param:"+inVO);
		Connection  connection = null;
		PreparedStatement  pstmt = null;
		ResultSet  rs = null;
		int flag = 0;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT COUNT(*) cnt  \n");
			sb.append(" FROM  member         \n");
			sb.append(" WHERE member_id = ?  \n");
			sb.append(" AND   passwd    = ?  \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setString(1, inVO.getMemberId());
			pstmt.setString(2, inVO.getPasswd());
			
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			if(rs.next()==true) {
				flag = rs.getInt("cnt");
			}
			LOG.debug("3.2  flag	:" + flag);
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		
		return flag;
	}
	
	
	
	
	
	@Override
	public List<?> doRetrieve(DTO param) {
		List<MemberVO> list=new ArrayList<MemberVO>();
		SearchVO  inVO = (SearchVO) param;
		LOG.debug("0.param:" + inVO);
		Connection connection    = null;
		PreparedStatement  pstmt = null;
		ResultSet          rs    = null;
		
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);// 조건 처리
			StringBuffer sbWhere=new StringBuffer(500);//동적 검색 조건 처리
			//--name(10),member_id(20),email(30),cell_phone(40)
			if(null !=inVO && inVO.getSearchDiv() !="") {
				if(inVO.getSearchDiv().equals("10")) {
					sbWhere.append(" AND  name LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("20")) {
					sbWhere.append(" AND  member_id LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("30")) {
					sbWhere.append(" AND  email LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("40")) {
					sbWhere.append(" AND  cell_phone LIKE  ? ||'%' \n");
				}
			}
			//main query
			StringBuffer sb=new StringBuffer(2000);
			sb.append(" SELECT TT1.RNUM num,                                                                                                 \n");
			sb.append("        TT1.member_id,                                                                                                \n");
			sb.append("        TT1.name,                                                                                                     \n");
			sb.append("        TT1.passwd,                                                                                                   \n");
			sb.append("        TT1.email,                                                                                                    \n");
			sb.append("        TT1.sex,                                                                                                      \n");
			//함수--------------------
			sb.append("        get_code_nm('SEX', TT1.sex) sex_nm, \n");
			//함수--------------------			
//			sb.append("        (SELECT det_nm                                                                                                \n");
//			sb.append("        FROM com_code                                                                                                 \n");
//			sb.append("        WHERE mst_id ='SEX'                                                                                           \n");
//			sb.append("        AND use_yn = '1'                                                                                              \n");
//			sb.append("        AND det_id= TT1.sex) sex_nm,                                                                                  \n");
			
			        
			sb.append("        TT1.cell_phone,                                                                                               \n");
			//함수--------------------
			sb.append("        get_code_nm('AUTH',TT1.auth) auth, \n");
			//함수--------------------			
			   
//			sb.append("        (SELECT det_nm                                                                                                \n");
//			sb.append("        FROM com_code                                                                                                 \n");
//			sb.append("        WHERE mst_id ='AUTH'                                                                                          \n");
//			sb.append("        AND use_yn = '1'                                                                                              \n");
//			sb.append("        AND det_id= TT1.auth) auth,                                                                                   \n");
			sb.append("        TT1.mod_id,                                                                                                   \n");
			sb.append("        CASE WHEN TO_CHAR(SYSDATE,'YYYY/MM/DD')=TO_CHAR(TT1.mod_dt,'YYYY/MM/DD')  THEN TO_CHAR(TT1.mod_dt,'HH24:MI')  \n");
			sb.append("           ELSE TO_CHAR(TT1.mod_dt,'YYYY/MM/DD')                                                                      \n");
			sb.append("        END mod_dt                                                                                                    \n");
			sb.append(" FROM (                                                                                                               \n");
			sb.append("     SELECT rownum rnum,T1.*                                                                                          \n");
			sb.append("     FROM (                                                                                                           \n");
			sb.append("         SELECT *                                                                                                     \n");
			sb.append("         FROM member                                                                                                  \n");
			sb.append("         WHERE member_id >'0'                                                                                         \n");
			//-----------------------------------------------------------------------------------------------------------------------------------
			//where
			//-----------------------------------------------------------------------------------------------------------------------------------
			
			//**************************
			sb.append(sbWhere.toString());
			//**************************
			
			sb.append("         ORDER BY MOD_DT DESC                                                                                         \n");
			sb.append("     )T1                                                                                                              \n");
			sb.append(" )TT1                                                                                                                 \n");
			sb.append(" WHERE rnum BETWEEN ? * ( ? - 1)+1 AND ? * ( ? - 1) + ?                                                                         \n");
			//sb.append(" --WHERE rnum BETWEEN :PAGE_SIZE*(:PAGE_NUM-1)+1 AND :PAGE_SIZE*(:PAGE_NUM-1)+:PAGE_SIZE                              \n");			
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			LOG.debug("3.0  SQL	:\n" + sb.toString());
			
			  
			
			int i=0;
			//검색조건이 있는 경우
			LOG.debug("3.1  inVO	:" + inVO);
			if(null !=inVO && !inVO.getSearchDiv().equals("")) {
				pstmt.setString(++i, inVO.getSearchWord());
				pstmt.setInt(++i, inVO.getPageSize());
				pstmt.setInt(++i, inVO.getPageNum());
				pstmt.setInt(++i, inVO.getPageSize());
				pstmt.setInt(++i, inVO.getPageNum());		
				pstmt.setInt(++i, inVO.getPageSize());					
			}else {
				
				
				pstmt.setInt(++i, inVO.getPageSize());
				pstmt.setInt(++i, inVO.getPageNum());
				pstmt.setInt(++i, inVO.getPageSize());
				pstmt.setInt(++i, inVO.getPageNum());		
				pstmt.setInt(++i, inVO.getPageSize());				
			}
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			while(rs.next() == true) {
				MemberVO member=new MemberVO();
				member.setNum(rs.getInt("num"));
				member.setMemberId(rs.getString("member_id"));
				member.setName(rs.getString("name"));
				member.setPasswd(rs.getString("passwd"));
				member.setEmail(rs.getString("email"));
				member.setSex(rs.getString("sex_nm"));
				member.setCellPhone(rs.getString("cell_phone"));
				member.setAuth(rs.getString("auth"));
				member.setModId(rs.getString("mod_id"));
				member.setModDt(rs.getString("mod_dt"));
				
				list.add(member);
			}
			
			for(MemberVO vo :list) {
				LOG.debug(vo);
			}
			LOG.debug("조회 데이터 사이즈:"+list.size());
			
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();				
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
		}		
		
		return list;
	}

	/**
	 * 총건수 조회
	 * @param param
	 * @return
	 */
	public DTO doTotalCnt(DTO param) {
		MemberVO   outVO= null;
		SearchVO  inVO = (SearchVO) param;
		
		LOG.debug("1.param:"+inVO);
		
		Connection  connection = null;
		PreparedStatement  pstmt = null;
		ResultSet  rs = null;
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);		
			StringBuffer sbWhere=new StringBuffer(500);//동적 검색 조건 처리
			//--name(10),id(20),email(30),cell_phone(40)
			if(null !=inVO && inVO.getSearchDiv() !="") {
				if(inVO.getSearchDiv().equals("10")) {
					sbWhere.append(" WHERE  name LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("20")) {
					sbWhere.append(" WHERE  member_id LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("30")) {
					sbWhere.append(" WHERE  email LIKE  ? ||'%' \n");
				}else if(inVO.getSearchDiv().equals("40")) {
					sbWhere.append(" WHERE  cell_phone LIKE  ? ||'%' \n");
				}
			}
			
			StringBuffer sb=new StringBuffer(2000);//MAIN QUERY
			sb.append(" SELECT COUNT(*) total_cnt \n");
			sb.append(" FROM member               \n");
			//sb.append(" WHERE 1 = 1               \n");
			//-------------------------------------------------------------------------------------------------------------------------------
			//WHERE조건 
			//-------------------------------------------------------------------------------------------------------------------------------
			sb.append(	sbWhere.toString() );		
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			
			//param set
			if(null !=inVO && inVO.getSearchDiv() !="") {
				pstmt.setString(1, inVO.getSearchWord());
			}
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			if(rs.next()) {
				outVO = new MemberVO();
				outVO.setTotalCnt(rs.getInt("total_cnt"));
			}
			
			LOG.debug("outVO:"+outVO);
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		return outVO;
	}
	
	
	@Override
	public int doUpdate(DTO param) {
		int flag  = 0 ;
		MemberVO inVO = (MemberVO) param;
		LOG.debug("0.param:" + inVO);
		Connection connection = null;
		PreparedStatement  pstmt = null;
		
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb=new StringBuffer(500);
			sb.append(" UPDATE member               \n");
			sb.append(" SET name        = ?         \n");
			sb.append("     ,passwd     = ?         \n");
			sb.append("     ,email      = ?         \n");
			sb.append("     ,sex        = ?         \n");
			sb.append("     ,cell_phone = ?         \n");
			sb.append("     ,auth       = ?         \n");
			sb.append("     ,mod_id     = ?         \n");
			sb.append("     ,mod_dt     = SYSDATE   \n");
			sb.append(" WHERE                       \n");
			sb.append("     member_id = ?           \n");
//			3. 쿼리 실행 PreparedStatement			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());

			int i=0;
			//param set
			pstmt.setString(++i, inVO.getName());
			pstmt.setString(++i, inVO.getPasswd());
			pstmt.setString(++i, inVO.getEmail());
			pstmt.setString(++i, inVO.getSex());
			pstmt.setString(++i, inVO.getCellPhone());
			pstmt.setString(++i, inVO.getAuth());
			pstmt.setString(++i, inVO.getModId());
			pstmt.setString(++i, inVO.getMemberId());
			
			flag =pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);			
			
		}		
			
			
		return flag;
	}

	@Override
	public DTO doSelectOne(DTO param) {
		MemberVO  outVO  = null;
		MemberVO  inVO = (MemberVO) param;
		LOG.debug("doSelectOne()");
		LOG.debug("1.param:"+inVO);
		Connection  connection = null;
		PreparedStatement  pstmt = null;
		ResultSet  rs = null;

		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
			StringBuffer sb = new StringBuffer(500);
			sb.append(" SELECT                                               \n");
			sb.append("     member_id,                                       \n");
			sb.append("     name,                                            \n");
			sb.append("     passwd,                                          \n");
			sb.append("     email,                                           \n");
			sb.append("     sex,                                             \n");
			sb.append("     cell_phone,                                      \n");
			sb.append("     auth,                                            \n");
			sb.append("     reg_id,                                          \n");
			sb.append("     TO_CHAR(reg_dt,'yyyy/mm/dd hh24:mi:ss') reg_dt,  \n"); 
			sb.append("     mod_id,                                          \n");
			sb.append("     TO_CHAR(mod_dt,'yyyy/mm/dd hh24:mi:ss') mod_dt   \n");
			sb.append(" FROM  member                                         \n");
			sb.append(" WHERE member_id = ?                                  \n");
			
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			pstmt = connection.prepareStatement(sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			pstmt.setString(1, inVO.getMemberId());
			
			
			rs = pstmt.executeQuery();
			LOG.debug("3.1  ResultSet	:" + rs);
			if(rs.next()==true) {
				outVO =new MemberVO();
				outVO.setMemberId(rs.getString("member_id"));
				outVO.setName(rs.getString("name"));
				outVO.setPasswd(rs.getString("passwd"));
				outVO.setEmail(rs.getString("email"));
				outVO.setSex(rs.getNString("sex"));
				outVO.setCellPhone(rs.getString("cell_phone"));
				outVO.setAuth(rs.getString("auth"));
				outVO.setRegId(rs.getString("reg_id"));
				outVO.setRegDt(rs.getString("reg_dt"));
				outVO.setModId(rs.getString("mod_id"));
				outVO.setModDt(rs.getString("mod_dt"));
				
			}
			LOG.debug("3.2  outVO	:" + outVO);
			
		}catch(SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();			
		}finally {
			
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
			
		}
		
		return outVO;
	}

	@Override
	public int doDelete(DTO param) {
		int flag = 0;
		MemberVO inVO=(MemberVO) param;
		LOG.debug("doDelete()");
		LOG.debug("0.param:" + inVO);
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {		
			connection = ConnectionMaker.getConnection();
			StringBuffer sb = new StringBuffer(50);
			sb.append(" DELETE FROM member    \n");
			sb.append(" WHERE  member_id = ?  \n");			
			pstmt = connection.prepareStatement(sb.toString());
		
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3. 쿼리 실행 PreparedStatement	:" + pstmt);
			// param set
			pstmt.setString(1, inVO.getMemberId());
			// 4. 쿼리실행:
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);
		}
		
		return flag;
	}

	@Override
	public int doInsert(DTO param) {
		int flag = 0;
		MemberVO inVO=(MemberVO) param;
		LOG.debug("0.param:" + inVO);
		Connection connection = null;
		PreparedStatement pstmt = null;
		
		try {
			connection = ConnectionMaker.getConnection();
			LOG.debug("2.데이터베이스 커넥션 구함:" + connection);
//			3. 쿼리 실행 PreparedStatement	
			StringBuffer sb = new StringBuffer(1000);			
			sb.append(" INSERT INTO member (  \n");
			sb.append("     member_id,        \n");
			sb.append("     name,             \n");
			sb.append("     passwd,           \n");
			sb.append("     email,            \n");
			sb.append("     sex,              \n");
			sb.append("     cell_phone,       \n");
			sb.append("     auth,             \n");
			sb.append("     reg_id,           \n");
			sb.append("     reg_dt,           \n");
			sb.append("     mod_id,           \n");
			sb.append("     mod_dt            \n");
			sb.append(" ) VALUES (            \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     ?,                \n");
			sb.append("     SYSDATE,          \n");
			sb.append("     ?,                \n");
			sb.append("     SYSDATE           \n");
			sb.append(" )                     \n");			
			pstmt = connection.prepareStatement(sb.toString());
			int i=0;
			//param set
			pstmt.setString(++i, inVO.getMemberId());
			pstmt.setString(++i, inVO.getName());
			pstmt.setString(++i, inVO.getPasswd());
			pstmt.setString(++i, inVO.getEmail());
			pstmt.setString(++i, inVO.getSex());
			pstmt.setString(++i, inVO.getCellPhone());
			pstmt.setString(++i, inVO.getAuth());
			pstmt.setString(++i, inVO.getRegId());
			pstmt.setString(++i, inVO.getModId());
			LOG.debug("2.1. 쿼리 실행 PreparedStatement	:\n" + sb.toString());
			LOG.debug("3.  PreparedStatement	:" + pstmt);
			
			flag = pstmt.executeUpdate();
			LOG.debug("4. 쿼리실행	flag:" + flag);
		} catch (SQLException e) {
			LOG.debug("SQLException:" + e.getMessage());
			e.printStackTrace();
		} finally {
			// 6.PreparedStatement 자원반납
			// 7.Connection 반납
			JDBCUtil.close(pstmt);
			JDBCUtil.close(connection);

		}		
		return flag;
	}

}


































