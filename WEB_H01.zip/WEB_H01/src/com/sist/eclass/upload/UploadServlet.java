package com.sist.eclass.upload;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.sist.eclass.cmn.StringUtil;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet(description = "파일업로드", urlPatterns = { "/upload.do" })
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Logger LOG = Logger.getLogger(UploadServlet.class);
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("=======================");
		LOG.debug("=UploadServlet doPost=");
		LOG.debug("=======================");
		
		//파일저장 경로
		String savePath= "D:\\20201123_eClass\\02_Oracle\\workspace_web\\WEB_H01\\WebContent\\upload";
		
		//파일용량
		int maxSize  = 1024*1024*50;//50M
		String encType = "UTF-8";
		//동적으로 yyyy
		//       -mm
		
		//save path동적 생성
		//File  saveDir=new File(savePath);
		//if(saveDir.exists()==false)saveDir.mkdir();
		int isSaveDir = mkDir(savePath);
		
		//2021
		String year   = StringUtil.formatDate("yyyy");
		//savePath\\yyyy\\mm
		String savePathTemp = savePath+File.separator+year;
		LOG.debug("=savePath="+savePathTemp);
		int isYearDir = mkDir(savePathTemp);
		LOG.debug("=isYearDir="+isYearDir);
		
		//03
		String month   = StringUtil.formatDate("MM");
        String savePathTempMonth = savePathTemp+File.separator+month;
		LOG.debug("=savePathTempMonth="+savePathTempMonth);
		int isYearMonthDir = mkDir(savePathTempMonth);
		
		
		//"D:\\20201123_eClass\\02_Oracle\\workspace_web\\WEB_H01\\WebContent\\upload\\2021\\03";
		savePath= savePathTempMonth;
		
		MultipartRequest  multi=new MultipartRequest(request
				, savePath
				, maxSize
				, encType
				, new DefaultFileRenamePolicy());
		//File Read
		
		List<FileVO>  fileList=new ArrayList<>();
		String filePK = StringUtil.getPK("yyyyMMddHH24mmss");
		//20210315102440261b288923cab34732b49f540b99cda006
		LOG.debug("=filePK="+filePK);
		
		String title = multi.getParameter("title");
		LOG.debug("=title="+title);
		
		int fileSeq = 0;//file seq
		Enumeration<String>  files =multi.getFileNames();
		
		
		
		
		while(files.hasMoreElements()) {
			FileVO  fileVO=new FileVO();
			
			
			String file = files.nextElement();
			LOG.debug("=file="+file);//<input type="file"  class="form-control" name="file01" />
			
			//원본파일명
			String orgFileName = multi.getOriginalFileName(file);
			LOG.debug("=orgFileName="+orgFileName);
			//저장파일명
			String saveFileName =multi.getFilesystemName(file);
			LOG.debug("=saveFileName="+saveFileName);
			
			//if(null==saveFileName)return;
			//파일순번
			fileSeq++;
			
			//파일ID
			fileVO.setFileId(filePK);
			//파일순번
			fileVO.setSeq(fileSeq);
			//원본파일명
			fileVO.setOrgFileNm(orgFileName);
			//저장파일명
			fileVO.setSaveFileNm(saveFileName);
			//저장경로
			fileVO.setPath(savePath);
			//파일사이즈
			String fileFullPath = savePath+File.separator+saveFileName;
			File tmpFile = new File(fileFullPath);
			long size = tmpFile.length();
			fileVO.setSize(size);
			
			//확장자
			String ext = "";
			if(orgFileName.lastIndexOf(".")>0) {
				int dotIndex = orgFileName.lastIndexOf(".");
				ext = orgFileName.substring(dotIndex+1);
			}
			fileVO.setExt(ext);
			
			fileList.add(fileVO);
		}
		
		for(FileVO vo :fileList) {
			LOG.debug("vo:"+vo);
		}
		
		//데이터 전송
//		request.setAttribute("fileList", fileList);
//		
//		
//		RequestDispatcher  dispatcher= request.getRequestDispatcher("/e_jsp/j12upload/file_upload_result.jsp");
//		dispatcher.forward(request, response);

		
	   Gson gson=new Gson();
	   String gsonString = gson.toJson(fileList);
	   
	   LOG.debug("gsonString:"+gsonString);
		
	   response.setContentType("text/html; charset=UTF-8");
	   PrintWriter out= response.getWriter();
	   out.print(gsonString);
	}

	/**
	 * path에 해당하는 디렉토리 생성
	 * @param path
	 * @return
	 */
	public int mkDir(String path) {
		int flag = 0;
		
		File  saveDir=new File(path);
		if(saveDir.exists()==false) {
			boolean isMkdir = saveDir.mkdir();
			
			if(isMkdir==true)flag=1;
		}
		
		return flag ;
	}
	
	
}










