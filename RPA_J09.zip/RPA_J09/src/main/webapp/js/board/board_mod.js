/**
 * 
 */
 
 //화면이 loading되면 수행
 window.onload = function() {
     console.log("window.onload");
     
     //삭제버튼 
     let doDeleteBtn =document.getElementById("doDelete");
     
     //삭제버튼 이벤트 감지
     doDeleteBtn.onclick = function(){
        doDelete();
     }
     
     //수정버튼
     let doUpdateBtn = document.getElementById("doUpdate");
     //수정버튼 이벤트 감지
     
     doUpdateBtn.onclick = function(){
        doUpdate();
     }
     
     
     //textarea maxLength처리
/*     let constentsTxt = document.getElementById("constents");
     let constentsCntTxt = document.getElementById("constents_cnt");
     constentsTxt.onkeyup  = function(){
      
       // console.log("e:"+constentsTxt.value );
        let contLength = constentsTxt.value.length;
        //console.log("contLength:"+contLength );
        constentsCntTxt.innerHTML = "("+contLength+"/100)";
           
        if(contLength>100){
          constentsCntTxt.value =   constentsTxt.value.substring(0,100);
        }
     }*/    
 }     
 
 
 
 $("#constents").on('keyup',function(){
    let contLength = $(this).val().length;
    $("#constents_cnt").html("("+contLength+"/100)");
    
    if(contLength>100){
       $(this).val($(this).val().substring(0, 100));
       $('#constents_cnt').html("(100 / 100)");
    }
 });   
 //수정
 function  doUpdate(){
     console.log("doUpdate") ;
     let frm = document.boardFrm;
     
     let title = frm.title.value;
     let seq = frm.seq.value;
     let constents = frm.constents.value;
     
     console.log("title:"+title) ;
     console.log("seq:"+seq) ;
     console.log("constents:"+constents) ;
     
     if(null === title || title.length <=0){
        frm.title.focus();
        alert("제목을 입력 하세요.");
        
        return;
     }
     
     if(null === constents || constents.length <=0){
        frm.constents.focus();
        alert("내용을 입력 하세요.");
        
        return;
     }     

     const send_url = CP+"/board/board.do";     

     $.ajax({
        type: "POST",
        url:send_url,
        asyn:"true",
        dataType:"html",
        data:{
          work_div:"doUpdate",
          seq:   seq,
          title: title,
          constents: constents  
        },
        success:function(data){//통신 성공
            console.log("success data:"+data);
            
            let jsonObj = JSON.parse(data);
            if(null !=jsonObj && "1" == jsonObj.msgId){
              alert(jsonObj.msgContents);
              movToList();
            }
            
            
        },
        error:function(data){//실패시 처리
            console.log("error:"+data);
        },
        complete:function(data){//성공/실패와 관계없이 수행!
            console.log("complete:"+data);
        }
      });
             
 }
 
 
 //삭제
 function doDelete(){
    console.log("doDelete");

    
/*    var frm = document.boardFrm;
    
    //작업구분
    frm.work_div.value = "doDelete";
    console.log("frm.work_div.value:"+frm.work_div.value);
    //seq
    console.log("seq:"+frm.seq.value);
    frm.action = CP+"/board/board.do";
    frm.method = "get";  
    frm.submit();*/
    let seq = document.boardFrm.seq.value;
    console.log("seq:"+seq);
    
    //삭제 하시겠습니까?
    if( false == confirm("삭제 하시겠습니까?"))return;
        
    //server url
    const send_url = CP + "/board/board.do";
    
       $.ajax({
          type: "GET",
          url:send_url,
          asyn:"true",
          dataType:"html",
          data:{
            work_div:"doDelete",
            seq: seq 
          },
          success:function(data){//통신 성공
              console.log("success data:"+data);
              let jsonObj = JSON.parse(data);
              if(null != jsonObj && "1" == jsonObj.msgId){
                alert(jsonObj.msgContents);
                movToList();
              }
              
              
          },
          error:function(data){//실패시 처리
              console.log("error:"+data);
          },
          complete:function(data){//성공/실패와 관계없이 수행!
              console.log("complete:"+data);
          }
        });    
    
    }
    
    function movToList(){
         let listUrl = CP+"/board/board.do?work_div=doRetrieve&searchDiv=&searchWord=&pageSize=10";
         window.location.href = listUrl;
    }
    
    
    
    
    
    