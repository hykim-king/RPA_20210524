//화면이 로드된 이후 수행될 작업!
  $(document).ready(function(){
     console.log("ready");
  
  });

  function doSearchPage(url,currPage){
    alert(url+","+currPage);
  }
        
          

  $("#board>tbody").on("click","tr",function(event){
    //console.log("#board>tbody");
    
    console.log("this:"+$(this));
    
    let tdArray = $(this).children();
    console.log("tdArray.eq(1).text():"+tdArray.eq(1).text());
    let seq = tdArray.eq(5).text();
    
    let frm = document.searchFrm;
    frm.work_div.value = "doSelectOne";//작업구분
    frm.seq.value = seq;
    
    console.log("frm.work_div.value:"+frm.work_div.value);
    console.log("frm.seq.value:"+frm.seq.value);
    
    frm.method ="get";
    frm.action = CP+"/board/board.do";
    frm.submit();
    
    
  });
  
  //등록화면으로 이동!
  function moveToReg(){
    //alert("moveToReg");
    console.log("moveToReg");
    
    var frm = document.searchFrm;
    frm.work_div.value = "moveToReg";
    console.log("frm.work_div.value:"+frm.work_div.value);
    frm.action = CP+"/board/board.do";
    frm.method = "post";
    frm.submit();
    
  }
  
  function doRetrieve(){
    //alert("doRetrieve");  
    var frm = document.searchFrm;
    //검색 목록조회를 찾아 가도록 작업구분(doRetrieve) 
    frm.work_div.value = 'doRetrieve';
    frm.method = "get";
    frm.action = CP+"/board/board.do";  
  
    //alert("frm.work_div.value:"+frm.action);
    frm.submit();  
    
  }
  //검색 Enter Event처리 
  function searchEnter(){
     //alert('searchEnter');
     
     if(window.event.keyCode==13){
       console.log(window.event.keyCode);
       doRetrieve();
     }
  }

