
     $(document).ready(function(){
       console.log("ready");
       
     });
  
     //게시 목록으로 이동
     function moveToList(){
         let listUrl = CP+"/board/board.do?work_div=doRetrieve&searchDiv=&searchWord=&pageSize=10";
         window.location.href = listUrl; 
     }
  
     //게시글 등록
     function doInsert(){
       //alert('doInsert');
       console.log('doInsert');
       var frm = document.boardFrm;   
       
       //작업구분
       frm.work_div.value ="doInsert";
       
       //제목에 대한 null check
       var title= frm.title.value;
       if(null === title || title.length <= 0){
         frm.title.focus();
         alert("제목을 입력 하세요.");
         return;
       }
       
       //내용에 대한 null check
       var constents =  frm.constents.value;
       if(null === constents || constents.length <= 0){
         frm.constents.focus();
         alert("내용을 입력 하세요.");
         return;
       }
       console.log('title:'+title);
       console.log('CP:'+CP);
       console.log('constents:'+constents);
       
       //등록 하시겠습니까?
       if( false == confirm("등록 하시겠습니까?"))  return;  
                
       //비동기 통신: AJAX
       const send_url = CP +"/board/board.do";
       console.log("send_url:"+send_url);
       $.ajax({
          type: "POST",
          url:send_url,
          asyn:"true",
          dataType:"html",      
          data:{
            work_div:"doInsert",
            title: title,
            constents: constents  
          },
          success:function(data){//통신 성공
              //console.log("success data:"+data);
              //JSON.parse()
              //문자열을 JSON으로서 구문 분석하고, 선택적으로 분석 결과의 값과 속성을 변환해 반환합니다.
              //jsonString:{"msgId":"1","msgContents":"등록 성공!","msgDetail":"1:등록 성공!","num":0}
              let jsonObj = JSON.parse(data);
              //console.log("jsonObj.msgId:"+jsonObj.msgId);
              //console.log("jsonObj.msgContents:"+jsonObj.msgContents);
              
              if(null != jsonObj && "1" == jsonObj.msgId){
                  alert(jsonObj.msgContents);
                  moveToList();
              }else{
                alert(jsonObj.msgDetail);
                
              }
              
          },
          error:function(data){//실패시 처리
              console.log("error:"+data);
          },
          complete:function(data){//성공/실패와 관계없이 수행!
              console.log("complete:"+data);
          }
        });
       
       
     } 
     
     $("#constents").on('keyup',function(){
        let contLength = $(this).val().length;
        $("#constents_cnt").html("("+contLength+"/100)");
        
        if(contLength>100){
           $(this).val($(this).val().substring(0, 100));
           $('#constents_cnt').html("(100 / 100)");
        }
     });
     
     
     
     
     