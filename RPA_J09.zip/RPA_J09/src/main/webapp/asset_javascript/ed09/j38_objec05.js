/**
 * for  … in 문                      
  객체의속성에 쉽게 접근할수 있는 문장.                   
 */
 
 let info = {
    subject : "javascript",
    credit: 3,
    days: 20,
    tuition: 1000
 };
 
 for(let i in info){
  console.log(`i=${i},info[${i}],`+info[i]);
}   