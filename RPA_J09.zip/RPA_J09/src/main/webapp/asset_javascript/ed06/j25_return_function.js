/**
 * return 함수의 처리 결과를 반환해 주는 명령어.                    
 */
 
 //평균 return
 function process(){
   let kor = 90;
   let eng = 90;
   let math = 90;
   
   let avg = (kor+eng+math)/3;
  
   return avg;
 }
 
 
 const avgResult = process();
 console.log(`avgResult:${avgResult}`);