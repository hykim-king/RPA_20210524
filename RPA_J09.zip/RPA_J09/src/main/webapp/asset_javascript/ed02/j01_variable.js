/**
 * 
 */
 //ES5
 //문법을 타이트하게 검사.
 'use strict'; 
 
 
//변수(var, let)
// 변수는 데이터를 저장하는 장소를 의미한다.

var num = 10;//var 변수 num에 10할당.
//let str = 'javascript';

let str = "javascript";  
let temp= true;
document.write("num="+num+"<br/> str="+str+"<br/> temp="+temp);
 
//1. 여러 개의 변수선언
let num01,str01,temp01;
num01 = 20, str01="pcwk",temp=true;

//2. 변수는 새로운 데이터가 저장되면 기존 데이터는 삭제된다.
let num02 = 0;
num02 = 10;
document.write("<br> num02="+num02);

//변수 관련 주의 사항.
//1. 변수명은 띄어쓰기를 할수 없다.
//let n um = 10;

//2. 변수명은 첫 글자는 숫자나 특수문자가 올수 없으나 예외적으로 '_','$'는 사용 가능.
//let 1java; //오류
//let %num;  //오류
let _num02;
let $num;

//3. javascript예약어들은 사용 불가.
//let break = 10;
//let continue = 10;


//4. 명명규칙
//carmelCase(카멜) 표기법 :  변수명,함수명
//                        ex) userAge, function createElement(){ }
//Pascal(파스칼) 표기법:     객체
//                        ex) UserAge
//underscore(언더스코어) 표기법
//                        ex) user_age,function create_element(){}


//let을 이용한 변수 선언
//ECMAScript 2015(ES6)
//var변수 선언의 단점을 보완하기 위해 추가(hosting)

let num05 = 10;
let str05 = "javascript";
let temp05= true;


//var vs let 차이
//var는 동일한 변수를 중복해서 선언할수 있다.
//let은 동일한 변수를 중복해서 사용불가.
//블록{ }

var num06 = 10;
var num06 = 20;
document.write("<br/>"+num06);

let num07 = 10;
//let num07 = 20;//Uncaught SyntaxError: Identifier 'num07' has already been declared
document.write("<br>"+num07);






















 