/**
 * var는 함수 블록{ }에서만 지역 변수 존재                                        
(블록{ }, 제어문 블록{ }에서는 지역 변수가 존재하지 않는다.)                                        
                                        
let,const는 블록{ }이나, 제어문 블록{ }에서도 지역변수를 선언 할 수 있다.                                       

 */
 'use strict'
 
/* 블록{ }, 제어문 블록{ }에서는 지역 변수가 존재하지 않는다.
 var num = 10;
 {
    var num = 20;//전역 변수
    console.log(num);
 }
 
 console.log(num);
 */
 
 //let,const는 블록{ }이나, 제어문 블록{ }에서도 지역변수를 선언 할 수 있다.
/* 
 let num = 10;
 {
    let num = 20; //지역변수
    console.log(num);//20
 }
 console.log(num);//10
 */
  //let,const는 블록{ }이나, 제어문 블록{ }에서도 지역변수를 선언 할 수 있다.
 const num = 10;
 {
    const num = 20; //지역변수
    console.log(num);//20
 }
 console.log(num);//10  
 
 
 