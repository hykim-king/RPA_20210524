/**
 * 
 */
 
 window.onload = function(){
    //console.log('window.onload');
    
    let list01 = document.querySelector("#box1 > ul > li");
    //console.log(`list01:${list01}`);
    list01.style.background = "#ff6600";
    
    let list02 = document.querySelectorAll("#box2 > ul > li");
    console.log(`list02:${list02}`);
    list02[0].style.background ="#ccc";
    
    list02.item(1).style.background  ="#ddd";   
 }