/**
 * 
 */
function createEle(){
  console.log('createEle');
  let div =document.getElementById('content');
  div.innerHTML = "<p class='m1'>자바스크립트</p>";
} 


addEventListener('load',createEle);