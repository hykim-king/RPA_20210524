/**
 * 
 */
 let wrap = document.getElementById('wrap');
 
 console.log(`wrap:${wrap}`);
 //div에 class속성 값을 가지고 옴
 let classValue = wrap.getAttribute('class');
 console.log(`classValue:${classValue}`);
 
 //요소의 속성 제거
 //wrap.removeAttribute('class');
 
  