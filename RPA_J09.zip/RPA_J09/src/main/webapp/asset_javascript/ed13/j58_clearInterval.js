/**
 * 
 */
 
window.onload =  function(){
  
  let bt = document.getElementById("bt");
  //console.log(bt);
  
  let i =0;
   
  let increase = setInterval( function(){
    i ++;
    alert(i); 
    
  },3000); 
  
  bt.onclick = function(){
    console.log("멈춤")
    clearInterval(increase); 
  };
  
  
  
  
  
}; 