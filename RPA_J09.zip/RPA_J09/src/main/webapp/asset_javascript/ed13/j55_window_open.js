/**
 * 
 */
 window.onload = function(){
  let bt = document.getElementById("bt");
  bt.onclick = function(){
      window.open("https://cafe.daum.net/pcwk","PCWK_CAFE",
      "width=600, height=400, left=100,top=100,location=yes,menubar=no,toolbar=no,status=yes");
  };
  
 };