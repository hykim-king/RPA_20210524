package com.pcwk.board.dao;

import org.apache.log4j.Logger;

public class HelloLog4J {
	static final Logger LOG = Logger.getLogger(HelloLog4J.class);
	public static void main(String[] args) {
		
		LOG.debug("Hello,Log4j.");
	}

}
