package com.pcwk.board.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.apache.log4j.Logger;

import com.pcwk.board.domain.BoardVO;
import com.pcwk.board.domain.SearchVO;

public class BoardTestMain {
    static final Logger LOG = Logger.getLogger(BoardTestMain.class);
	BoardVO inVO;
	BoardDao dao;
	

	
	public BoardTestMain() {
		inVO=new BoardVO();
		//inVO.setSeq(1);
		inVO.setTitle("게시제목 99_수정");
		inVO.setConstents("내용 99_수정");
		inVO.setReadCnt(0);
		inVO.setRegId("pcwk");		
		
		
		dao = new BoardDao();
	}
	
	public void doMerge() {
		int flag = dao.doMerge(inVO);
		if(flag ==1) {
			LOG.debug("====================");
			LOG.debug("=merge 성공="+flag);
			LOG.debug("====================");
		}
	}
	
	
	public void doDelete() {
		int flag = dao.doDelete(inVO);
	}
	
	public void doInsert() {
		int flag = dao.doInsert(inVO);
		if(flag ==1) {
			LOG.debug("*******************");
			LOG.debug("********등록성공:"+flag);
			LOG.debug("*******************");
		}
	}
	
	public void doSelectOne() {
		BoardVO oneVO = (BoardVO) dao.doSelectOne(inVO);
		if(oneVO.equals(inVO)) {
			LOG.debug("*********************");
			LOG.debug("***조회 성공:");
			LOG.debug("*********************");				
		}
	}

	public void doRetrieve() {
		SearchVO search=new SearchVO();
		search.setPageSize(10);
		search.setPageNum(1);
		search.setSearchDiv("");//전체
		
		List<BoardVO> list = dao.doRetrieve(search);
		for(BoardVO vo :list) {
			LOG.debug(vo);
		}
	}
	
	
	public void doReadCnt() {
		inVO.setSeq(100007);
		
		int flag = dao.doReadCnt(inVO);
		if(flag==1) {
			LOG.debug("*********************");
			LOG.debug("**doReadCnt*:");
			LOG.debug("*********************");				
		}
		
		
	}
	
	public void getTotalCnt() {
		SearchVO search=new SearchVO();
		search.setPageSize(10);
		search.setPageNum(1);
		search.setSearchDiv("10");//전체
		search.setSearchWord("제목");
		
		int totalCnt = dao.getTotalCnt(search);
		LOG.debug("*********************");
		LOG.debug("**totalCnt*:");
		LOG.debug("*********************");			
		
		
	}
	
	public static String formatDate(String format) {
		// null or "" 기본값 yyyy/MM/dd
		if (Objects.equals(format, "")) {
			format = "yyyy/MM/dd";
		}

		SimpleDateFormat sdf = new SimpleDateFormat(format);

		return sdf.format(new Date());
	}
	
	
	public static String getUUID() {
		String uuidStr = "";
		UUID  uuid = UUID.randomUUID();
		
		uuidStr = uuid.toString().replaceAll("-", "");
		return uuidStr;
	}
	
	public static String getPK(String format) {

		return formatDate(format) + getUUID();
	}
	
	
	public static void main(String[] args) {
		BoardTestMain main=new BoardTestMain();
		//8a00658e-4d0f-4b3b-80f9-116823b4e3e2
		LOG.debug("*********************");
		LOG.debug("**main.getUUID*:"+main.getUUID());
		LOG.debug("**main.getUUID*:"+main.getUUID().length());
		LOG.debug("**main.getPK*:"+main.getPK("yyyyMMddHHmmss"));
		LOG.debug("*********************");		
		//기존 데이터 삭제
		//main.doDelete();
		//데이터 입력
//		main.doMerge();
		
//		//기존 데이터 삭제
//		main.doDelete();
//		
//		//데이터 입력
//		main.doInsert();
//		
//		//단건조회
//		main.doSelectOne();  
//		
		//리드 cnt
//		main.doReadCnt();
		//목록조회
//		main.doRetrieve();
	    
		//총글수
//		main.getTotalCnt();
	}

}
