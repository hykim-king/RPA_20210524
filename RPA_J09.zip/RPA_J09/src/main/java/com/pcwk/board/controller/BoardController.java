package com.pcwk.board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.pcwk.board.dao.BoardDao;
import com.pcwk.board.domain.BoardVO;
import com.pcwk.board.domain.SearchVO;
import com.pcwk.cmn.MessageVO;

/**  
 * Servlet implementation class BoardController
 */
@WebServlet(description = "게시판", urlPatterns = { "/board/board.do" })
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final Logger LOG = Logger.getLogger(getClass());
	
	//Dao
	private BoardDao  dao;       
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardController() {
        super();
        LOG.debug("1. BoardController()");
        dao = new BoardDao();
        
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("2. doGet()");
		serviceHandler(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("2. doPost()");
		serviceHandler(request,response);
	}
    /**
     * method분기
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    public void serviceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	LOG.debug("3. serviceHandler()");
    	//request encoding: utf-8
    	request.setCharacterEncoding("utf-8");
    	//응답처리
    	response.setContentType("text/html; charset=utf-8");
    	
    	//작업분기
    	String workDiv = request.getParameter("work_div");
    	LOG.debug("workDiv:"+workDiv);
    	switch(workDiv) {
    		case  "doRetrieve" :
    			doRetrieve(request,response);
    			break;
    		case "moveToReg":
    			moveToReg(request,response);
    			break;
    		case "doInsert": //게시글 등록
    			doInsert(request,response);
    			break;
    		case "doSelectOne"://상세 조회
    			doSelectOne(request,response);
    			break;
    		case "doDelete"://삭제
    			doDeletePCWK(request,response);
    			break;
    		case "doUpdate"://수정
    			doUpdate(request,response);
    			break;
    	}
    	
    }
    
    //수정
    public void doUpdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.debug("===================");
        LOG.debug("=doUpdate==");
        LOG.debug("===================");     	
        BoardVO  inVO =new BoardVO();
        MessageVO msgVO=new MessageVO();
        
        String seq = request.getParameter("seq");
        String title = request.getParameter("title");
        String constents = request.getParameter("constents");
        
        inVO.setSeq(Integer.parseInt(seq));
        inVO.setTitle(title);
        inVO.setConstents(constents);
        
        LOG.debug("inVO:"+inVO);
        
        int flag = dao.doUpdate(inVO);
        
        msgVO.setMsgId(String.valueOf(flag));
        String msgCont = "";
        if(1==flag) {
        	msgCont ="수정 되었습니다.";
        }else {
        	msgCont ="수정 실패";
        }
        
        msgVO.setMsgContents(msgCont);
        msgVO.setMsgDetail(flag+":"+msgCont);
        
        Gson gson=new Gson();
        String jsonString = gson.toJson(msgVO);
        LOG.debug("jsonString:"+jsonString);
        
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.print(jsonString);        
        
        
    }
    
    //삭제
    public void doDeletePCWK(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.debug("===================");
        LOG.debug("=doDeletePCWK==");
        LOG.debug("===================");     	
        BoardVO  inVO =new BoardVO();
        MessageVO msgVO=new MessageVO();
        
        String seq = request.getParameter("seq");
        inVO.setSeq(Integer.parseInt(seq));
        
        LOG.debug("inVO="+inVO);
        
        //dao호출
        int flag = dao.doDelete(inVO);
        
        //JSON
        msgVO.setMsgId(String.valueOf(flag));
        String msgCont = "";
        if(1==flag) {
        	msgCont = "삭제 되었습니다.";
        }else {
        	msgCont = "삭제 실패.";
        }
        
        msgVO.setMsgContents(msgCont);
        msgVO.setMsgDetail(flag+":"+msgCont);
        
        Gson  gson=new Gson();
        String jsonString = gson.toJson(msgVO);
        LOG.debug("jsonString:\n"+jsonString);
        
        //view로 json전달
        PrintWriter out=response.getWriter();
        out.print(jsonString);
        
    }
    
    
    
    //상세 조회
    public void doSelectOne(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.debug("===================");
        LOG.debug("=doSelectOne==");
        LOG.debug("===================");   	
        BoardVO inVO = new BoardVO();
        
        String seq  = request.getParameter("seq");
        inVO.setSeq(Integer.parseInt(seq));
        
        LOG.debug("inVO:"+inVO);
        
        //조회 count증가
        if(null != inVO) {
        	int flag = dao.doReadCnt(inVO);
        	LOG.debug("doReadCnt flag:"+flag);
        }
        
        
        BoardVO outVO = (BoardVO) dao.doSelectOne(inVO);
        LOG.debug("outVO:"+outVO);
        

        
        
        //화면으로 전달할 데이터
        request.setAttribute("vo", outVO);
        
        RequestDispatcher dispacher = request.getRequestDispatcher("/board/board_mod.jsp");
        dispacher.forward(request, response);
        
    }
    //등록
    public void doInsert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.debug("===================");
        LOG.debug("=doInsert==");
        LOG.debug("===================");    	
        BoardVO  inVO = new BoardVO();
        MessageVO msgVO=new MessageVO();
        
        String title = request.getParameter("title");
        String constents = request.getParameter("constents");
        
        //TODO: Session에서 등록자 ID받을 것.
        String regId ="ADMIN";
        
        inVO.setTitle(title);
        inVO.setConstents(constents);
        inVO.setRegId(regId);

        
        LOG.debug("inVO:"+inVO);
        int flag = dao.doInsert(inVO);
        
        msgVO.setMsgId(String.valueOf(flag));
        
        String msgCont = "";
        if(1==flag) {
        	msgCont = "등록 성공!";
        }else {
        	msgCont = "등록 실패!";
        }
        
        msgVO.setMsgContents(msgCont);
        msgVO.setMsgDetail(flag+":"+msgCont);
        
        LOG.debug("flag:"+flag);
        LOG.debug("msgVO:"+msgVO);
        
        Gson gson=new Gson();
        //Object -> JSON String으로 변환
        String jsonString = gson.toJson(msgVO);
        LOG.debug("jsonString:"+jsonString);
        
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.print(jsonString);
    }
    
    
    
    public void moveToReg(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
          LOG.debug("===================");
          LOG.debug("=moveToReg==");
          LOG.debug("===================");
          
          RequestDispatcher dispatcher = request.getRequestDispatcher("/board/board_reg.jsp");
          dispatcher.forward(request, response);
    }
    
    
//	doReadCnt()
//	doRetrieve()
//	doUpdate()
//	doSelectOne()
//	doDelete()
//	doInsert()
    
    public void doRetrieve(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	SearchVO inVO =new SearchVO();
    	inVO.setPageNum(1);
    	inVO.setPageSize(10);
    	
    	String searchDiv = request.getParameter("searchDiv");//검색구분
    	String searchWord= request.getParameter("searchWord");//검색어
    	String pageSize  = request.getParameter("pageSize");//페이지사이즈
    	//TODO : pageNum 추후 구현.
    	
    	
    	
    	inVO.setSearchDiv(searchDiv);
    	inVO.setSearchWord(searchWord);
    	inVO.setPageSize(Integer.parseInt(pageSize));
    	
    	LOG.debug(" inVO:"+inVO.toString());
    	//조회목록
    	List<BoardVO> list = dao.doRetrieve(inVO);
    	for(BoardVO vo:list) {
    		LOG.debug(vo);
    	}
    	  
    	//총글수
        int totalCnt = dao.getTotalCnt(inVO);
        request.setAttribute("totalCnt", totalCnt);
        
    	request.setAttribute("vo", inVO);
    	request.setAttribute("list", list);
    	
    	RequestDispatcher  dispatcher = request.getRequestDispatcher("/board/board_list.jsp");
    	dispatcher.forward(request, response); 
    	
    }
    
    
    


}
