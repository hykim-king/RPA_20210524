package com.pcwk.board.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.pcwk.board.domain.BoardVO;
import com.pcwk.board.domain.SearchVO;
import com.pcwk.cmn.DTO;
import com.pcwk.cmn.JDBCUtil;

public class BoardDao implements WorkdDiv {
	final static Logger LOG = Logger.getLogger(BoardDao.class);

	
	
	/**
	 * 총글수 
	 * @param inVO
	 * @return
	 */
	public int getTotalCnt(SearchVO vo) {
		int count =0;
		SearchVO inVO = vo;
		
		Connection con           = null;
		PreparedStatement  pstmt = null;
		ResultSet          rs    = null;
		
		try {
			//db Connection연결
			con = getConnection();
			
			//검색조건 
			StringBuilder sbWhere =new StringBuilder(300);
			//제목
			if(inVO.getSearchDiv().equals("10")) {
				sbWhere.append("AND title LIKE ? || '%'  \n");
			//내용	
			}else if(inVO.getSearchDiv().equals("20")) {
				sbWhere.append("AND constents LIKE ? || '%'  \n");
			//등록자id	
			}else if(inVO.getSearchDiv().equals("30")) {
				sbWhere.append("AND reg_id LIKE ? || '%'  \n");
			//순번 검색	
			}else if(inVO.getSearchDiv().equals("40")) {
				sbWhere.append("AND seq LIKE ? || '%'  \n");
			}
			
			//main 쿼리
			StringBuilder sb=new StringBuilder(500);
			sb.append(" SELECT COUNT(*) CNT \n");
			sb.append(" FROM board          \n");
			sb.append(" WHERE seq > 0       \n");
			//검색조건
			sb.append(sbWhere.toString() );
			
			LOG.debug("2) 쿼리:\n"+sb.toString());
			LOG.debug("2-1) param:\n"+inVO.toString());	
			//preparedStatement 객체 생성
			pstmt = con.prepareStatement(sb.toString());
			
			//검색조건이 있으면
			if(null != inVO && !inVO.getSearchDiv().equals("")  ) {
				pstmt.setString(1, inVO.getSearchWord());
			}
			
			//query수행
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				count = rs.getInt(1);
			}
			LOG.debug("2-2) count:"+count);	
			
			
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");				
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(con);			
		}
		
		return count;
	}
	/**
	 * read_cnt++
	 * @param param
	 * @return 성공:1,실패:0
	 */
	public int doReadCnt(BoardVO param) {
		int flag = 0;
		BoardVO inVO = param;
		
		Connection con           = null;//connection객체
		PreparedStatement  pstmt = null;//query수행
		
		try {
		     con = getConnection();
		     LOG.debug("1) Connection -DB와 연결:"+con);
		     StringBuilder sb=new StringBuilder(50);
		     sb.append(" UPDATE board                           \n");
		     sb.append(" SET read_cnt = NVL(read_cnt,0)+1       \n");
		     sb.append(" WHERE seq = ?		                    \n");
		     
		     LOG.debug("2) 쿼리:\n+"+sb.toString());
		     LOG.debug("2-1) param:\n+"+inVO.toString());
		     
		     pstmt = con.prepareStatement(sb.toString());
		     pstmt.setInt(1, inVO.getSeq());
		     
		     
		     flag = pstmt.executeUpdate();
		     LOG.debug("3) flag:"+flag);
		     
		}catch(SQLException e) {
			LOG.debug("SQLException================================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException================================");
		}finally {
			JDBCUtil.close(pstmt);
			JDBCUtil.close(con);
		}
		
		return flag;
	}
	
	/**
	 * 등록/수정 수행
	 * @param vo
	 * @return 성공:1,실패:0
	 */
	public int doMerge(DTO vo) {
		int flag = 0;
		BoardVO inVO = (BoardVO) vo;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = getConnection();
			StringBuilder sb=new StringBuilder(200);
			sb.append(" MERGE INTO board t1                                                                                    \n");
			sb.append(" USING (                                                                                                \n");
			sb.append("     SELECT                                                                                             \n");
			sb.append("         ? seq,                                                                                         \n");
			sb.append("         ? title,                                                                                       \n");
			sb.append("         ? constents,                                                                                   \n");
			sb.append("         ? reg_id                                                                                       \n");
			sb.append("     FROM dual                                                                                          \n");
			sb.append(" )t2                                                                                                    \n");
			sb.append(" ON (t1.seq = t2.seq)                                                                                   \n");
			sb.append(" WHEN MATCHED THEN                                                                                      \n");
			sb.append("     UPDATE SET t1.title = t2.title,                                                                    \n");
			sb.append("                t1.constents = t2.constents,                                                            \n");
			sb.append("                t1.reg_id = t2.reg_id                                                                   \n");
			sb.append(" WHEN NOT MATCHED THEN                                                                                  \n");
			sb.append("     INSERT (t1.seq,t1.title,t1.constents,t1.reg_id) VALUES (BOARD_SEQ.NEXTVAL,t2.title,t2.constents,t2.reg_id)    \n");
						
			LOG.debug("2) 쿼리:\n"+sb.toString());
			LOG.debug("2-1) param:\n"+inVO.toString());
			
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, inVO.getSeq());
			pstmt.setString(2, inVO.getTitle());
			pstmt.setString(3, inVO.getConstents());
			pstmt.setString(4, inVO.getRegId());
			
			flag = pstmt.executeUpdate();
			LOG.debug("3) flag: "+flag);
			
		}catch(SQLException e) {
			LOG.debug("=SQLException=======================================");
			LOG.debug(e.getMessage());
			LOG.debug("=SQLException=======================================");
		}finally {
			JDBCUtil.close(pstmt);
			JDBCUtil.close(con);
		}
				
		
		
		return flag;
	}
	
	
	@Override
	public List<BoardVO> doRetrieve(DTO vo) {
		List<BoardVO> list = null;
		SearchVO inVO      = (SearchVO) vo;
		
		Connection con           = null;
		PreparedStatement  pstmt = null;
		ResultSet          rs    = null;
		
		try {
			//db연결
			con = getConnection();
			
			//검색조건 
			StringBuilder sbWhere =new StringBuilder(300);
			//제목
			if(inVO.getSearchDiv().equals("10")) {
				sbWhere.append("AND title LIKE ? || '%'  \n");
			//내용	
			}else if(inVO.getSearchDiv().equals("20")) {
				sbWhere.append("AND constents LIKE ? || '%'  \n");
			//등록자id	
			}else if(inVO.getSearchDiv().equals("30")) {
				sbWhere.append("AND reg_id LIKE ? || '%'  \n");
			//순번 검색	
			}else if(inVO.getSearchDiv().equals("40")) {
				sbWhere.append("AND seq LIKE ? || '%'  \n");
			}
			
			//main 쿼리
			StringBuilder sb=new StringBuilder(500);
			sb.append(" SELECT tt1.rnum num,                                                                                                 \n");
			sb.append("        tt1.seq,                                                                                                    \n");
			sb.append("        tt1.title,                                                                                                    \n");
			sb.append("        tt1.reg_id,                                                                                                   \n");
			sb.append("        CASE WHEN TO_CHAR(SYSDATE,'YYYY/MM/DD')=TO_CHAR(tt1.reg_dt,'YYYY/MM/DD') THEN TO_CHAR(tt1.reg_dt,'HH24:MI')   \n");
			sb.append("             ELSE TO_CHAR(tt1.reg_dt,'YYYY/MM/DD')                                                                    \n");
			sb.append("        END reg_dt,                                                                                                 \n");
			sb.append("        tt1.read_cnt                                                                                                  \n");
			sb.append(" FROM(                                                                                                                \n");
			sb.append("     SELECT rownum rnum,T1.*                                                                                          \n");
			sb.append("     FROM(                                                                                                            \n");
			sb.append("         --최신글에 첫번째 보이도록 처리                                                                                      \n");
			sb.append("         SELECT /*+ INDEX_DESC(board PK_BOARD) */ *                                                                     \n");
			sb.append("         FROM board                                                                                                   \n");
			sb.append("         WHERE 1=1                                                                                                \n");
			sb.append("         --검색조건                                                                                                      \n");
			
			//where검색 조건-----------------------------------------------------------------------------------------------
			sb.append(sbWhere.toString());
			//----------------------------------------------------------------------------------------------------------
			
			sb.append("                                                                                                                           \n");
			
			//sb.append("         ORDER BY seq DESC                                                                                            \n");
			sb.append("     )t1                                                                                                              \n");
			sb.append(" )tt1                                                                                                                 \n");
			sb.append(" --WHERE rnum BETWEEN :page_size * (:page_num-1)+1 AND :page_size * (:page_num-1)+:page_size                          \n");
			sb.append(" WHERE rnum BETWEEN ? * (?-1)+1 AND ? * (?-1)+?                                                                       \n");			
			
		    LOG.debug("2) 쿼리:\n"+sb.toString());
		    LOG.debug("2-1) param:\n"+inVO.toString());			
			
			//preparedStatement 객체 생성
			pstmt = con.prepareStatement(sb.toString());
			
			//검색조건이 있으면
			if(!inVO.getSearchDiv().equals("")) {
				pstmt.setString(1, inVO.getSearchWord());
				pstmt.setInt(2, inVO.getPageSize());
				pstmt.setInt(3, inVO.getPageNum());
				
				pstmt.setInt(4, inVO.getPageSize());
				pstmt.setInt(5, inVO.getPageNum());
				pstmt.setInt(6, inVO.getPageSize());
			//검색조건이 없으면	
			}else {
				pstmt.setInt(1, inVO.getPageSize());
				pstmt.setInt(2, inVO.getPageNum());
				
				pstmt.setInt(3, inVO.getPageSize());
				pstmt.setInt(4, inVO.getPageNum());
				pstmt.setInt(5, inVO.getPageSize());				
			}
			//query수행
			rs = pstmt.executeQuery();
			list = new ArrayList<BoardVO>();
			
			while(rs.next()) {
				BoardVO outVO=new BoardVO();
				outVO.setNum(rs.getInt("num"));//DTO
				
		    	outVO.setSeq(rs.getInt("seq"));
		    	outVO.setTitle(rs.getString("title"));
		    	outVO.setReadCnt(rs.getInt("read_cnt"));
		    	outVO.setRegId(rs.getString("reg_id"));
		    	outVO.setRegDt(rs.getString("reg_dt"));
		    	
		    	list.add(outVO);
			}
			
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");					
		}finally {
			JDBCUtil.close(rs);
			JDBCUtil.close(pstmt);
			JDBCUtil.close(con);
		}

		return list;
	}

	@Override
	public int doUpdate(DTO vo) {
		int flag = 0;
		BoardVO inVO  = (BoardVO) vo;//param
		
		Connection        con   = null;//db connection객체
		PreparedStatement pstmt = null;//query수행
		try {
			con =  getConnection();
			LOG.debug("1) Connection -DB와 연결 : "+con);
			StringBuilder sb=new StringBuilder(50);
			sb.append(" UPDATE board	        \n");
			sb.append(" SET title     = ?,      \n");
			sb.append("     constents = ?       \n");
			sb.append(" WHERE seq = ?           \n");
			
			LOG.debug("2) 쿼리:\n"+sb.toString());
			LOG.debug("2-1) 파라메터:"+inVO.toString());
			pstmt = con.prepareStatement(sb.toString());
			
			//위아래 순서대로 ? 값 지정
			pstmt.setString(1, inVO.getTitle());//문자로 set
			pstmt.setString(2, inVO.getConstents());
			pstmt.setInt(3, inVO.getSeq());//숫자로 set
			
			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:"+flag);
		}catch(SQLException e) {
			LOG.debug("=SQLException===========================");
			LOG.debug(e.getMessage());
			LOG.debug("=SQLException===========================");
		}finally {
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			//Connection 자원반납
			JDBCUtil.close(con);
		}
		
		
		return flag;
	}

	@Override
	public DTO doSelectOne(DTO vo) {
		BoardVO inVO = (BoardVO) vo;
		BoardVO outVO = null;
		
		Connection          con = null;
		PreparedStatement pstmt = null;
		
		//데이터 조회
		ResultSet  rs           = null;
		try {
			con  = getConnection();
			LOG.debug("2) Connection -DB와 연결 :"+con);
			StringBuilder sb=new StringBuilder(200);
			sb.append (" SELECT seq,                                              \n");
		    sb.append ("    title,                                                \n");
			sb.append ("    constents,                                            \n");
			sb.append ("    read_cnt,                                             \n");
			sb.append ("    reg_id,                                               \n");
			sb.append ("    TO_CHAR(reg_dt,'YYYY/MM/DD hh24:MI:SS') reg_date      \n");
		    sb.append (" FROM board                                               \n");
		    sb.append (" WHERE seq = ?			                                  \n");
		    LOG.debug("2) 쿼리:\n"+sb.toString());	
		    LOG.debug("2-1) param:\n"+inVO.toString());
		    
		    pstmt = con.prepareStatement(sb.toString());
		    pstmt.setInt(1, inVO.getSeq());
		    
		    rs = pstmt.executeQuery();//결과 return;
		    if(rs.next()) {
		    	outVO = new BoardVO();
		    	
		    	//int seq = rs.getInt("seq");
		    	//outVO.setSeq(seq);
		    	
		    	outVO.setSeq(rs.getInt("seq"));
		    	outVO.setTitle(rs.getString("title"));
		    	outVO.setConstents(rs.getString("constents"));
		    	outVO.setReadCnt(rs.getInt("read_cnt"));
		    	outVO.setRegId(rs.getString("reg_id"));
		    	outVO.setRegDt(rs.getString("reg_date"));
		    }
		    
		    LOG.debug("3) ResultSet:"+outVO.toString());	
			
		}catch(SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");
		}finally {
			//ResultSet 자원반납
			JDBCUtil.close(rs);
			
			//PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			
			//Connection 자원반납
			JDBCUtil.close(con);
			
		}
		
		
		return outVO;
	}
	

	/**
	 * Database Connection
	 * 
	 * @return Connection
	 * @throws SQLException
	 */
	public Connection getConnection() throws SQLException {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			LOG.debug("ClassNotFoundException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("ClassNotFoundException=====================");
		}
		LOG.debug("1) JDBC Driver loading ");

		con = DriverManager.getConnection(JDBCUtil.DB_URL , JDBCUtil.USER_ID, JDBCUtil.USER_PASS);
		LOG.debug("2) Connection -DB와 연결 :" + con);
		return con;
	}

	@Override
	public int doDelete(DTO vo) {
		int flag = 0;
		BoardVO inVO = (BoardVO) vo;// param

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 :" + con);

			StringBuilder sb = new StringBuilder(50);
			sb.append(" DELETE FROM board ");
			sb.append(" WHERE seq = ?     \n");
			LOG.debug("2) 쿼리:\n" + sb.toString());
			LOG.debug("2-1) param:\n" + inVO.toString());

			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1, inVO.getSeq());

			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:" + flag);
		} catch (SQLException e) {
			LOG.debug("SQLException=====================");
			LOG.debug(e.getMessage());
			LOG.debug("SQLException=====================");
		} finally {
			// PreparedStatement 자원반납
			JDBCUtil.close(pstmt);
			// Connection 자원반납
			JDBCUtil.close(con);
		}

		return flag;
	}



	@Override
	public int doInsert(DTO vo) {
		int flag = 0;
		BoardVO inVO = (BoardVO) vo;
		// ---------------------------------
		/*
		 * 1) JDBC Driver loading - 데이터베이스 벤더에 맞는 디라이버를 호출 - 데이터페이스와의 연결을 위해 드라이버 로딩.
		 * 
		 * 2) Connection -DB와 연결을 위해 URL과 아이디/비번 필요 -연결 메소드
		 * DriverManager.getConnection(url,id,password):Connection
		 * 
		 * 3) Statement/PreparedStatement - SQL구문을 정의하고 변경될 값은 치환문자(?)를 이용해서 쿼리 전송
		 * 
		 * 4) executeUpdate()/executeQuery() - executeUpdate() : SQL Query
		 * insert,update,delete의 경우에 사용. - executeQuery() : SQL Query select문에 사용.
		 * 
		 * 5) ResultSet(Select의 경우 해당) - 데이터베이스 조회 결과 집합에 대한 표준 - next()를 통해 DB Table에
		 * row한 줄을 불러온다. - getString(Column명),getInt(Column명)를 통해 특정 Column값을 가져 온다.
		 */

		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = getConnection();
			LOG.debug("2) Connection -DB와 연결 " + con);

			StringBuilder sb = new StringBuilder();
			sb.append(" INSERT INTO BOARD (SEQ,TITLE,CONSTENTS,READ_CNT,REG_ID,REG_DT) \n");
			sb.append(" VALUES (BOARD_SEQ.NEXTVAL,?,?,?,?,sysdate) \n");

			LOG.debug("2) 쿼리:\n" + sb.toString());

			LOG.debug("2-1) param:\n" + inVO.toString());

			pstmt = con.prepareStatement(sb.toString());

			pstmt.setString(1, inVO.getTitle());
			pstmt.setString(2, inVO.getConstents());
			pstmt.setInt(3, inVO.getReadCnt());
			pstmt.setString(4, inVO.getRegId());

			flag = pstmt.executeUpdate();
			LOG.debug("3) flag:" + flag);

		} catch (SQLException e) {
			LOG.debug("=SQLException================================");
			LOG.debug(e.getMessage());
			LOG.debug("=================================");
		} finally {
			// pstmt 자원반납
			JDBCUtil.close(pstmt);

			// con 자원반납
			JDBCUtil.close(con);
		}

		// ---------------------------------
		return flag;
	}

}
