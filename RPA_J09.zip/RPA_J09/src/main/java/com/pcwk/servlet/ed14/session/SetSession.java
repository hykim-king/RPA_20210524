package com.pcwk.servlet.ed14.session;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SetSession
 */
@WebServlet(description = "세션 set", urlPatterns = { "/session/set_session" })
public class SetSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetSession() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		//session객체
		HttpSession  session = request.getSession();
		
		//생성된 session id
		out.println("세션 ID:"+session.getId() +"<br>");
		out.println("세션 생성 시각:"+new Date( session.getCreationTime()) +"<br>");
		
		//가장 최근에 접근한 시간
		out.println("세션 접근 시각:"+new Date( session.getLastAccessedTime()) +"<br>");
		
		//session유효시간:web.xml
		//<session-timeout>30</session-timeout>
		//1800 = 60*30
		out.println("session유효시간:"+session.getMaxInactiveInterval() +"<br>");
		
		//최초로 생성된 session인지
		if(session.isNew()) {
			out.println("새 세션이 만들어 졌습니다.");
		}
		
		
		
		
	}

}
