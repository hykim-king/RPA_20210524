package com.pcwk.servlet.ed13.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class SetCookieValue
 */
@WebServlet(description = "쿠키 set", urlPatterns = { "/cookie/session/set_cookie" })
public class SetCookieValue extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private final Logger  LOG = Logger.getLogger(getClass());   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SetCookieValue() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		Date d =new Date();
		
		//cookie값을 utf-8 encoding해서 저장.
		Cookie c=new Cookie("cookieTestSession", URLEncoder.encode("JSP_session 프로그래밍", "utf-8"));
		//유효기간
		//c.setMaxAge(60*60*24);
		c.setMaxAge(-1);//브라우저 메모리상에 저장
		
		
		//생성된 쿠키를 브라우저로 전송
		response.addCookie(c);
		
		out.println("현재시간: "+d);
		out.println("문자열을 Cookie에 저장.");
		
		
	}

}





































