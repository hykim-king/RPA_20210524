package com.pcwk.servlet.ed01;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class MultiServletInput
 */
@WebServlet(description = "checkbox 다건전송", urlPatterns = { "/multi_input" })
public class MultiServletInput extends HttpServlet {
	private final Logger LOG = Logger.getLogger(getClass());
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MultiServletInput() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		super.service(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("doPost()");
		//Encoding
		request.setCharacterEncoding("utf-8");
		
		String userId = request.getParameter("user_id");
		LOG.debug("userId:"+userId);
		//input에 변수 name속성들을 모두 읽는다.
		Enumeration<String> enu = request.getParameterNames();
		while(enu.hasMoreElements()) {
			
			String name = enu.nextElement();
			String[]  values = request.getParameterValues(name);
			for(String value : values) {
				LOG.debug("name:"+name);
				LOG.debug("value:"+value);
			}
			
			
		}
		
		
		
		
	}

}












