package com.pcwk.servlet.json.ed11;

import com.google.gson.Gson;
import com.pcwk.cmn.MessageVO;
public class JsonMain {

	public static void main(String[] args) {
		MessageVO outMSG =new MessageVO();
		
		
		outMSG.setMsgId("1");
		outMSG.setMsgContents("등록 성공!");
		
		Gson gson=new Gson();
		
		String jsonString = gson.toJson(outMSG);
		System.out.println("jsonString:\n"+jsonString);
	}

}
