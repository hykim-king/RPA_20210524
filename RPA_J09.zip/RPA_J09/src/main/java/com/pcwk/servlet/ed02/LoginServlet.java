package com.pcwk.servlet.ed02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(description = "응답", urlPatterns = { "/res_login" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private final Logger LOG = Logger.getLogger(getClass());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("doGet");
		doPost(request,response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("doPost");
		
		request.setCharacterEncoding("utf-8");//요청에 대한 encoding utf-8처리
		response.setContentType("text/html; charset=utf-8");//응답할 데이터 종류가 html,charset=utf-8로 지정
		//client(브라우저)에 데이터를 전송할수 있는 response로 PrintWriter객체 생성
		PrintWriter out = response.getWriter();
		
		String userId     = request.getParameter("user_id");
		String userPasswd = request.getParameter("user_ps");		
		
		LOG.debug("userId:"+userId);
		LOG.debug("userPasswd:"+userPasswd);     
		
		StringBuilder sb=new StringBuilder(500);
		sb.append(" <!DOCTYPE html>                      \n");
		sb.append("<html lang='ko'>                     \n");
		sb.append("<head>                               \n");
		sb.append(" <style type='text/css'>              \n");
		sb.append("                                      \n");
		sb.append(" </style>                             \n");
		sb.append(" <meta charset='UTF-8'>               \n");
		sb.append("<title>Insert title here</title>     \n");
		sb.append("</head>                              \n");
		sb.append("<body>                               \n");
		sb.append("        아이디:"+userId +"<br>          \n");
		sb.append("        비밀번호:"+userPasswd+"<br>      \n");
		sb.append("</body>                              \n");
		sb.append("</html>                              \n");	
		
		out.print(sb.toString());
	}

}
















