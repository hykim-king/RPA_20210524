package com.pcwk.servlet.ed16.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class LoginServletTest
 */
@WebServlet(description = "로그인_세션_테스트", urlPatterns = { "/login/session/test" })
public class LoginServletTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
    final Logger LOG = Logger.getLogger(getClass());   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServletTest() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		serviceHandler(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		serviceHandler(request,response);
	}
	
	protected void serviceHandler(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LOG.debug("=serviceHandler=========");
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		//작업분기
		String workDiv = request.getParameter("work_div");
		LOG.debug("=workDiv="+workDiv);
		switch(workDiv) {
			case "doLogin":
				doLogin(request,response);
				break;
			case "doLogout":
				doLogout(request,response);
				break;				
		}
	}
	//로그인
	protected void doLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		
		String userId = request.getParameter("user_id");
		String userPw = request.getParameter("user_pw");
		
		session.setAttribute("user_id", userId);	
		RequestDispatcher  dispatcher = request.getRequestDispatcher("/asset_jsp/ed06_session/login_session_result.jsp");
		dispatcher.forward(request, response);
		
	}
	
	//로그아웃
	protected void doLogout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session  = request.getSession();
		if(null != session && null !=session.getAttribute("user_id")) {
			//session삭제
			session.invalidate();
		}
		
		RequestDispatcher  dispatcher = request.getRequestDispatcher("/asset_jsp/ed06_session/login_session_result.jsp");
		dispatcher.forward(request, response);		
	}	
	
	

}
