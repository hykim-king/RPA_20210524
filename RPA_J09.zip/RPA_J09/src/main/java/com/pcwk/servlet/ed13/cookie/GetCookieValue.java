package com.pcwk.servlet.ed13.cookie;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetCookieValue
 */
@WebServlet(description = "쿠키 get", urlPatterns = { "/cookie/session/get_cookie" })
public class GetCookieValue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetCookieValue() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		//브라우저(파일)에서 쿠키정보를 요청 배열로 가지고 온다.
		Cookie[] allValues = request.getCookies();
		
		for(int i=0;i<allValues.length;i++) {
			if(allValues[i].getName().equals("cookieTestSession")) {
				out.println("<h2>"+ URLDecoder.decode(allValues[i].getValue(), "UTF-8")  +"</h2>");
			}
		}
		
		
	}

}











