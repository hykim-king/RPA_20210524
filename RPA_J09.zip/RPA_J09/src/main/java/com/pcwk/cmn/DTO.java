package com.pcwk.cmn;

/**
 * 모든 VO에 Parent
 * 
 * @author HKEDU
 *
 */
public class DTO {
	private int num;// 글 번호

	public DTO() {
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public String toString() {
		return "DTO [num=" + num + "]";
	}

}
