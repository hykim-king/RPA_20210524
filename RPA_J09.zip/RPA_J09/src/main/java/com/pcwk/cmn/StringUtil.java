package com.pcwk.cmn;

public class StringUtil {

	/**
	 * 
	 * @param maxNum : 총글수(100038)
	 * @param currPageNo : 1 현재 페이지 
	 * @param rowPerPage : 10
	 * @param bottomCount: 10
	 * @param url        :/RPA_J09/board/board.do?work_div=doRetrieve&seq=&searchDiv=&searchWord=&pageSize=10
	 * @param scriptName : doSearchPage(url,currPage)
	 * @return
	 */
	public static String renderingPage(int maxNum,int currPageNo, int rowPerPage, int bottomCount,String url,
			String scriptName) {
		StringBuilder html=new StringBuilder(1000);
		/*
		 * maxNum(총글수) : 21
		 * rowPerPage(한 페이지에 보여질 행수) : 10
		 * bottomCount(바닥에 보여질 페이지 수) : 10 
		 * << < 1 2 3 4 5 6 7 8 9 10 > >>   
		 *      1block  2block  3block                                 
		 */
		
		int maxPageNo = ( (maxNum - 1) / rowPerPage ) +1 ;//3  --> 1 2 3
		
		int startPageNo = ((currPageNo -1) / bottomCount) * bottomCount + 1; // ---> 1
		int endPageNo   = ((currPageNo -1) / bottomCount +1) * bottomCount;  // ---> 10
		
		int nowBlockNo  = ((currPageNo - 1) / bottomCount)+1;   //  ---> 1
		int maxBlockNo  = ((maxNum - 1) / bottomCount) +1;      //  ---> 3
		
		int inx = 0;
		
		if(currPageNo > maxPageNo) return "";
		
		html.append("<nav> \n");
		html.append("\t <ul class=\"pagination\">   \n");
		//<< : 1페이지로 이동
		if(nowBlockNo > 1 && nowBlockNo <=maxBlockNo) {
			html.append("\t<li>   \n");
			html.append("\t\t<a href=\"javascript:"+scriptName+"('"+url+"',1); \" "+ "aria-label='Previous'>  \n");
			html.append("\t\t\t<span aria-hidden=\"true\">&laquo;</span> \n");
			html.append("</a>   \n");
			html.append("\t\t</li>  \n");
		}        
		
		//< : 시작페이지 - bottomCount(10)
		if(startPageNo > bottomCount) {
			html.append("\t<li>   \n");
			html.append("\t\t<a href=\"javascript:"+scriptName+"('"+url+"',"+(startPageNo - bottomCount)+ ");\" aria-label='Previous'>  \n");
			html.append("\t\t\t<span aria-hidden=\"true\">&lt;</span> \n");
			html.append("</a>   \n");
			html.append("\t</li>  \n");
		}
		
		//1 2 3 4 5 6 7 8 9 10
		for(inx = startPageNo; inx<=maxPageNo && inx <=endPageNo; inx++ ) {
			
			//하이퍼 링크 없음
			if(inx == currPageNo) {
				html.append("\t\t<li><a href=\"javascript:#\">");
				html.append(inx);
				html.append("\t\t</a></li> \n");
			}else {
				html.append("\t\t <li>   \n");
				html.append("\t\t\t<a href=\"javascript:"+scriptName+"('"+url+"',"+inx+ "); \" aria-label='Previous'>");
				html.append(inx);
				html.append("</a>   \n");
				html.append("\t\t</li>  \n");
			}
		}
		   
		//> : 현재블럭 * bottomCount(10)+1
		if(maxPageNo > inx) {
			html.append("\t<li>   \n");
			html.append("\t\t <a href=\"javascript:"+scriptName+"('"+url+"',"+((nowBlockNo * bottomCount)+1)+ "); \" aria-label='Previous'>  \n");
			html.append("\t\t\t<span aria-hidden=\"true\">&gt;</span> \n");
			html.append("\t\t</a>   \n");
			html.append("\t </li>  \n");
		}		
		
		
		//>> : 마지막 페이지로 이동
		if(maxPageNo > inx) {
			html.append("\t<li>   \n");
			html.append("\t\t<a href=\"javascript:"+scriptName+"('"+url+"',"+maxPageNo+ "); \" aria-label='Next'>  \n");
			html.append("\t\t\t<span aria-hidden=\"true\">&raquo;</span> \n");
			html.append("\t\t</a>   \n");
			html.append("\t</li>  \n");			
		}
		
		html.append("\t</ul> \n");
		html.append("</nav>   \n");
		
		
		return html.toString();
	}
}
