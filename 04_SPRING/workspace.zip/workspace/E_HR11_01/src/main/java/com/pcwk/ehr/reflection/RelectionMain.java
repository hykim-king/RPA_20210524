package com.pcwk.ehr.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

public class RelectionMain {

	final static Logger LOG = Logger.getLogger(RelectionMain.class);
	public static void main(String[] args) throws Exception {
		//리플렉션은 자바 코드를 추상화 해서 접근
		//모든 자바 클래스는 Class 타입의 오브젝트를 하나씩 가지고 있다.
		
		//기존 방법으로 메소드 호출
		
		String name ="Spring";
		//1.문자열 길이
		LOG.debug("name.length():"+name.length());
		
		//2.리플렉션
		Method lengthMethod = String.class.getMethod("length");

		int nameLength = (Integer) lengthMethod.invoke(name);
		LOG.debug("nameLength:"+nameLength);
		
		//charAt()
		LOG.debug("name.charAt(0):"+name.charAt(0));
		Method  chatAtMethod = String.class.getMethod("charAt", int.class);
		LOG.debug("chatAtMethod:"+chatAtMethod.invoke(name, 0));
	}

}
