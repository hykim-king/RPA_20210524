package com.pcwk.ehr.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;

public class UppercaseHandler implements InvocationHandler {

	Hello target;
	final Logger  LOG = Logger.getLogger(getClass());
	
	//다이나믹 프록시로부터 전달 받은 요청을 다시 타깃 오브젝트에 위임.
	public UppercaseHandler(Hello target) {
		this.target = target;
	}

	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		LOG.debug("method :"+method.getName());
		String retStr = (String) method.invoke(target, args);//target==HelloTarget
		
		//포인트컷(Pointcut)필터링된 조인 포인트: 원하는 특정 메소드에만 적용.
        if(retStr instanceof String && method.getName().startsWith("sayH")) {
        	return retStr.toUpperCase();
        }else {
        	return retStr;
        }
		
		
	}

}
