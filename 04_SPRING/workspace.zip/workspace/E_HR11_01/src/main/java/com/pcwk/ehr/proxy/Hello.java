package com.pcwk.ehr.proxy;

public interface Hello {

	String sayHello(String name);

	String sayHi(String name);

	String sayThankYou(String name);
}
