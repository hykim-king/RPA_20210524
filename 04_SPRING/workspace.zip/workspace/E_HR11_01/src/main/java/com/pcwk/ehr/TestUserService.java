package com.pcwk.ehr;

import java.sql.SQLException;

public class TestUserService extends UserServiceImpl {
	private String uId;
	
	public TestUserService() {
		
	}

	public TestUserService(String uId) {
		super();
		this.uId = uId;
	}

	//UserService의 upgradeLevel 오버라이드
	@Override
	protected void upgradeLevel(UserVO user) throws SQLException,TestUserServiceException {
		if(user.getuId().equals(this.uId) ) {
			throw new TestUserServiceException(uId);
		}
		
		super.upgradeLevel(user);
		
	}


	
	
}
