package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.lang.reflect.Proxy;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;

import com.pcwk.ehr.proxy.Hello;
import com.pcwk.ehr.proxy.HelloTarget;
import com.pcwk.ehr.proxy.HelloUppercase;
import com.pcwk.ehr.proxy.UppercaseHandler;

public class JProxyHello {
    final Logger LOG = Logger.getLogger(getClass());
    
    @Test
    public void dynamicProxy() {
    	//Proxy생성
	    Hello proxiedHello = (Hello)Proxy.newProxyInstance(
	    		    //동적으로 생성되는 다이내믹 프로시 클래스의 로딩
	    			getClass().getClassLoader(),
	    			//구현 인터페이스
	    			new Class[] {Hello.class},
	    			//부가기능 위임 기능을 담은 InvocationHandler
	    			new UppercaseHandler(new HelloTarget()));
    	LOG.debug(proxiedHello.sayHello("eClass"));
    	LOG.debug(proxiedHello.sayHi("eClass"));
    	LOG.debug(proxiedHello.sayThankYou("eClass"));
    	
    	assertThat(proxiedHello.sayHello("eClass"), is("HELLO ECLASS"));
    	assertThat(proxiedHello.sayHi("eClass"), is("HI ECLASS"));
    	//assertThat(proxiedHello.sayThankYou("eClass"), is("THANK YOU ECLASS"));
    	
    }
    
    @Test
    @Ignore
    public void simpleProxy02() {
    	//프록시를 통해서 타깃 오브젝트에 접근
    	Hello hello = new HelloUppercase(new HelloTarget());
    	LOG.debug(hello.sayHello("eClass"));
    	LOG.debug(hello.sayHi("eClass"));
    	LOG.debug(hello.sayThankYou("eClass"));
    	
    	
    	assertThat(hello.sayHello("eClass"), is("HELLO ECLASS"));
    	assertThat(hello.sayHi("eClass"), is("HI ECLASS"));
    	assertThat(hello.sayThankYou("eClass"), is("THANK YOU ECLASS"));
    }
    
	@Test
	@Ignore
	public void simpleProxy() {
		LOG.debug("====================");
		Hello hello = new HelloTarget();
		
		assertThat(hello.sayHello("eClass"), is("Hello eClass"));
		assertThat(hello.sayHi("eClass"), is("Hi eClass"));
		assertThat(hello.sayThankYou("eClass"), is("Thank you eClass"));
	}

}
