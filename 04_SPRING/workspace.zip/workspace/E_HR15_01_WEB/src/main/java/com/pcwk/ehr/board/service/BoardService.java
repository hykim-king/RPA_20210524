package com.pcwk.ehr.board.service;

import java.sql.SQLException;
import java.util.List;

import com.pcwk.ehr.SearchVO;
import com.pcwk.ehr.board.domain.BoardVO;

public interface BoardService {

	/**
	 * 게시글 목록 조회
	 * @param inVO
	 * @return List<BoardVO>
	 * @throws SQLException
	 */
	List<BoardVO> doRetrieve(SearchVO inVO) throws SQLException;

	/**
	 * 조회 count증가 
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	int doReadCntUpdate(BoardVO inVO) throws SQLException;

	/**
	 * 게시글 수정
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	int doUpdate(BoardVO inVO) throws SQLException;

	/**
	 * 게시글 등록
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 */
	int doInsert(BoardVO inVO) throws SQLException;

	/**
	 * 게시글 삭제
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	int doDelete(BoardVO inVO) throws SQLException;

	/**
	 * 단건조회 
	 * @param inVO
	 * @return BoardVO
	 * @throws SQLException
	 */
	BoardVO doSelectOne(BoardVO inVO) throws SQLException;

}