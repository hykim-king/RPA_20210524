package com.pcwk.ehr;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ChartControllerBasic {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	
	@RequestMapping(value = "chart/pieChart.do")
	public String pieChart() {
		LOG.debug("===========================");
		LOG.debug("==viewPie()=====");
		LOG.debug("===========================");
		
		return "chart/pieChart";
	}
	
	
}
