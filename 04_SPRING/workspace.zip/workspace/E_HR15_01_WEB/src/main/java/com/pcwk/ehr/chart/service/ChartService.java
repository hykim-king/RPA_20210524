package com.pcwk.ehr.chart.service;

import java.util.List;

import com.pcwk.ehr.chart.domain.ChartVO;

public interface ChartService {

	
	public List<ChartVO> memberLevelRatio();
}
