package com.pcwk.ehr.board.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pcwk.ehr.SearchVO;
import com.pcwk.ehr.board.domain.BoardVO;
import com.pcwk.ehr.member.dao.UserDaoImpl;
import com.pcwk.ehr.member.domain.UserVO;

@Repository
public class BoardDaoImpl  {

	final static org.slf4j.Logger LOG = LoggerFactory.getLogger(BoardDaoImpl.class);
	
	@Autowired
	SqlSessionTemplate   sqlSessionTemplate;
	
	final String NAMESPACE = "com.pcwk.ehr.board";	
	
	public BoardDaoImpl() {
		
	}
	
	/**
	 * 게시글 목록 조회
	 * @param inVO
	 * @return List<BoardVO>
	 * @throws SQLException
	 */
	public List<BoardVO> doRetrieve(SearchVO inVO) throws SQLException {
		List<BoardVO>   list=new ArrayList<>();
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");	
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doRetrieve";			
		list = sqlSessionTemplate.selectList(statement, inVO);
		
		for(BoardVO vo   :list) {
			LOG.debug(""+vo);
		}
		
		return list;
	}
	
	
	/**
	 * 조회 count증가 
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	public int doReadCntUpdate(BoardVO inVO) throws SQLException {
		int flag = 0;
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");	
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doReadCntUpdate";		
		flag = sqlSessionTemplate.update(statement, inVO);
		LOG.debug("flag=" + flag);
		return flag;
	}
	
	/**
	 * 게시글 수정
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	public int doUpdate(BoardVO inVO) throws SQLException {
		int flag = 0;
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");	
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doUpdate";	
		flag = sqlSessionTemplate.update(statement, inVO);
		LOG.debug("flag=" + flag);
		return flag;
	}
	
	/**
	 * 게시글 등록
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 */
	public int doInsert(BoardVO inVO) throws SQLException {
		int flag = 0;
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");		

		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doInsert";
		flag = sqlSessionTemplate.insert(statement, inVO);
		LOG.debug("flag=" + flag);
		
		return flag;
	}
	
	/**
	 * 게시글 삭제
	 * @param inVO
	 * @return 성공(1)/실패(0)
	 * @throws SQLException
	 */
	public int doDelete(BoardVO inVO) throws SQLException {
		int flag = 0;
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");				
		
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doDelete";
		flag = sqlSessionTemplate.delete(statement,inVO);
		LOG.debug("flag=" + flag);
		return flag;
	}
	
	/**
	 * 단건조회 
	 * @param inVO
	 * @return BoardVO
	 * @throws SQLException
	 */
	public BoardVO doSelectOne(BoardVO inVO) throws SQLException {
		BoardVO  outVO = null;
		LOG.debug("=========================================");
		LOG.debug("param=" + inVO.toString());
		LOG.debug("=========================================");	
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doSelectOne";
		LOG.debug("statement=" + statement);
		LOG.debug("=========================================");
		outVO =sqlSessionTemplate.selectOne(statement, inVO);
		
		LOG.debug("outVO=" + outVO);
		return outVO;
	}
	
	
	
	
	
	
	
	
	
	
	
}
