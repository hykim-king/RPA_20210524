package com.pcwk.ehr.chart.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.pcwk.ehr.chart.domain.ChartVO;
import com.pcwk.ehr.chart.service.ChartService;

@Controller
public class ChartController {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	ChartService chartService;
	
	@RequestMapping(value = "chart/lineChart.do")
	public String lineChart() {
		LOG.debug("===========================");
		LOG.debug("==lineChart()=====");
		LOG.debug("===========================");
		
		return "chart/lineChart";
	}
	
	
	@RequestMapping(value="chart/memberLevelRatio.do",method=RequestMethod.GET, produces = "application/json; charset=UTF-8")
	@ResponseBody
	public String memberLevelRatio() {
		LOG.debug("=========================");
		LOG.debug("=memberLevelRatio=");
		LOG.debug("=========================");
//      [		
//        ['BASIC', 3],
//        ['SILVER', 1],
//        ['GOLD', 1]
//      ]		
		
		List<ChartVO> list = chartService.memberLevelRatio();
		
		JsonArray   jArray=new JsonArray();
		
		for(ChartVO vo :list) {
			JsonArray   sArray=new JsonArray();
			sArray.add(vo.getLevelNm());
			sArray.add(vo.getLevelCnt());
			
			jArray.add(sArray);
		}
		//[
		//  ["BASIC",89999],
		//  ["SILVER",9999],
		//  ["GOLD",1]
		//]
		LOG.debug("=========================");
		LOG.debug("=jArray:"+jArray.toString());
		LOG.debug("=========================");		
		
		
		return jArray.toString();
	}
	
}
