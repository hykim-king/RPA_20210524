package com.pcwk.ehr.board.service;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.SearchVO;
import com.pcwk.ehr.board.dao.BoardDaoImpl;
import com.pcwk.ehr.board.domain.BoardVO;

@Service
public class BoardServiceImpl implements BoardService {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	
	@Autowired
	BoardDaoImpl  boardDaoImple;
	
	
	@Override
	public List<BoardVO> doRetrieve(SearchVO inVO) throws SQLException {
		
		return boardDaoImple.doRetrieve(inVO);
	}

	@Override
	public int doReadCntUpdate(BoardVO inVO) throws SQLException {
		
		return boardDaoImple.doReadCntUpdate(inVO);
	}

	@Override
	public int doUpdate(BoardVO inVO) throws SQLException {
		return boardDaoImple.doUpdate(inVO);
	}

	@Override
	public int doInsert(BoardVO inVO) throws SQLException {
		return boardDaoImple.doInsert(inVO);
	}

	@Override
	public int doDelete(BoardVO inVO) throws SQLException {
		return boardDaoImple.doDelete(inVO);
	}

	@Override
	public BoardVO doSelectOne(BoardVO inVO) throws SQLException {
		BoardVO outVO = boardDaoImple.doSelectOne(inVO);
		if(null !=outVO) {
			boardDaoImple.doReadCntUpdate(inVO);
		}
		return outVO;
	}

}
