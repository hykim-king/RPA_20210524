package com.pcwk.ehr.chart.dao;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.pcwk.ehr.chart.domain.*;
@Repository
public class ChartDaoImpl {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	SqlSessionTemplate  sqlSessionTemplate;
	
	final String NAMESPACE = "com.pcwk.ehr.chart";
	
	public ChartDaoImpl() {}
	
	public List<ChartVO> memberLevelRatio(){
		List<ChartVO> list =new ArrayList<ChartVO>();
		
		String statement  = NAMESPACE + ".memberLevelRatio";
		LOG.debug("==============================");
		LOG.debug("=statement="+statement);
		LOG.debug("==============================");
		
		list = sqlSessionTemplate.selectList(statement);
		for(ChartVO vo  : list) {
			LOG.debug("=vo="+vo);
		}
		
		return list;
	}
	
}
