package com.pcwk.ehr.template;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TemplateController {

	
	
	@RequestMapping(value = "template/listTemplate.do")
	public String listTemplate() {
		
		return "template/board_list_boot";
	}
	
	@RequestMapping(value = "template/regTemplate.do")
	public String regTemplate() {
		
		return "template/board_reg_boot";
	}	
}
   