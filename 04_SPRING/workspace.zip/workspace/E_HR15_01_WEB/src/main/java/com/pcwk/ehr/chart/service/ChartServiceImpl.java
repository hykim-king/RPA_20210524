package com.pcwk.ehr.chart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.chart.dao.ChartDaoImpl;
import com.pcwk.ehr.chart.domain.ChartVO;

@Service
public class ChartServiceImpl implements ChartService {

	
	@Autowired
	ChartDaoImpl chartDaoImpl;
	
	@Override
	public List<ChartVO> memberLevelRatio() {

		return chartDaoImpl.memberLevelRatio();
	}

}
