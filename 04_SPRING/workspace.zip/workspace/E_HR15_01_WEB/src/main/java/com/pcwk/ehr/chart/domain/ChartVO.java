package com.pcwk.ehr.chart.domain;

import com.pcwk.ehr.DTO;

public class ChartVO extends DTO {
	private String levelNm; //레벨명
	private int    levelCnt;//레벨별 인원수
	
	public ChartVO() {}

	public ChartVO(String levelNm, int levelCnt) {
		super();
		this.levelNm = levelNm;
		this.levelCnt = levelCnt;
	}

	/**
	 * @return the levelNm
	 */
	public String getLevelNm() {
		return levelNm;
	}

	/**
	 * @param levelNm the levelNm to set
	 */
	public void setLevelNm(String levelNm) {
		this.levelNm = levelNm;
	}

	/**
	 * @return the levelCnt
	 */
	public int getLevelCnt() {
		return levelCnt;
	}

	/**
	 * @param levelCnt the levelCnt to set
	 */
	public void setLevelCnt(int levelCnt) {
		this.levelCnt = levelCnt;
	}

	@Override
	public String toString() {
		return "ChartVO [levelNm=" + levelNm + ", levelCnt=" + levelCnt + ", toString()=" + super.toString() + "]";
	}
	
	
}
