package com.pcwk.ehr.board.domain;

import com.pcwk.ehr.DTO;

public class BoardVO extends DTO {

	private int    seq;      //순번
	private String title;    //제목
	private String constents;//내용
	private int    readCnt;  //읽은 횟수
	private String regId;    //등록자 아이디
	private String regDt;    //등록일
	
	public BoardVO() {}

	public BoardVO(int seq, String title, String constents, int readCnt, String regId, String regDt) {
		super();
		this.seq = seq;
		this.title = title;
		this.constents = constents;
		this.readCnt = readCnt;
		this.regId = regId;
		this.regDt = regDt;
	}

	/**
	 * @return the seq
	 */
	public int getSeq() {
		return seq;
	}

	/**
	 * @param seq the seq to set
	 */
	public void setSeq(int seq) {
		this.seq = seq;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the constents
	 */
	public String getConstents() {
		return constents;
	}

	/**
	 * @param constents the constents to set
	 */
	public void setConstents(String constents) {
		this.constents = constents;
	}

	/**
	 * @return the readCnt
	 */
	public int getReadCnt() {
		return readCnt;
	}

	/**
	 * @param readCnt the readCnt to set
	 */
	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}

	/**
	 * @return the regId
	 */
	public String getRegId() {
		return regId;
	}

	/**
	 * @param regId the regId to set
	 */
	public void setRegId(String regId) {
		this.regId = regId;
	}

	/**
	 * @return the regDt
	 */
	public String getRegDt() {
		return regDt;
	}

	/**
	 * @param regDt the regDt to set
	 */
	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	@Override
	public String toString() {
		return "BoardVO [seq=" + seq + ", title=" + title + ", constents=" + constents + ", readCnt=" + readCnt
				+ ", regId=" + regId + ", regDt=" + regDt + ", toString()=" + super.toString() + "]";
	}
	
	
	
}
