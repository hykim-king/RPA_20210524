package com.pcwk.ehr.aspectj.around;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pcwk.ehr.aspectj.Member;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/aspectj/around/aspectj-performance-applictionContext.xml")
public class JTestAspectjPerformanceAround {
	final Logger LOG = Logger.getLogger(getClass());
	
	@Autowired
	ApplicationContext context;
	
	@Autowired
	Member member;
	
	
	@Test
	public void aroundAspect() {
		member.doSave();
//	     - Before:^^^^^^^^^^^ 메소드 수행전
//	     - ------------------------
//	      - -doSave()-
//	      - ------------------------
//	     - after:^^^^^^^^^^^ 메소드 수행후
		member.doRetrieve(23);
	              
	}
	
	@Test
	public void beans() {
		assertThat(context, is(notNullValue()));
		assertThat(member, is(notNullValue()));
	}

}
