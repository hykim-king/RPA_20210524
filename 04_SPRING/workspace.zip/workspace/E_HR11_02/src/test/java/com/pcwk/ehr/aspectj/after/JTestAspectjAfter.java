package com.pcwk.ehr.aspectj.after;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.pcwk.ehr.aspectj.Member;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/aspectj/after/aspectj-after-applictionContext.xml")
public class JTestAspectjAfter {
    final Logger LOG = Logger.getLogger(getClass());
    
	@Autowired
	ApplicationContext applicationContext;
	
	@Autowired
	Member member;
	
	@Test
	public void beansAfter() {
		member.doSave();
		member.doUpdate();
		member.delete();
	}
	
	@Test
	public void beans() {
		LOG.debug("==========================");
		LOG.debug("=applicationContext="+applicationContext);
		LOG.debug("==========================");
		
		assertThat(applicationContext, is(notNullValue()) );
		assertThat(member, is(notNullValue()) );
	}

}
