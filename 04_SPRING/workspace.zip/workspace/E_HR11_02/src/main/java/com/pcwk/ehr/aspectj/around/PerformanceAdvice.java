package com.pcwk.ehr.aspectj.around;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.util.StopWatch;

import com.pcwk.ehr.DTO;

public class PerformanceAdvice {
	final Logger LOG = Logger.getLogger(getClass());
	PerformanceDao performanceDao;
	
	public PerformanceAdvice() {}
	
	public void setPerformanceDao(PerformanceDao performanceDao) {
		this.performanceDao = performanceDao;
	}

	public Object performanceLog(ProceedingJoinPoint pjp) throws Throwable {
		Signature signature  = pjp.getSignature();
		String className = pjp.getTarget().getClass().toString();//클래스
		String methodName= signature.getName();//메서드
		
		//시작시간
		StopWatch  stopWatch=new StopWatch();
		stopWatch.start();
		//성능측정:시퀀스,클래스.메서드,수행시간,param,등록일
		//param
		Object[] args = pjp.getArgs();
		Object   paramObj = new Object();
		
		for(Object obj:args) {
			LOG.debug("param : "+obj);
			if(paramObj instanceof DTO) {
			  paramObj = obj;
			}
		}
		
		Object obj = pjp.proceed();
		
		//종료시간
		stopWatch.stop();
		LOG.debug(className+"."+methodName+":수행시간"+stopWatch.getTotalTimeMillis());
		//TODO: 성능측정 DAO
		PerformVO   vo =new PerformVO();
		vo.setPacMethod(className+"."+methodName);
		vo.setParam(paramObj.toString());
		vo.setRunTime(stopWatch.getTotalTimeMillis());
		
		int flag = performanceDao.doInsert(vo);
		LOG.debug("flag:"+flag);
		
		return obj;
		
	}
	
}






