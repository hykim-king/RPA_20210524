package com.pcwk.ehr.aspectj.around;

import com.pcwk.ehr.DTO;

public class PerformVO extends DTO {
	private int seq;          //순번
	private String pacMethod; //패키기+클래스+메서드
	private String param;     //전달인자
	private long    runTime;   //수행시간
	private String regDt;     //등록일
	
	public PerformVO() {}

	public PerformVO(int seq, String pacMethod, String param, long runTime, String regDt) {
		super();
		this.seq = seq;
		this.pacMethod = pacMethod;
		this.param = param;
		this.runTime = runTime;
		this.regDt = regDt;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getPacMethod() {
		return pacMethod;
	}

	public void setPacMethod(String pacMethod) {
		this.pacMethod = pacMethod;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public long getRunTime() {
		return runTime;
	}

	public void setRunTime(long runTime) {
		this.runTime = runTime;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}

	@Override
	public String toString() {
		return "PerformVO [seq=" + seq + ", pacMethod=" + pacMethod + ", param=" + param + ", runTime=" + runTime
				+ ", regDt=" + regDt + ", toString()=" + super.toString() + "]";
	}
	
	
	
	
}
