package com.pcwk.ehr.aspectj.around;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
/**
 * 클라이언트 메소드 호출을 가로챈다.
 * 클라이언트가 호출한 비즈니스 메소드 실행 전,후에 수행.
 * 전수행 내용
 *   비즈니스 메소드
 * 후수행 내용
 * @author HKEDU
 *
 */
public class AroundAdvice {
	final Logger LOG = Logger.getLogger(getClass());
	
	public Object aroundLog(ProceedingJoinPoint pjp)throws Throwable{
		LOG.debug("Before:^^^^^^^^^^^ 메소드 수행전");
		
		
		
		LOG.debug("클래스 : "+pjp.getTarget().getClass());
		//메서드
		Signature  signature  = pjp.getSignature();
		LOG.debug("메서드 : "+signature.getName());
		
		//param
		Object[] args = pjp.getArgs();
		for(Object obj:args) {
			LOG.debug("param : "+obj);
		}
		
		
		Object returnObj = pjp.proceed();
		LOG.debug("after:^^^^^^^^^^^ 메소드 수행후");
		
		return returnObj;
	}
}







