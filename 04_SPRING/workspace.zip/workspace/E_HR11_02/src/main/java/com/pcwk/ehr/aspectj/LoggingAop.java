package com.pcwk.ehr.aspectj;

import org.apache.log4j.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
public class LoggingAop {
	
	final Logger LOG = Logger.getLogger(getClass());
	
	//JoinPoint : method paran, 메소드정보
	public void logging(JoinPoint joinPoint) {
		Signature signature=joinPoint.getSignature();
		
		//메소드 이름
		String methodName = signature.getName();
		LOG.debug("+++++++++++++++++++++++++++++++");
		LOG.debug("+methodName+"+methodName);
		LOG.debug("+++++++++++++++++++++++++++++++");
	}

}
