package com.pcwk.ehr.aspectj;

import org.apache.log4j.Logger;

public class MemberImpl implements Member {
    final Logger  LOG = Logger.getLogger(getClass());
    
	public int doSave() {
		LOG.debug("------------------------");
		LOG.debug("-doSave()-");
		LOG.debug("------------------------");
		return 0;
	}

	public int doUpdate() {
		LOG.debug("------------------------");
		LOG.debug("-doUpdate()-");
		LOG.debug("------------------------");
		return 0;
	}

	public int delete() {
		LOG.debug("------------------------");
		LOG.debug("-delete()-");
		LOG.debug("------------------------");
		return 0;
	}

	public void doRetrieve(int age) {
		for(int i=0;i<Integer.MAX_VALUE;i++) {
			for(int j=0;j<Integer.MAX_VALUE;j++) {
				
			}
		}
		LOG.debug("------------------------");
		LOG.debug("-doRetrieve()-");
		LOG.debug("------------------------");

	}

}
