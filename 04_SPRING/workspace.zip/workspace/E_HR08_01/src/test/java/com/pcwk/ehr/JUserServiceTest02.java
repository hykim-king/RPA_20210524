package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//메소드 수행 순서: method ASCENDING ex)a~z
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class) //JUnit기능 스프링 프레임으로 확장
@ContextConfiguration(locations = "/applicationContext.xml") ///applicationContext.xml 설정파일 read
public class JUserServiceTest02 {
	final Logger LOG = Logger.getLogger(getClass());
	
	@Autowired
	UserService  userService;
	
	@Autowired
	UserDao     userDao;
	List<UserVO> list;
	
	@Before
	public void setUp() throws Exception {
		LOG.debug("====setUp()======");
		list = Arrays.asList(
				new UserVO("pcwk_01", "이상무01", "1234_1",Level.BASIC,49,0)//BASIC
			   ,new UserVO("pcwk_02", "이상무02", "1234_2",Level.BASIC,50,10)//BASIC - > SILVER
			   ,new UserVO("pcwk_03", "이상무03", "1234_3",Level.SILVER,51,29)//SILVER 
			   ,new UserVO("pcwk_04", "이상무04", "1234_4",Level.SILVER,51,30)//SILVER - > GOLD
			   ,new UserVO("pcwk_05", "이상무05", "1234_5",Level.GOLD,52,32)//GOLD
				);
	}

	@After
	public void tearDown() throws Exception {
	}

    @Test
    //@Ignore
	public void upgradeLevels() throws SQLException, ClassNotFoundException {
		//1. 전체삭제
    	//2. list 데이터 입력(5건)
    	int flag = 0;
    	
    	//1.
    	userDao.deleteAll();
    	
    	//2.
    	for(UserVO vo :list){
    		flag+=userDao.doInsert(vo);
    	}
    	
    	assertThat(flag, is(5));
    	
    	
    	this.userService.upgradeLevels();
    	
    	checkLevel(list.get(0),Level.BASIC);
    	checkLevel(list.get(1),Level.SILVER);
    	checkLevel(list.get(2),Level.SILVER);
    	checkLevel(list.get(3),Level.GOLD);
    	checkLevel(list.get(4),Level.GOLD);
    	
	}
	
    private void checkLevel(UserVO user, Level expectedLevel) throws ClassNotFoundException, SQLException {
    	UserVO upDateUser = this.userDao.doSelectOne(user);
    	assertThat(upDateUser.getLevel(), is(expectedLevel));
    }
    
    
	
	
	@Test
	public void bean() {
		LOG.debug("==============================");
		LOG.debug("=userService="+userService);
		LOG.debug("=userDao="+userDao);
		LOG.debug("==============================");
		assertThat(userService, is(notNullValue()));
		assertThat(userDao, is(notNullValue()));
	}

}
