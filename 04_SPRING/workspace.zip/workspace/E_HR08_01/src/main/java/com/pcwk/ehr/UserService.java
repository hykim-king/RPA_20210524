package com.pcwk.ehr;

import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

public class UserService {

	final Logger LOG = Logger.getLogger(getClass());
	
	UserDao userDao;
	
	public UserService() {}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	
	//등업
	/**
	 * 1.전 회원을 조회 한다.
	 *  1.1.전 회원준 1건을 추출한다.
	 *   1.2.회원이 등업 대상인지 확인 한다.
	 *    BASIC  -> SILVER : 50회 이상 로그인
	 *    SILVER -> GOLD   : 30회 이상 추천 
	 *    GOID   ->        : 대상 아님
	 *   1.3. 등업한다.
	 * @throws SQLException 
	 */
	public void upgradeLevels() throws SQLException {
		//1.
		List<UserVO>  list = userDao.getAll();
		
		//1.1.
		for(UserVO user :list) {
			boolean changedLevel = false;
			
			LOG.debug(user);
			//1.2.
			if(user.getLevel() == Level.BASIC  && user.getLogin() >=50) {
				changedLevel = true;
				user.setLevel(Level.SILVER);
				
			}else if(user.getLevel() == Level.SILVER && user.getRecommend() >=30) {
				changedLevel = true;
				user.setLevel(Level.GOLD);
			}else if(user.getLevel() == Level.GOLD) {
				changedLevel = false;
				
			}else {
				changedLevel = false;
				
			}
			
			
			if(changedLevel==true) {
				userDao.doUpdate(user);
			}
		}
		
		
		
		
	}
	
	
}














