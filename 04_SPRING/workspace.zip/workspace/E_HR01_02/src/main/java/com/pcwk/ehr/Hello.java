package com.pcwk.ehr;
import org.apache.log4j.*;
public class Hello {
    final static Logger LOG = Logger.getLogger(Hello.class);
	public static void main(String[] args) {
		LOG.debug("Hello,world.");

	}

}
