package com.pcwk.ehr;

public class MessageVO extends DTO {
	private String msgId;
	private String msgContents;
	
	
	public MessageVO() {}


	public MessageVO(String msgId, String msgContents) {
		super();
		this.msgId = msgId;
		this.msgContents = msgContents;
	}


	/**
	 * @return the msgId
	 */
	public String getMsgId() {
		return msgId;
	}


	/**
	 * @param msgId the msgId to set
	 */
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}


	/**
	 * @return the msgContents
	 */
	public String getMsgContents() {
		return msgContents;
	}


	/**
	 * @param msgContents the msgContents to set
	 */
	public void setMsgContents(String msgContents) {
		this.msgContents = msgContents;
	}


	@Override
	public String toString() {
		return "MessageVO [msgId=" + msgId + ", msgContents=" + msgContents + ", toString()=" + super.toString() + "]";
	}
	
	
	
}
