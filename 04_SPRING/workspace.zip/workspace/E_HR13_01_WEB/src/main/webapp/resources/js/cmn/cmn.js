/**
 *  
 */
 
 //프로젝트 이름
 const  CP = "/PCWK_MVC/resources";