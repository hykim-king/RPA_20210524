--paging
SELECT A.*,B.*
FROM(
    SELECT t2.rnum,
           t2.u_id,
           t2.name,
           t2.u_level,
           t2.login,
           t2.recommend,
           t2.email,
           --�����̸� �ú�, �����
           DECODE( TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(t2.reg_dt,'YYYYMMDD')
                                              ,TO_CHAR(t2.reg_dt,'HH24:MI')
                                              ,TO_CHAR(t2.reg_dt,'YYYY/MM/DD') ) reg_dt
    FROM(
        SELECT rownum rnum,t1.*
        FROM(
            SELECT *
            FROM hr_member
            --WHERE����
            ORDER BY reg_dt desc
        )t1
    )t2
    WHERE rnum BETWEEN 21 AND 30
    )A
    CROSS JOIN
    (
    SELECT COUNT(*) total_cnt
    FROM hr_member
    --WHERE����
    )B
;



--ITAS 100000
DELETE FROM hr_member;
commit;

INSERT INTO hr_member
SELECT 'j_hr'||lpad(rownum,7,'0')
       ,'�̻�' || lpad(rownum,7,'0')
       ,'1234'
       ,DECODE(MOD(rownum,10),0,'2','1')
       ,MOD(rownum,50)
       ,MOD(rownum,20)
       ,'james'||lpad(rownum,7,'0')||'@daum.net'
       ,(SYSDATE -ROWNUM/(60*60))
FROM dual
CONNECT BY LEVEL < =100000
;
commit;
SELECT COUNT(*) FROM hr_member;

