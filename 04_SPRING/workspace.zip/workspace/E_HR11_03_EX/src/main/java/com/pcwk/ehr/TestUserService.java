package com.pcwk.ehr;

import java.sql.SQLException;

import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserServiceImpl;

public class TestUserService extends UserServiceImpl {
	private String uId;
	
	public TestUserService() {
		
	}

	public TestUserService(String uId) {
		super();
		this.uId = uId;
	}

	//UserService의 upgradeLevel 오버라이드
	@Override
	protected void upgradeLevel(UserVO user) throws SQLException,TestUserServiceException {
		if(user.getuId().equals(this.uId) ) {
			throw new TestUserServiceException(uId);
		}
		
		super.upgradeLevel(user);
		
	}


	
	
}
