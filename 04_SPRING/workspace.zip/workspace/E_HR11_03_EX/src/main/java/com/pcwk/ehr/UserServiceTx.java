package com.pcwk.ehr;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserService;

public class UserServiceTx implements UserService {
    private final Logger LOG = Logger.getLogger(getClass());
    
	UserService userService;
	//Transaction
	private PlatformTransactionManager transactionManager;
	
	public UserServiceTx() {}
	
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void setTransactionManager(PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	public int add(UserVO user) throws ClassNotFoundException, SQLException {

		return userService.add(user);
	}

	public void upgradeLevels() throws Exception {
		// -----------------------------------------------
		// 트랜잭션 동기화
		// -----------------------------------------------
		TransactionStatus status = transactionManager.getTransaction(new DefaultTransactionDefinition());
		try {
			userService.upgradeLevels();
			transactionManager.commit(status);
		}catch(RuntimeException e) {
			LOG.debug("-------------------------------");
			LOG.debug("-rollback--"+e);
			LOG.debug("-------------------------------");			
			transactionManager.rollback(status);
		}
	}

}
