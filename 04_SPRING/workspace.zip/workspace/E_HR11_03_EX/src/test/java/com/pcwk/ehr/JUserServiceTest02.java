package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.notNullValue;
import static com.pcwk.ehr.member.service.UserServiceImpl.MIN_LOGCOUNT_FOR_SILVER;
import static com.pcwk.ehr.member.service.UserServiceImpl.MIN_RECCOMEND_FOR_GOLD;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.mail.MailSender;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.pcwk.ehr.member.dao.UserDao;
import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserServiceImpl;

//메소드 수행 순서: method ASCENDING ex)a~z
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class) // JUnit기능 스프링 프레임으로 확장
@ContextConfiguration(locations = "/applicationContext.xml") /// applicationContext.xml 설정파일 read
public class JUserServiceTest02 {
	final Logger LOG = Logger.getLogger(getClass());

	@Autowired
	UserServiceImpl userServiceImpl;

	@Autowired
	UserDao userDao;
	List<UserVO> list;

	@Autowired
	DataSource dataSource;

	@Autowired
	@Qualifier("dummyMailSender")
	MailSender mailSender;
	
	@Autowired
	PlatformTransactionManager  transactionManager;
	
	@Before
	public void setUp() throws Exception {
		LOG.debug("====setUp()======");
		list = Arrays.asList(new UserVO("pcwk_01", "이상무01", "1234_1", Level.BASIC, MIN_LOGCOUNT_FOR_SILVER - 1, 0,"jamesol@naver.com","")// BASIC
				, new UserVO("pcwk_02", "이상무02", "1234_2", Level.BASIC, MIN_LOGCOUNT_FOR_SILVER, 10,"jamesol@naver.com","")// BASIC - > SILVER
				, new UserVO("pcwk_03", "이상무03", "1234_3", Level.SILVER, MIN_LOGCOUNT_FOR_SILVER + 1, 29,"jamesol@naver.com","")// SILVER
				, new UserVO("pcwk_04", "이상무04", "1234_4", Level.SILVER, 51, MIN_RECCOMEND_FOR_GOLD,"jamesol@naver.com","")// SILVER - > GOLD
				, new UserVO("pcwk_05", "이상무05", "1234_5", Level.GOLD, 52, MIN_RECCOMEND_FOR_GOLD + 2,"jamesol@naver.com","")// GOLD
		);
	}

	// TransactionTest
	@Test
	public void allOrNothing() throws SQLException, ClassNotFoundException {
//		등업 대상자 2번째, 4번재가 있음, 이중 4번째에서 예외 발생																
//		하면 2번째가 rollback 확인.																
		int flag = 0;
		// 4번째 사용자에게서 예외 발생.
		TestUserService testUserService = new TestUserService(list.get(3).getuId());
		testUserService.setUserDao(userDao);// 수동으로 DI
		testUserService.setDataSource(dataSource);
		testUserService.setMailSender(mailSender);//mailSender 수동으로 DI
		

		UserServiceTx  userServiceTx=new UserServiceTx();
		userServiceTx.setUserService(testUserService);
		userServiceTx.setTransactionManager(transactionManager);
		// 1. 전체 삭제
		// 2. 전체 추가
		// 3. 등업
		   
		try {
			// 1.
			this.userDao.deleteAll();
			// 2.
			for (UserVO vo : list) {
				flag += userDao.doInsert(vo);
			}
			assertThat(flag, is(5));
			userServiceTx.upgradeLevels();
			
		} catch (Exception e) {
			LOG.debug("----------------------------");
			LOG.debug("----------------------------" + e.getMessage());
			LOG.debug("----------------------------");
		}

		// 예외가 발생하기 전에 레벨 변경이 있었던 사용자
		// Rollback
		checkLevel(list.get(1), false);
	}

	@Test
	//@Ignore
	public void add() throws SQLException, ClassNotFoundException {
		// *. Level이 null이면 : Level.BASIC
		// *. Level이 있는 경우는 : 해당 Level로 등록

		// 1. 기존 데이터 삭제

		// 2. Level이 null
		// 2.1. Level이 있는 경우
		// 2.2. 데이터 입력
		// 3. 입력데이터 조회
		// 4. 비교

		int flag = 0;

		// 1.
		for (UserVO vo : list) {
			this.userDao.doDelete(vo);
		}

		// 2.
		UserVO userWithLevel = list.get(4);// GOLD
		UserVO userWithOutLevel = list.get(0);// BASIC -> NULL
		userWithOutLevel.setLevel(null);

		flag = this.userServiceImpl.add(userWithLevel);
		assertThat(flag, is(1));
		flag = this.userServiceImpl.add(userWithOutLevel);
		assertThat(flag, is(1));

		// userWithLevel -> GOLD
		// userWithOutLevel -> BASIC
		UserVO userWithLevelRead = this.userDao.doSelectOne(userWithLevel);
		assertThat(userWithLevelRead.getLevel(), is(Level.GOLD));

		UserVO userWithoutLevelRead = this.userDao.doSelectOne(userWithOutLevel);

		assertThat(userWithoutLevelRead.getLevel(), is(Level.BASIC));

	}

	@Test
	//@Ignore
	public void upgradeLevels() throws Exception {
		// 1. 전체삭제
		// 2. list 데이터 입력(5건)
		int flag = 0;

		// 1.
		userDao.deleteAll();

		// 2.
		for (UserVO vo : list) {
			flag += userDao.doInsert(vo);
		}

		assertThat(flag, is(5));

		this.userServiceImpl.upgradeLevels();

		checkLevel(list.get(0), false);
		checkLevel(list.get(1), true);
		checkLevel(list.get(2), false);
		checkLevel(list.get(3), true);
		checkLevel(list.get(4), false);

	}

	/**
	 * true가 전달되면 등업
	 * 
	 * @param user
	 * @param upgraded
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private void checkLevel(UserVO user, boolean upgraded) throws ClassNotFoundException, SQLException {
		UserVO upDateUser = this.userDao.doSelectOne(user);

		// 등업되면 -> nextLevel
		if (upgraded) {
			assertThat(upDateUser.getLevel(), is(user.getLevel().nextLevel()));
			// 그렇치 않으면 -> 현재 Level로
		} else {
			assertThat(upDateUser.getLevel(), is(user.getLevel()));
		}

	}

	@Test
	public void bean() {
		LOG.debug("==============================");
		LOG.debug("=userService=" + userServiceImpl);
		LOG.debug("=userDao=" + userDao);
		LOG.debug("=dataSource=" + dataSource);
		LOG.debug("=mailSender=" + mailSender);
		LOG.debug("=transactionManager=" + transactionManager);
		
		LOG.debug("==============================");
		assertThat(userServiceImpl, is(notNullValue()));
		assertThat(userDao, is(notNullValue()));
		assertThat(dataSource, is(notNullValue()));
		assertThat(mailSender, is(notNullValue()));
		assertThat(transactionManager, is(notNullValue()));
	}

}
