package com.pcwk.ehr;

import org.apache.log4j.Logger;

public class SonySpeaker {

	
	final Logger  LOG = Logger.getLogger(getClass());
	
	public SonySpeaker() {
		LOG.debug("=====================");
		LOG.debug("=SonySpeaker()=");
		LOG.debug("=====================");
	}
	
	
	public void volumeUp() {
		LOG.debug("=====================");
		LOG.debug("=volumeUp()=");
		LOG.debug("=====================");		
	}
	
	public void volumeDown() {
		LOG.debug("=====================");
		LOG.debug("=volumeDown()=");
		LOG.debug("=====================");			
	}
	
}
