package com.pcwk.ehr;

public class SamsungTv implements Tv {

	private String brandNm = "SAMSUNG";
	private int price;
	
	private SonySpeaker speaker;
	//Constructor Injection

	
	public SamsungTv() {
		LOG.debug("============================");
		LOG.debug("=SamsungTv()=");
		LOG.debug("============================");		
	}
	
	
	
	
	
	public SamsungTv(int price, SonySpeaker speaker) {
		super();
		this.price = price;
		this.speaker = speaker;
		LOG.debug("============================");
		LOG.debug("=public SamsungTv(int price, SonySpeaker speaker)=");
		LOG.debug("=price="+price);
		LOG.debug("=speaker="+speaker);
		LOG.debug("============================");			
	}





	public void powerOn() {
		LOG.debug("============================");
		LOG.debug("=powerOn()=");
		LOG.debug("============================");

	}

	public void powerOff() {
		LOG.debug("============================");
		LOG.debug("=powerOff()=");
		LOG.debug("============================");

	}

	public void volumeUp() {
		speaker.volumeUp();

	}

	public void volumeDown() {
		speaker.volumeDown();

	}

}
