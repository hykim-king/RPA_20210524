package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.Test;

public class JTest01 {
    final Logger LOG = Logger.getLogger(getClass());
    
    
	@Test
	public void test() {
		LOG.debug("-----------------------");
		LOG.debug("-test()--");
		LOG.debug("-----------------------");
	}

	@Test
	public void test02() {
		LOG.debug("-----------------------");
		LOG.debug("-test02()--");
		LOG.debug("-----------------------");	
		
		//실패 케이스
		//assertThat(1, is(0));
	}
	
}
