package com.pcwk.ehr;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class JTest03LifeCycle {
	final Logger LOG = Logger.getLogger(getClass());
	
	
	@Before
	public void setUp() throws Exception {
		LOG.debug("---------------------");
		LOG.debug("@Before()");
		LOG.debug("---------------------");
	}

	@After
	public void tearDown() throws Exception {
		LOG.debug("---------------------");
		LOG.debug("@After()");
		LOG.debug("---------------------");		
	}

	@Test
	public void aTtest() {
		LOG.debug("---------------------");
		LOG.debug("aTtest()");
		LOG.debug("---------------------");	
	}
	@Test
	public void zTtest() {
		LOG.debug("---------------------");
		LOG.debug("zTtest()");
		LOG.debug("---------------------");	
	}
}
