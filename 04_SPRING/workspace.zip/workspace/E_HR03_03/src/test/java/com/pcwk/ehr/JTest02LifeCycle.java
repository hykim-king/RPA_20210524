package com.pcwk.ehr;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import junit.framework.TestCase;

public class JTest02LifeCycle {
    final Logger LOG = Logger.getLogger(getClass());
    
    @Before
	public void setUp() throws Exception {
    	LOG.debug("===========================");
    	LOG.debug("=@Before=");
    	LOG.debug("===========================");
	}

    @After
    public void tearDown() throws Exception {
    	LOG.debug("===========================");
    	LOG.debug("=@After=");
    	LOG.debug("===========================");
	}
    
    @Test
    public void aTest01() {
    	LOG.debug("***************************");
    	LOG.debug("=test01()=");
    	LOG.debug("***************************");
    }
    
    @Test
    public void zTest02() {
    	LOG.debug("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
    	LOG.debug("=test02()=");
    	LOG.debug("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
    }    

}
