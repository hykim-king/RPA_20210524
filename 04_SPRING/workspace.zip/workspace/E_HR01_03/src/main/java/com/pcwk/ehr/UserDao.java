package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDao {
    final static Logger LOG = Logger.getLogger(UserDao.class);
    
    
	public static void main(String[] args) {
		UserDao  dao=new UserDao();
		UserVO   user=new UserVO("pcwk_01", "이상무01", "1234");
		
		try {
			//등록
			int flag =dao.add(user);
			if(1==flag) {
				LOG.debug("=========================");
				LOG.debug("=등록성공=");
				LOG.debug("=========================");
			}
			
			//한건 조회
			UserVO outVO = dao.get(user);
			if(outVO.getuId().equals(user.getuId())
			&& outVO.getName().equals(user.getName())
			&& outVO.getPasswd().equals(user.getPasswd()) 
			  ) {
				LOG.debug("=========================");
				LOG.debug("=단건조회 성공=");
				LOG.debug("=========================");				
			}
				
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 사용자 조회
	 * @param inVO
	 * @return UserVO
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public UserVO get(UserVO inVO) throws ClassNotFoundException, SQLException {
		UserVO outVO = null;
		//1.DB연결에 대한 관심 사항.
		//2.DB에 보낼 SQL문장 작성, PreparedStatement생성하고 실행.
		//3. 자원반납
		
		//1.
		Connection con = getConnection();
		
		//2.
		StringBuilder sb=new StringBuilder(50);
		sb.append(" SELECT u_id,	\n"); 
		sb.append("        name,    \n");
		sb.append(" 	   passwd   \n");
		sb.append(" FROM hr_member  \n");
		sb.append(" WHERE u_id = ?  \n");
		LOG.debug("=========================================");
		LOG.debug("sql=\n"+sb.toString());
		LOG.debug("param="+inVO.toString());
		LOG.debug("=========================================");
		
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		pstmt.setString(1, inVO.getuId());
		
		ResultSet rs = pstmt.executeQuery();
		
		if(rs.next()) {
			outVO = new UserVO();
			
			outVO.setuId(rs.getString("u_id"));
			outVO.setName(rs.getString("name"));
			outVO.setPasswd(rs.getString("passwd"));
		}
		LOG.debug("=========================================");
		LOG.debug("outVO=\n"+outVO.toString());		
		LOG.debug("=========================================");
		
		
		//3.
		rs.close();
		pstmt.close();
		con.close();
		
		return outVO;
	}
	
	
	/**
	 * 사용자 등록
	 * @param inVO
	 * @return :성공(1)/실패(0)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int add(UserVO inVO) throws ClassNotFoundException, SQLException {
		int flag = 0;
		//1. DB연결을 위한 Connection
		//2. SQL을 담은 Statement, PreparedStatement
		//3. PreparedStatement를 수행
		//4. 조회의 경우 ResultSet으로  정보를 받아와 User Object에 저장
		//5. 자원 반납 Connection,PreparedStatement,ResultSet close()
		//* 예외가 발생하면 예외는 밖으로 throw한다.
		
		//1.DB연결에 대한 관심 사항.
		Connection con = getConnection();
		
		//2.DB에 보낼 SQL문장 작성, PreparedStatement생성하고 실행.
		StringBuilder sb=new StringBuilder();
		sb.append(" INSERT INTO HR_MEMBER ( u_id,name,passwd ) \n");
		sb.append(" VALUES (?,?,?)                             \n");
		LOG.debug("=========================================");
		LOG.debug("sql=\n"+sb.toString());
		LOG.debug("param="+inVO.toString());
		LOG.debug("=========================================");
		
		PreparedStatement pstmt = con.prepareStatement(sb.toString());
		pstmt.setString(1, inVO.getuId());
		pstmt.setString(2, inVO.getName());
		pstmt.setString(3, inVO.getPasswd());
		 
		flag = pstmt.executeUpdate();
		LOG.debug("=========================================");
		LOG.debug("flag="+flag);
		LOG.debug("=========================================");		
		
		//3. 자원반납
		pstmt.close();
		con.close();
		
		return flag;
	}

	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Connection connection = null;//Oracle DB connection
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//
		final String DB_URL ="jdbc:oracle:thin:@192.168.3.100:1521:xe";
		//final String DB_URL ="jdbc:oracle:thin:@localhost:1521:xe";
		final String USER_ID ="SPRING_PCWK";
		final String USER_PASS ="PCWK1234";
		
		connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("=========================================");
		LOG.debug("=connection="+connection);
		LOG.debug("=========================================");
		return connection;
	}
	
	
	
}
