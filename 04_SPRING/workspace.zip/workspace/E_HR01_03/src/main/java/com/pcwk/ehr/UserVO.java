package com.pcwk.ehr;

public class UserVO {
										
	private String uId; //사용자 ID 													
	private String name; //사용자 이름 													
	private String passwd;//비밀번호													

	//default 생성자
	public UserVO() {}

	public UserVO(String uId, String name, String passwd) {
		super();
		this.uId = uId;
		this.name = name;
		this.passwd = passwd;
	}

	@Override
	public String toString() {
		return "UserVO [uId=" + uId + ", name=" + name + ", passwd=" + passwd + "]";
	}

	public String getuId() {
		return uId;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	
	

}
