package com.pcwk.ehr;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SingleTonRegistry {
    final static Logger  LOG = Logger.getLogger(SingleTonRegistry.class);
	public static void main(String[] args) {
		DaoFactory faoFactory=new DaoFactory();
		UserDao  dao01=faoFactory.userDao();
		UserDao  dao02=faoFactory.userDao();
		LOG.debug("============================");
		LOG.debug("=dao01="+dao01);
		LOG.debug("=dao02="+dao02);
		LOG.debug("============================");		
        System.out.println();
		ApplicationContext context = new AnnotationConfigApplicationContext(DaoFactory.class);
		//1. 종합 IoC 서비스를 제공.(SingleTone)
		// 오브젝트의 생성, 관계설정, 자동생성, 후처리, 정보의 조함
		
		//2. 빈을 검색하는 다양한 방법을 제공.
		//getBean()
		LOG.debug("============================");
		LOG.debug("=context="+context);
		LOG.debug("============================");
		
		
		UserDao dao03 = context.getBean("userDao", UserDao.class);
		UserDao dao04 = context.getBean("userDao", UserDao.class);
		LOG.debug("============================");
		LOG.debug("=dao03="+dao03);//=dao03=com.pcwk.ehr.UserDao@78b729e6
		LOG.debug("=dao04="+dao04);//=dao04=com.pcwk.ehr.UserDao@78b729e6
		LOG.debug("============================");		
	}

}

