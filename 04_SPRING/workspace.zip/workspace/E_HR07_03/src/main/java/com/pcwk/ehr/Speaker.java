package com.pcwk.ehr;

public interface Speaker {

	void volumeUp();

	void volumeDown();

}