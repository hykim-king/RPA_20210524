package com.pcwk.ehr;

import org.apache.log4j.Logger;

public class AppleSpeaker implements Speaker {

	final Logger LOG = Logger.getLogger(getClass());
	
	public AppleSpeaker() {
		LOG.debug("=====================");
		LOG.debug("=AppleSpeaker()=");
		LOG.debug("=====================");		
	}
	
	public void volumeUp() {
		LOG.debug("=====================");
		LOG.debug("=volumeUp()=");
		LOG.debug("=====================");	

	}

	public void volumeDown() {
		LOG.debug("=====================");
		LOG.debug("=volumeDown()=");
		LOG.debug("=====================");	

	}

}
