package com.pcwk.ehr;

import org.apache.log4j.Logger;

public class TestUserServiceException extends RuntimeException {
	final Logger LOG = Logger.getLogger(getClass());
	
	public TestUserServiceException() {}
	
	public TestUserServiceException(String msg) {
		super(msg);		
		LOG.debug("+++++++++++++++++++++++++++++++++++");
		LOG.debug("+TestUserServiceException:"+msg);
		LOG.debug("+++++++++++++++++++++++++++++++++++");

		
	}
	
	
}
