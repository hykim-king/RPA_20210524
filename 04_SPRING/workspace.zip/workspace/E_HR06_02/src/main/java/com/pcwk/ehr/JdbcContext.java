package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class JdbcContext {
	final Logger LOG = Logger.getLogger(getClass());
	
	private DataSource  dataSource;
	
	public JdbcContext() {}
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public int workWidthStatementStrategy(StatementStrategy stmt) throws SQLException {
		int flag = 0;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			// 1.DB연결에 대한 관심 사항.
			con = dataSource.getConnection();

			pstmt = stmt.makeStatement(con);

			flag = pstmt.executeUpdate();
			LOG.debug("=========================================");
			LOG.debug("flag=" + flag);
			LOG.debug("=========================================");

		} catch (SQLException e) {
			LOG.debug("=========================================");
			LOG.debug("SQLException=" + e.getMessage());
			LOG.debug("=========================================");
			throw e;
		} finally {
			// 3. 자원반납
			if (null != pstmt) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (null != con) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return flag;
	}

}
