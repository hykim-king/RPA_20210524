package com.pcwk.ehr;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class UserDaoTest {

	final static Logger LOG = Logger.getLogger(UserDaoTest.class);

	public static void main(String[] args) {
		
		//ApplicationContext context = new AnnotationConfigApplicationContext(DaoFactory.class);
		ApplicationContext context =new GenericXmlApplicationContext("/applicationContext.xml");
		UserDao dao=context.getBean("userDao", UserDao.class);
		
		
		UserVO user = new UserVO("pcwk_01", "이상무01", "1234");

		try {
			// 등록
			int flag = dao.add(user);
			if (1 == flag) {
				LOG.debug("=========================");
				LOG.debug("=등록성공=");
				LOG.debug("=========================");
			}

			// 한건 조회
			UserVO outVO = dao.get(user);
			if (outVO.getuId().equals(user.getuId()) && outVO.getName().equals(user.getName())
					&& outVO.getPasswd().equals(user.getPasswd())) {
				LOG.debug("=========================");
				LOG.debug("=단건조회 성공=");
				LOG.debug("=========================");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
