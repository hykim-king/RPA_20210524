package com.pcwk.ehr;


/**
 * DaoFactory 역할은 객체의 생성 방법을 결정하고 
 * 그렇게 만들어진 오브젝트를 돌려준다.
 * 
 * 제어의 역전이란 제어 흐름의 개념을 꺼꾸로 뒤집는 것이다.
 * 제어의 역전에서는 오브젝트가 자신이 사용할 오브젝트를 스스로 선택하지 않는다.
 * 당연히 생성하지도 않는다. 모든 제어 권한을 자신이 아닌 다른 대상에게 위임한다.
 * @author sist
 *
 */
public class DaoFactory {

	public UserDao userDao() {
		
		UserDao dao=new UserDao(connectionMaker());
		
		return dao;
	}
	
//	public BoardDao userDao() {
//		BoardDao boardDao=new BoardDao(connectionMaker());
//		
//		return boardDao;
//	}	
	
	public ConnectionMaker connectionMaker() {
		return new NConnectionMaker();
	}
	
	
}
