package com.pcwk.ehr;

import org.apache.log4j.Logger;

public interface Tv {

	final static Logger LOG = Logger.getLogger(Tv.class);
	
	public void powerOn();
	
	public void powerOff();
	
	public void volumeUp();
	
	public void volumeDown();
	
}
