package com.pcwk.ehr;

public class LgTv implements Tv {

	private String brandNm ="LG";
	
	private int price;
	
	//bean생성시 필수
	public LgTv() {
		LOG.debug("============================");
		LOG.debug("=LgTv()=");
		LOG.debug("============================");		
	}
	
	//초기화,default생성사 다음 호출
	public void initMethod() {
		
		LOG.debug("============================");
		LOG.debug("=객체초기화:initMethod()=");
		LOG.debug("============================");		
	}
	
	
	public void destroyMethod() {
		LOG.debug("============================");
		LOG.debug("=bean factory shutdown:destroyMethod()=");
		LOG.debug("============================");			
	}
	
	
	public void powerOn() {
		LOG.debug("============================");
		LOG.debug("=powerOn()=");
		LOG.debug("============================");

	}

	public void powerOff() {
		LOG.debug("============================");
		LOG.debug("=powerOff()=");
		LOG.debug("============================");

	}

	public void volumeUp() {
		LOG.debug("============================");
		LOG.debug("=volumeUp()=");
		LOG.debug("============================");

	}

	public void volumeDown() {
		LOG.debug("============================");
		LOG.debug("=volumeDown()=");
		LOG.debug("============================");

	}

}
