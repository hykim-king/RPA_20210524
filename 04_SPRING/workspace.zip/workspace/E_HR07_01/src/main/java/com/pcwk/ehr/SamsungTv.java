package com.pcwk.ehr;

public class SamsungTv implements Tv {

	private String brandNm = "SAMSUNG";
	private int price;
	
	public SamsungTv() {
		LOG.debug("============================");
		LOG.debug("=SamsungTv()=");
		LOG.debug("============================");		
	}
	
	
	public void powerOn() {
		LOG.debug("============================");
		LOG.debug("=powerOn()=");
		LOG.debug("============================");

	}

	public void powerOff() {
		LOG.debug("============================");
		LOG.debug("=powerOff()=");
		LOG.debug("============================");

	}

	public void volumeUp() {
		LOG.debug("============================");
		LOG.debug("=volumeUp()=");
		LOG.debug("============================");

	}

	public void volumeDown() {
		LOG.debug("============================");
		LOG.debug("=volumeDown()=");
		LOG.debug("============================");

	}

}
