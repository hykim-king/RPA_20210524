package com.pcwk.ehr;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/applicationContext.xml")
public class TvTest {
    final Logger  LOG = Logger.getLogger(getClass());
    
    @Autowired
    ApplicationContext context;
    
    private Tv tv;
    
	@Before
	public void setUp() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=setUp()=");
		LOG.debug("=======================");
		
		LOG.debug("=context="+context);
		//name으로 찾
		//tv = context.getBean("https://cafe.daum.net/pcwk", Tv.class);          
		//tv = context.getBean("lgTv", Tv.class);
		
		tv = context.getBean("samsungTv", Tv.class);
		LOG.debug("tv="+tv);
	}

	@After
	public void tearDown() throws Exception {
		LOG.debug("=======================");
		LOG.debug("=tearDown()=");
		LOG.debug("=======================");		
	}

	
	@Test
	public void lgTv() {
		LOG.debug("************************");
		LOG.debug("=lgTv()=");
		LOG.debug("************************");
		
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
	}


}
