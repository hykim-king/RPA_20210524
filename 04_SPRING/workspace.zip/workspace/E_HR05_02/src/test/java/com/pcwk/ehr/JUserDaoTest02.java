package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

//메소드 수행 순서: method ASCENDING ex)a~z
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringJUnit4ClassRunner.class) //JUnit기능 스프링 프레임으로 확장
@ContextConfiguration(locations = "/applicationContext.xml") ///applicationContext.xml 설정파일 read
public class JUserDaoTest02 {
	final Logger LOG = Logger.getLogger(getClass());

	@Autowired
	ApplicationContext context;
	
	@Autowired
	UserDao dao;
	
	UserVO user01;
	UserVO user02;
	UserVO user03;
	
	
	@Before
	public void setUp() throws Exception {
		//context = new GenericXmlApplicationContext("/applicationContext.xml");
		//dao = context.getBean("userDao", UserDao.class);
		
		user01 = new UserVO("pcwk_01", "이상무01", "1234_1");
		user02 = new UserVO("pcwk_02", "이상무02", "1234_2");
		user03 = new UserVO("pcwk_03", "이상무03", "1234_3");	
		
		LOG.debug("=========================");
		LOG.debug("=context="+context);
		LOG.debug("=dao="+dao);
		LOG.debug("=========================");		
	}

	@After
	public void tearDown() throws Exception {
		
	}

	//비교표현식
	@Test
	public void testAssert() {
		LOG.debug("=========================");
		LOG.debug("=testAssert()=");
		LOG.debug("=========================");	
		
		
		//assertThat(테스트 대상, Matcher구문);
		//예상은 2021-08-19 였었는데 실제는 2021-08-20
		//assertThat("2021-08-20", is("2021-08-20"));
		
		//assertThat("시작 날짜 비교","2021-08-20", is("2021-08-19"));
		
		//배열지원
		String[] names = {"Tom","JIMMY","SCOTT"};
		String[] anotherNames = {"Tom","JIMMY","SCOTT"};
		assertArrayEquals(names,anotherNames);
		
		//객체 A와 B가 같은지
		//assertEquals(a, b);
		
		//객체 A와 B가 같은지: c오차범위
		//assertEquals(a, b,c);
		
		//객체 A와 B가 같은 객체인지
		//assertSame(names, anotherNames);
		
		//assertTrue(a)
		//assertTrue()
		//조건 A가 참인가를 확인한다.		
	}
	
	
	
	@Test(expected = EmptyResultDataAccessException.class)
	public void getFailure() throws ClassNotFoundException, SQLException {
		LOG.debug("=========================");
		LOG.debug("=getFailure()=");
		LOG.debug("=========================");
		// 삭제
		dao.deleteAll();

		dao.get(user01);

	}

	// 1/1000초
	@Test(timeout = 20000)
	//@Ignore // 테스트 케이스에서 제외
	public void addAndGet() {

		UserVO user01 = new UserVO("pcwk_01", "이상무01", "1234_1");
		UserVO user02 = new UserVO("pcwk_02", "이상무02", "1234_2");
		UserVO user03 = new UserVO("pcwk_03", "이상무03", "1234_3");

		try {
			// 전체삭제
			dao.deleteAll();

			// 등록
			int flag = dao.add(user01);
			assertThat(flag, is(1));

			// 1건등록 확인
			assertThat(dao.getCount(), is(1));

			// 2건등록
			flag = dao.add(user02);
			assertThat(flag, is(1));

			// 2건등록 확인
			assertThat(dao.getCount(), is(2));

			// 3건등록
			flag = dao.add(user03);
			assertThat(flag, is(1));
			assertThat(dao.getCount(), is(3));

			// 한건 조회
			UserVO outVO_01 = dao.get(user01);

			isSameUser(outVO_01, user01);

			// 한건 조회
			UserVO outVO_02 = dao.get(user02);
			isSameUser(outVO_02, user02);

			// 한건 조회
			UserVO outVO_03 = dao.get(user03);
			isSameUser(outVO_03, user03);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void isSameUser(UserVO outVO, UserVO user) {
		assertThat(outVO.getuId(), is(user.getuId()));
		assertThat(outVO.getName(), is(user.getName()));
		assertThat(outVO.getPasswd(), is(user.getPasswd()));
	}

}
