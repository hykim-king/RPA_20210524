package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDaoAdd implements StatementStrategy {
    
	final Logger LOG = Logger.getLogger(getClass());
	UserVO user;
	
	public UserDaoAdd() {}
	
	public UserDaoAdd(UserVO user) {
		super();
		this.user = user;
	}

	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		PreparedStatement pstmt = null;
		// 2.DB에 보낼 SQL문장 작성, PreparedStatement생성하고 실행.
		StringBuilder sb = new StringBuilder();
		sb.append(" INSERT INTO HR_MEMBER ( u_id,name,passwd ) \n");
		sb.append(" VALUES (?,?,?)                             \n");
		LOG.debug("=========================================");
		LOG.debug("sql=\n" + sb.toString());
		LOG.debug("param=" + user.toString());
		LOG.debug("=========================================");

		pstmt = connection.prepareStatement(sb.toString());
		pstmt.setString(1, user.getuId());
		pstmt.setString(2, user.getName());
		pstmt.setString(3, user.getPasswd());		
		
		
		
		return pstmt;
	}

}
