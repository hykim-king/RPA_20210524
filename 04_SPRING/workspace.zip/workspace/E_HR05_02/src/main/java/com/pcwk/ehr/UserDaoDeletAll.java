package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

public class UserDaoDeletAll implements StatementStrategy {

	final Logger  LOG = Logger.getLogger(getClass());
	
	UserVO  userVO;
	
	public UserDaoDeletAll() {}
	
	public UserDaoDeletAll(UserVO userVO) {
		this.userVO = userVO;
	}
	
	
	public PreparedStatement makeStatement(Connection connection) throws SQLException {
		PreparedStatement pstmt;
		// 2.DB에 보낼 SQL문장 작성, PreparedStatement생성하고 실행.
		StringBuilder sb = new StringBuilder();
		sb.append(" DELETE FROM hr_member \n");
		LOG.debug("=========================================");
		LOG.debug("sql=\n" + sb.toString());
		LOG.debug("=========================================");

		pstmt = connection.prepareStatement(sb.toString());
		
		return pstmt;
	}

}
