package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.dao.EmptyResultDataAccessException;

public class JUserDaoTest {
    final Logger LOG = Logger.getLogger(getClass());
    
    
    
    @Test(expected = EmptyResultDataAccessException.class)
    public void getFailure() throws ClassNotFoundException, SQLException {
    	LOG.debug("=========================");
    	LOG.debug("=getFailure()=");
    	LOG.debug("=========================");
    	
    	
    	ApplicationContext context =new GenericXmlApplicationContext("/applicationContext.xml");
		UserDao dao=context.getBean("userDao", UserDao.class);
		
		//삭제
		dao.deleteAll();
		
		UserVO user01 = new UserVO("pcwk_01", "이상무01", "1234_1");
		dao.get(user01);
		
    }
    
    
    // 1/1000초 
	@Test(timeout = 20000)
	@Ignore //테스트 케이스에서 제외
	public void addAndGet() {
		ApplicationContext context =new GenericXmlApplicationContext("/applicationContext.xml");
		UserDao dao=context.getBean("userDao", UserDao.class);
		
		
		UserVO user01 = new UserVO("pcwk_01", "이상무01", "1234_1");
		UserVO user02 = new UserVO("pcwk_02", "이상무02", "1234_2");
		UserVO user03 = new UserVO("pcwk_03", "이상무03", "1234_3");

		try {
			//전체삭제
			dao.deleteAll();
			
			// 등록
			int flag = dao.add(user01);
			assertThat(flag, is(1));
      
			// 1건등록 확인
			assertThat(dao.getCount(), is(1));
			
			// 2건등록 
			flag = dao.add(user02);
			assertThat(flag, is(1));
			
			// 2건등록 확인
			assertThat(dao.getCount(), is(2));
			
			// 3건등록 
			flag = dao.add(user03);
			assertThat(flag, is(1));
			assertThat(dao.getCount(), is(3));
			
			// 한건 조회
			UserVO outVO_01 = dao.get(user01);
			
			isSameUser(outVO_01, user01);

			// 한건 조회
			UserVO outVO_02 = dao.get(user02);
			isSameUser(outVO_02, user02);
			
			// 한건 조회
			UserVO outVO_03 = dao.get(user03);
			isSameUser(outVO_03, user03);			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}
	
	public void isSameUser(UserVO outVO, UserVO user) {
		assertThat(outVO.getuId(), is(user.getuId()));
		assertThat(outVO.getName(), is(user.getName()));
		assertThat(outVO.getPasswd(), is(user.getPasswd()));
	}
	
	
	

}
