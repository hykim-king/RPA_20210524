package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/**
 * DB연결
 * @author HKEDU
 *
 */
public class SimpleConnectionMaker {
	final Logger LOG = Logger.getLogger(SimpleConnectionMaker.class);
    /**
     * DB연결
     * @return Connection
     * @throws ClassNotFoundException
     * @throws SQLException
     */
	public Connection makeGetConnection() throws ClassNotFoundException, SQLException {
		Connection connection = null;//Oracle DB connection
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//
		final String DB_URL ="jdbc:oracle:thin:@192.168.3.100:1521:xe";
		//final String DB_URL ="jdbc:oracle:thin:@localhost:1521:xe";
		final String USER_ID ="SPRING_PCWK";
		final String USER_PASS ="PCWK1234";
		
		connection = DriverManager.getConnection(DB_URL, USER_ID, USER_PASS);
		LOG.debug("=========================================");
		LOG.debug("=connection="+connection);
		LOG.debug("=========================================");
		return connection;
	}
}
