package com.pcwk.ehr;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.sql.SQLException;
import java.util.List;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;


import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pcwk.ehr.member.dao.UserDao;
import com.pcwk.ehr.member.domain.UserVO;

//메소드 수행 순서: method ASCENDING ex)a~z
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class) //JUnit기능 스프링 프레임으로 확장
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/root-context.xml",
                                "file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"}) 
public class JUserControllerTest02 {

	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	WebApplicationContext webApplicationContext;	
	
	//브라우저 대신할 Mock
	MockMvc  mockMvc;	
	
	UserVO user01;
	UserVO user02;
	UserVO user03;
	SearchVO search01;
	
	@Autowired
	UserDao dao;
	
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		
		user01 = new UserVO("pcwk_01", "이상무01", "1234_1",Level.BASIC,1,0,"jamesol@naver.com","");
		user02 = new UserVO("pcwk_02", "이상무02", "1234_2",Level.SILVER,51,0,"jamesol@naver.com","");
		user03 = new UserVO("pcwk_03", "이상무03", "1234_3",Level.GOLD,71,31,"jamesol@naver.com","");
		
		search01 = new SearchVO();
		search01.setPageNum(1);
		search01.setPageSize(10);
		
	}
	
	@Test
	public void doLogin() throws Exception {
		//1.기존데이터 삭제
		//2.입력		
		dao.doDelete(user01);
		
		dao.doInsert(user01);		
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/member/doLogin.do")
				 .param("uId",   user01.getuId())
				 .param("passwd",   user01.getPasswd())
				 ;		
		
		ResultActions    resultActions = mockMvc.perform(createMessage)
                .andExpect(status().is2xxSuccessful());
 
		String result = resultActions.andDo(print())
                .andReturn()
                .getResponse().getContentAsString();		
        Gson gson=new Gson();
		
		MessageVO message = gson.fromJson(result, MessageVO.class);
		
		assertThat(message.getMsgId(), is("30"));
		assertThat(message.getMsgContents(), is(user01.getName()+"님이 로그인 되었습니다."));			
	}
	
	
	
	@Test
	@Ignore
	public void idCheck() throws Exception {
		//1.기존데이터 삭제
		//2.입력
		//3.idCheck
		dao.doDelete(user01);
		
		dao.doInsert(user01);
		
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/member/idCheck.do")
				 .param("uId",   user01.getuId());
		
		ResultActions    resultActions = mockMvc.perform(createMessage)
                .andExpect(status().is2xxSuccessful());		 
		String result = resultActions.andDo(print())
                .andReturn()
                .getResponse().getContentAsString();
		LOG.debug("=====================================");
		LOG.debug("=result="+result);
		LOG.debug("=====================================");			
		
        Gson gson=new Gson();
		
		MessageVO message = gson.fromJson(result, MessageVO.class);
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is(user01.getuId()+"는 사용 하실수 있습니다."));		
	}
	
	
	
	
	
	
	@Test
	@Ignore
	public void doRetrieve() throws Exception {
        search01.setSearchDiv("10");
        search01.setSearchWord("j_hr000000");
		
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.get("/member/doRetrieve.do")
				 .param("searchDiv",   search01.getSearchDiv())
				 .param("searchWord",  search01.getSearchWord())
				 .param("pageSize",    String.valueOf(search01.getPageSize()))
				 .param("pageNum",     String.valueOf(search01.getPageNum()));
				 
		ResultActions    resultActions = mockMvc.perform(createMessage)
                .andExpect(status().is2xxSuccessful());		 
		String result = resultActions.andDo(print())
                .andReturn()
                .getResponse().getContentAsString();
		LOG.debug("=====================================");
		LOG.debug("=result="+result);
		LOG.debug("=====================================");		
		
		//gson -> List<UserVO>
		Gson gson=new Gson();
		List<UserVO> list=gson.fromJson(result, new TypeToken<List<UserVO>>(){}.getType());
		
		for(UserVO vo :list) {
			LOG.debug("=vo="+vo);
		}
		
		assertThat(list.size(), is(10));
	}
	
	@Test
	@Ignore
	public void doUpdate() throws Exception {
		//전체삭제
		dao.deleteAll();
		//단건 입력
		dao.doInsert(user01);
		//단건 조회
		UserVO vsUser = dao.doSelectOne(user01);
		
		String upStr = "_U";
		//수정
		vsUser.setName(vsUser.getName()+upStr);
		vsUser.setPasswd(vsUser.getPasswd()+upStr);
		vsUser.setLevel(Level.SILVER);
		vsUser.setLogin(vsUser.getLogin()+2);
		vsUser.setRecommend(vsUser.getRecommend()+10);
		vsUser.setEmail(vsUser.getEmail()+upStr);
		
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/member/doUpdate.do")
				 .param("uId",      vsUser.getuId())
				 .param("name",     vsUser.getName())
				 .param("passwd",   vsUser.getPasswd())
				 .param("level",    String.valueOf(vsUser.getLevel()))
				 //.param("level",    null)
				 .param("login",    String.valueOf(vsUser.getLogin()))
				 .param("recommend",String.valueOf(vsUser.getRecommend()))
				 .param("email",    vsUser.getEmail());		
		ResultActions    resultActions = mockMvc.perform(createMessage)
				                      .andExpect(status().is2xxSuccessful());
		
		String result = resultActions.andDo(print())
		                .andReturn()
		                .getResponse().getContentAsString();
		LOG.debug("=====================================");
		LOG.debug("=result="+result);
		LOG.debug("=====================================");	
				
		Gson gson=new Gson();
		
		MessageVO message = gson.fromJson(result, MessageVO.class);
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("수정 되었습니다."));
		
		UserVO getUpdateUser = dao.doSelectOne(vsUser);
		this.isSameUser(vsUser, getUpdateUser);
	}
	
	@Test
	@Ignore
	public void addAndGet() throws Exception {
		//00.deleteAll
		dao.deleteAll();
		
		//0.등록
		doInsert(user01);
		
		//1.삭제
		doDelete(user01);
		
		//2.등록
		int flag = doInsert(user01);
		assertThat(flag, is(1));
		//3.조회
		UserVO vsUser01 = doSelectOne(user01);
		
		isSameUser(vsUser01, user01);
	}
	
	//@Test
	private int doInsert(UserVO user) throws Exception {
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.post("/member/doInsert.do")
				 .param("uId",      user.getuId())
				 .param("name",     user.getName())
				 .param("passwd",   user.getPasswd())
				 .param("level",    String.valueOf(user.getLevel()))
				 //.param("level",    null)
				 .param("login",    String.valueOf(user.getLogin()))
				 .param("recommend",String.valueOf(user.getRecommend()))
				 .param("email",    user.getEmail());
		
		@SuppressWarnings("deprecation")
		ResultActions  resultActions = mockMvc.perform(createMessage)
		                               .andExpect(status().is2xxSuccessful())
		                               .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_UTF8));
		//응답
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson =new Gson();
		MessageVO message = gson.fromJson(result, MessageVO.class);
		LOG.debug("=====================================");
		LOG.debug("=message="+message);
		LOG.debug("=====================================");
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("등록 되었습니다."));
		
		return Integer.valueOf(message.getMsgId());
	}
	
	
	
	//@Test
	//@Ignore
	private UserVO doSelectOne(UserVO user) throws Exception {
		//param,url
		MockHttpServletRequestBuilder createMessage =
				MockMvcRequestBuilders.get("/member/doSelectOne.do")
				 .param("uId", user.getuId());
		
		//호출,예상결과
		ResultActions  resultActions = this.mockMvc.perform(createMessage)
				                       .andExpect( status().is2xxSuccessful() );
				                       
		                               //model and view
				                       //.andExpect( model().attributeExists("vo")); 
		
		//응답
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson=new Gson();
		
		UserVO outVO =gson.fromJson(result, UserVO.class);
		LOG.debug("==========================");
		LOG.debug("=result="+result);
		LOG.debug("=outVO="+outVO);
		LOG.debug("==========================");
		isSameUser(outVO, user01);
		
		return outVO;
	}
	
	//@Test
	//@Ignore
	private int doDelete(UserVO user) throws Exception {
		//param,url
		MockHttpServletRequestBuilder createMessage =
						MockMvcRequestBuilders.get("/member/doDelete.do")
						 .param("uId", user.getuId());	
		//호출,예상결과
		ResultActions  resultActions = this.mockMvc.perform(createMessage)
						               .andExpect( status().is2xxSuccessful() );
		
		//응답
		String result = resultActions.andDo(print())
				      .andReturn()
				      .getResponse().getContentAsString();
		
		Gson gson=new Gson();
		MessageVO message = gson.fromJson(result,MessageVO.class);
		
		LOG.debug("==========================");
		LOG.debug("=result="+result);
		LOG.debug("=message="+message);
		LOG.debug("==========================");	
		
		assertThat(message.getMsgId(), is("1"));
		assertThat(message.getMsgContents(), is("삭제 되었습니다."));
		
		return Integer.valueOf(message.getMsgId());
	}
	
	public void isSameUser(UserVO outVO, UserVO user) {
		assertThat(outVO.getuId(), is(user.getuId()));
		assertThat(outVO.getName(), is(user.getName()));
		assertThat(outVO.getPasswd(), is(user.getPasswd()));
		// 2021/08/25 추가컬럼
		assertThat(outVO.getLevel(), is(user.getLevel()));
		assertThat(outVO.getLogin(), is(user.getLogin()));
		assertThat(outVO.getRecommend(), is(user.getRecommend()));
		// 2021/08/30 추가컬럼
		assertThat(outVO.getEmail(), is(user.getEmail()));
		
	}
	
	
	
	
	
	
	
	@Test
	public void beans() {
		LOG.debug("webApplicationContext"+webApplicationContext);
		assertThat(webApplicationContext, is(notNullValue()));
	}

}
