--ITAS 100000
DELETE FROM hr_member;
commit;

INSERT INTO hr_member
SELECT 'j_hr'||lpad(rownum,7,'0')
       ,'�̻�' || lpad(rownum,7,'0')
       ,'1234'
       ,DECODE(MOD(rownum,10),0,'2','1')
       ,MOD(rownum,50)
       ,MOD(rownum,20)
       ,'james'||lpad(rownum,7,'0')||'@daum.net'
       ,(SYSDATE -ROWNUM/(60*60))
FROM dual
CONNECT BY LEVEL < =100000
;
commit;
SELECT COUNT(*) FROM hr_member;