package com.pcwk.ehr.member.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.pcwk.ehr.Level;
import com.pcwk.ehr.MessageVO;
import com.pcwk.ehr.SearchVO;
import com.pcwk.ehr.StringUtil;
import com.pcwk.ehr.member.domain.UserVO;
import com.pcwk.ehr.member.service.UserService;

/**
 * 화면(view)->Controller
 *          ->param to VO  -> Service
 *            flag         <-
 * @author HKEDU
 *
 */
@Controller
public class UserController {

	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	UserService  service;
	
	
	public UserController() {}
	
	//Jackson 라이브러리를 통해서
	//Object -> Json
	@RequestMapping(value="member/doLogin.do",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public MessageVO doLogin(UserVO user, HttpSession session) throws ClassNotFoundException, SQLException  {
		LOG.debug("======================================");
		LOG.debug("=user="+user);
		LOG.debug("======================================");
		

		
		
		MessageVO loginMessage = service.login(user);
		
		//setMsgId==30번이면 로그인 성공
		//
		if("30".equals(loginMessage.getMsgId())) {
			
			UserVO loginUser = service.doSelectOne(user);
			
			if(null !=loginUser) {
				loginMessage.setMsgContents(loginUser.getName()+"님이 로그인 되었습니다.");
			}
			
			session.setAttribute("user", loginUser);
		}
		
		Gson gson=new Gson();
		LOG.debug("======================================");
		LOG.debug("=loginMessage="+loginMessage);
		LOG.debug("======================================");		
		
		return loginMessage;
	}
	
	
	@RequestMapping(value="member/idCheck.do",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String idCheck(UserVO user) throws ClassNotFoundException, SQLException{
		LOG.debug("=====================================");
		LOG.debug("=param=="+user);
		LOG.debug("=====================================");
		
		int flag = service.idCheck(user);
		MessageVO   message = new MessageVO();
		message.setMsgId(String.valueOf(flag));
		
		if( 1 != flag) {
			message.setMsgContents(user.getuId()+"는 사용 하실수 없습니다.");
		}else {
			message.setMsgContents(user.getuId()+"는 사용 하실수 있습니다.");
		}
		
		Gson gson=new Gson();
		String gsonStr = gson.toJson(message);
		LOG.debug("=gsonStr=="+gsonStr);
		return gsonStr;
	}
	
	//member/doSelectOne.do?uId=pcwk_01
	@RequestMapping(value = "member/doSelectOne.do",method = RequestMethod.GET
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String doSelectOne(UserVO inVO,Model model) throws ClassNotFoundException, SQLException{
		LOG.debug("=====================================");
		LOG.debug("=doSelectOne=");
		LOG.debug("=param="+inVO);
		LOG.debug("=====================================");
		 
		UserVO outVO = service.doSelectOne(inVO);
		LOG.debug("=outVO="+outVO);
		//model.addAttribute("vo", outVO);
		
		Gson gson=new Gson();
		//DTO -> JSON
		String jsonStr = gson.toJson(outVO);
		LOG.debug("=====================================");
		LOG.debug("=jsonStr="+jsonStr);
		LOG.debug("=====================================");		
		
		//{"uId":"pcwk_01","name":"이상무01","passwd":"1234_1","level":"BASIC"
		//,"login":49,"recommend":0,"email":"jamesol@naver.com","regDt":"2021/09/03 132849"}
		
		return jsonStr;   
	}
	@RequestMapping(value="member/doInsert.do"
			,method=RequestMethod.POST
			,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String doInsert(HttpServletRequest req) throws ClassNotFoundException, SQLException{
		UserVO inVO = new UserVO();
		MessageVO messageVO = new MessageVO();
		//request -> VO
		inVO.setuId(req.getParameter("uId"));     //사용자 ID
		inVO.setName(req.getParameter("name"));    //사용자 이름
		inVO.setPasswd(req.getParameter("passwd"));  //비밀번호
		
		String tmpLevel = StringUtil.nvl(req.getParameter("intLevel"), "1");
		inVO.setIntLevel(Integer.valueOf(tmpLevel));   //등급: Default :1
		
		String loginStr  = req.getParameter("login");
		inVO.setLogin(Integer.valueOf(loginStr));   //로그인 회수
		
		String recommendStr  = req.getParameter("recommend");
		
		inVO.setRecommend(Integer.valueOf(recommendStr));//추천수
		inVO.setEmail(req.getParameter("email"));    //이메일
		            
		LOG.debug("=====================================");
		LOG.debug("=inVO="+inVO);
		LOG.debug("=====================================");
		
		int flag = this.service.doInsert(inVO);
		
		String messageStr = "";
		if(1==flag) {
			messageStr = "등록 되었습니다.";
		}else {
			messageStr = "등록 실패.";
		}
		
		messageVO.setMsgId(String.valueOf(flag));
		messageVO.setMsgContents(messageStr);
		
		Gson gson=new Gson();
		String gsonStr = gson.toJson(messageVO);
		LOG.debug("=====================================");
		LOG.debug("=gsonStr="+gsonStr);
		LOG.debug("=====================================");		
		return gsonStr;
	}
	
	//member/doDelete.do?uId=pcwk_01
	@RequestMapping(value="member/doDelete.do"
			,method = RequestMethod.GET
			,produces ="application/json;charset=UTF-8" )
	@ResponseBody	
	public String doDelete(HttpServletRequest req) throws SQLException{
		UserVO inVO =new UserVO();
		MessageVO messageVO=new MessageVO();
		LOG.debug("=====================================");
		LOG.debug("=doSelectOne=");
		
		LOG.debug("=====================================");
		
		String userId = req.getParameter("uId");
		inVO.setuId(userId);
		LOG.debug("=param="+inVO);
		int flag = this.service.doDelete(inVO);
		
		String resultMsg = "";
		if(1==flag) {
			resultMsg = "삭제 되었습니다.";
		}else {
			resultMsg = "삭제 실패.";
		}
		messageVO.setMsgId(String.valueOf(flag));
		messageVO.setMsgContents(resultMsg);
		
		//MessageVO -> JSON
		Gson gson=new Gson();
		String jsonStr = gson.toJson(messageVO);
		LOG.debug("=====================================");
		LOG.debug("=jsonStr="+jsonStr);
		LOG.debug("=====================================");		
		
		return jsonStr;
	}
	
	
	@RequestMapping(value="member/doUpdate.do"
			,method = RequestMethod.POST
			,produces = "application/json;charset=UTF-8"
			)
	@ResponseBody
	public String doUpdate(UserVO user) throws SQLException{
        MessageVO  messageVO = new MessageVO();
		LOG.debug("=====================================");
		LOG.debug("=user="+user);
		LOG.debug("=====================================");	
		
		if(null == user.getLevel()) {
			user.setLevel(Level.BASIC);
		}
		
		int flag  = this.service.doUpdate(user);
		
		String messageStr = "";
		
		if(1==flag) {
			messageStr = "수정 되었습니다.";
		}else {
			messageStr = "수정 실패";
		}
		messageVO.setMsgId(String.valueOf(flag));
		messageVO.setMsgContents(messageStr);
		LOG.debug("=====================================");
		LOG.debug("=messageVO="+messageVO);
		LOG.debug("=====================================");	
		
		Gson gson=new Gson();
		String jsonStr = gson.toJson(messageVO);
		LOG.debug("=jsonStr="+jsonStr);
		return jsonStr;
	}
	
	@RequestMapping(value="member/doRetrieve.do"
			,method=RequestMethod.GET
			,produces="application/json;charset=UTF-8")
	@ResponseBody
	public String doRetrieve(SearchVO search) throws SQLException{
		
		//Default: pageSize=10, pageNum=1
		//페이지 Num
		if(0==search.getPageNum()) {
			search.setPageNum(1);
		}
		      
		//pageSize
		if(0==search.getPageSize()) {
			search.setPageSize(10);
		}		
		
		LOG.debug("=====================================");
		LOG.debug("=search=");
		LOG.debug("=search="+search);
		LOG.debug("=====================================");		
		
		List<UserVO> list = (List<UserVO>) this.service.doRetrieve(search);
		
		for(UserVO vo   :list) {
			LOG.debug("=vo="+vo);
		}
		
		Gson gson=new Gson();
		String jsonList = gson.toJson(list);
		LOG.debug("=====================================");
		LOG.debug("=jsonList="+jsonList);
		LOG.debug("=====================================");				
		
		
		return jsonList;
	}	
}































