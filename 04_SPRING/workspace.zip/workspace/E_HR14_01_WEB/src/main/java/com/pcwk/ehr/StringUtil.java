package com.pcwk.ehr;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class StringUtil {

	/**
	 * val가 Null이면 rep 대처
	 * @param val
	 * @param rep
	 * @return String
	 */
	public static String nvl(String val,String rep) {
		if(null == val) {
			val = rep;
		}
		
		return val.trim();
	}
	
	//
	public static String getPK(String format) {
		return formatDate(format)+getUUID();
	}
	
	/**
	 * UUID
	 * @return
	 */
	public static String getUUID() {
		String uuidStr = "";
		
		UUID uuid = UUID.randomUUID();
		uuidStr =  uuid.toString().replaceAll("-", "");
		return uuidStr;    
	}
	/**
	 * 형식날짜 출력 
	 * @param format
	 * @return String
	 */
	public static String formatDate(String format) {
		
		format = nvl(format,"yyyy/MM/dd");
		
		SimpleDateFormat  sdf=new SimpleDateFormat(format);
		return sdf.format(new Date());
	}
	
	/**
	 * 동적 디렉토리 생성
	 * @param path
	 * @return boolean
	 */
	public static boolean makeDir(String path) {
		boolean flag = false;
		
		File mkdir =new File(path);
		if(mkdir.isDirectory()==false) {
			flag = mkdir.mkdirs();
		}
		
		return flag;
	}
	
	
	
	
}
