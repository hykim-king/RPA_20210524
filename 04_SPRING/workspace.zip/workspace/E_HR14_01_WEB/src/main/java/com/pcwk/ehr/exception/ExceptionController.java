/**
* <pre>
* com.pcwk.ehr.exception
* Class Name : ExceptionController.java
* Description: Server예외 처리
* Author: HKEDU
* Since: 2021/09/15
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/09/15 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pcwk.ehr.member.domain.UserVO;

/**
 * @author HKEDU
 *
 */


@Controller
public class ExceptionController {

	final Logger LOG = LoggerFactory.getLogger(getClass());
	//http://localhost:8080/ehr/execept/null_pointer.do?uId=
	@RequestMapping(value="execept/null_pointer.do", method = RequestMethod.GET)
	public String nullPointer(UserVO user) {
		if(null !=user.getuId() || "".equals(user.getuId())) {
			throw new NullPointerException("아이디를 입력 하세요");
		}
		   
		return "main/main";
	}
	
	//http://localhost:8080/ehr/execept/illegal.do?uId=
	@RequestMapping(value="execept/illegal.do", method = RequestMethod.GET)
	public String illegalArguemnt(UserVO user) {
		if(null !=user.getuId() || "".equals(user.getuId())) {
			throw new IllegalArgumentException("아이디를 입력 하세요");
		}
		
		return "main/main";
	}	
	   
	
	//http://localhost:8080/ehr/execept/commonError.do?uId=
	@RequestMapping(value="execept/commonError.do", method = RequestMethod.GET)
	public String commonError(UserVO user) {
		if(null ==user.getuId() || "".equals(user.getuId())) {
			throw new ArithmeticException("common 에러");
		}
		
		return "main/main";
	}		
	

}
