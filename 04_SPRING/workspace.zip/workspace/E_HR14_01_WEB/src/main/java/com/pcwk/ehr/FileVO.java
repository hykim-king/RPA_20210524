/**
* <pre>
* com.pcwk.ehr
* Class Name : FileVO.java
* Description:
* Author: HKEDU
* Since: 2021/09/13
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/09/13 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr;

/**
 * @author HKEDU
 *
 */
public class FileVO extends DTO {
	
	private String orgFileNm; //원본파일명
	private String saveFileNm;//저장파일명
	private long   fileSize;  //파일사이즈
	private String ext     ;  //확장자
	private String savepath;  //저장경로
	
	private String  year   ;  //년도
	private String  month  ;  //월
	

	
	
	public FileVO() {}

	/**
	 * @return the year
	 */
	public String getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * @return the month
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * @param month the month to set
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * @return the orgFileNm
	 */
	public String getOrgFileNm() {
		return orgFileNm;
	}

	/**
	 * @param orgFileNm the orgFileNm to set
	 */
	public void setOrgFileNm(String orgFileNm) {
		this.orgFileNm = orgFileNm;
	}

	/**
	 * @return the saveFileNm
	 */
	public String getSaveFileNm() {
		return saveFileNm;
	}

	/**
	 * @param saveFileNm the saveFileNm to set
	 */
	public void setSaveFileNm(String saveFileNm) {
		this.saveFileNm = saveFileNm;
	}

	/**
	 * @return the fileSize
	 */
	public long getFileSize() {
		return fileSize;
	}

	/**
	 * @param fileSize the fileSize to set
	 */
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	/**
	 * @return the ext
	 */
	public String getExt() {
		return ext;
	}

	/**
	 * @param ext the ext to set
	 */
	public void setExt(String ext) {
		this.ext = ext;
	}

	/**
	 * @return the savepath
	 */
	public String getSavepath() {
		return savepath;
	}

	/**
	 * @param savepath the savepath to set
	 */
	public void setSavepath(String savepath) {
		this.savepath = savepath;
	}

	@Override
	public String toString() {
		return "FileVO [orgFileNm=" + orgFileNm + ", saveFileNm=" + saveFileNm + ", fileSize=" + fileSize + ", ext="
				+ ext + ", savepath=" + savepath + ", year=" + year + ", month=" + month + ", toString()="
				+ super.toString() + "]";
	}



}
