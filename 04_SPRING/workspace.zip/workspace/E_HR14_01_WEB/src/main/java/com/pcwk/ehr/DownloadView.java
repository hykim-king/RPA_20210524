/**
* <pre>
* com.pcwk.ehr
* Class Name : DownloadView.java
* Description: 파일다운 로드
* Author: HKEDU
* Since: 2021/09/14
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/09/14 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.servlet.view.AbstractView;

/**
 * @author HKEDU
 *
 */
public class DownloadView extends AbstractView {
	final Logger LOG = LoggerFactory.getLogger(getClass());
	
	public DownloadView() {
		setContentType("application/download;charset=utf-8");
	}
	
	/**
	 * 다운로드 파일을 원본파일명으로 변환
	 * @param orgFileNm
	 * @param request
	 * @param response
	 */
	public void setDownloadFileName(String orgFileNm, HttpServletRequest  request, HttpServletResponse response) throws Exception{
			
		//브라우저 정보
		String userAgent = request.getHeader("User-Agent");//브라우저 구분
		LOG.debug("userAgent:"+userAgent);
		LOG.debug("orgFileNm:"+orgFileNm);
		
		//IE 11 Trident
		if(userAgent.indexOf("Trident")>-1) {
			orgFileNm = URLEncoder.encode(orgFileNm, "utf-8").replaceAll("\\+", "%20");//%20 : space
		}else {
			orgFileNm = URLEncoder.encode(orgFileNm, "utf-8");
		}
		LOG.debug("URLEncoder.encode orgFileNm:"+orgFileNm);
		
		//header에 파일이름 set
		//response.setHeader("", userAgent);
		response.setHeader("Content-Disposition", "attachment; fileName=\""+orgFileNm+"\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
			
	}
	
	/**
	 * stream을 이용해서 파일 다운로드
	 * @param downloadFile
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	public void downloadFile(File downloadFile, HttpServletRequest  request, HttpServletResponse response) throws Exception{
	
		FileInputStream   in=new FileInputStream(downloadFile);
		
		OutputStream      out=response.getOutputStream();
		try {
			FileCopyUtils.copy(in, out);
		}catch(IOException e) {
			throw e;
		}finally {
			if(null != in) {
				try {
				in.close();
				}catch(IOException i) {
					
				}
			}
			
			if(null !=out) {
				try {
				out.close();
				}catch(IOException e) {
					
				}
			}
		}
		
	}
	//downloadView 진입점
	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		setResponseContentType(request, response);
		
		String orgFileNm  = (String) model.get("orgFileNm");
		File downloadFile = (File) model.get("downloadFile");
		LOG.debug("orgFileNm:"+orgFileNm);
		LOG.debug("downloadFile:"+downloadFile);
		//다운로드 파일을 원본파일명으로 변환
		setDownloadFileName(orgFileNm,request,response);
		
		//stream을 이용해서 파일 다운로드
		downloadFile(downloadFile,request,response);
	}

}


