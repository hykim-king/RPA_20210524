/**
* <pre>
* com.pcwk.ehr
* Class Name : FileController.java
* Description:
* Author: HKEDU
* Since: 2021/09/13
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/09/13 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
/**
 * @author HKEDU
 *
 */
@Controller
public class FileController {
    final Logger LOG = LoggerFactory.getLogger(getClass());
    
    //image save path
    //final String UPLOAD_IMG_DIR  = "D:\\RPA_20210524\\04_SPRING\\workspace\\E_HR14_01_WEB\\src\\main\\webapp\\resources\\upload_img";
    //
    final String UPLOAD_IMG_DIR  = "D:\\RPA_20210524\\04_SPRING\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\E_HR14_01_WEB\\resources\\upload_img";
    
    //file  save path
    final String UPLOAD_FILE_DIR = "D:\\RPA_20210524\\04_SPRING\\workspace\\E_HR14_01_WEB\\src\\main\\webapp\\WEB-INF\\upload";
    
    @Resource(name = "downloadView")
    View  download;
    
    
    @RequestMapping(value = "file/download.do",method = RequestMethod.POST)
    public ModelAndView download(FileVO fileVO, ModelAndView modelAndView) {
		LOG.debug("==================");
		LOG.debug("=download()=");
		LOG.debug("=fileVO="+fileVO);
		LOG.debug("==================");   	
    	
		//DownloadView.java
		//   renderMergedOutputModel
		//   setDownloadFileName
		//   downloadFile
		
		File downloadFile=new File(fileVO.getSavepath(), fileVO.getSaveFileNm());
		
		//DownloadView 
		modelAndView.setView(download);
		
		//원본파일
		modelAndView.addObject("orgFileNm", fileVO.getOrgFileNm());
		//파일객체: 저장경로, 저장파일명
		modelAndView.addObject("downloadFile", downloadFile);
				
    	return modelAndView;
    }
    
    
    
    
    
    
	@RequestMapping(value="file/file_view.do")
	public String fileView() {
		LOG.debug("==================");
		LOG.debug("=fileView()=");
		LOG.debug("==================");
		

		
		return "file/file_upload";
	}
	
	
	@RequestMapping(value = "file/upload.do",method = RequestMethod.POST)
	public ModelAndView upload(MultipartHttpServletRequest mReg, ModelAndView  modelAndView) throws IllegalStateException, IOException {
		LOG.debug("==================");
		LOG.debug("=upload()=");
		LOG.debug("==================");		
		  
		//동적으로 폴더 생성:파일
		File  fileRootDir = new File(UPLOAD_FILE_DIR);
		if(fileRootDir.isDirectory()==false) {
			fileRootDir.mkdir();
		}
		//동적으로 폴더 생성:이미지		
		File imageRootDir=new File(this.UPLOAD_IMG_DIR);
		if(imageRootDir.isDirectory()==false) {
			imageRootDir.mkdir();
		}
		
		//년도
		String year = StringUtil.formatDate("yyyy");
		LOG.debug("=year="+year);
		//월
		String month = StringUtil.formatDate("MM");
		LOG.debug("=month="+month);
		
		//파일에 관련된 동적 dir생성
		String yearMonthPath = "";
		yearMonthPath = UPLOAD_FILE_DIR+File.separator
		                +year+File.separator
		                +month;
		
		LOG.debug("=yearMonthPath="+yearMonthPath);
		//UPLOAD_FILE_DIR+년도/월
	    StringUtil.makeDir(yearMonthPath);
		
		String imageYearMonthPath = "";
		imageYearMonthPath = this.UPLOAD_IMG_DIR+File.separator
				             +year+File.separator
				             +month;
		StringUtil.makeDir(imageYearMonthPath);
		
		
		String title = StringUtil.nvl(mReg.getParameter("title"),"");//제목
		String fileDiv = StringUtil.nvl(mReg.getParameter("file_div"),"");//구분
		
		
		LOG.debug("=title="+title);
		LOG.debug("=fileDiv="+fileDiv);
		
		List<FileVO> list = new ArrayList<FileVO>();
		Iterator<String> files =mReg.getFileNames();
		
		while(files.hasNext()) {
			FileVO fileVO=new FileVO();
			String upFileNm = files.next();
			LOG.debug("=upFileNm="+upFileNm);
			
			//File정보
			MultipartFile mFile = mReg.getFile(upFileNm);
			
			//원본파일
			String orgFileNm = mFile.getOriginalFilename();
			LOG.debug("=orgFileNm="+orgFileNm);
			
			//파일이 없는 경우
			if(null == orgFileNm || "".equals(orgFileNm)) {
				continue;
			}
			//저장파일명 
			//yyyyMMddHH24mmss+UUID
			//2021091311244808 + ae2de10540364afba5c3b0da9bcf0ae9
			String saveFileNm = StringUtil.getPK("yyyyMMddHH24mmss");
			//확장자
			String ext = "";
			if(orgFileNm.lastIndexOf(".")>-1) {
				ext = orgFileNm.substring(orgFileNm.lastIndexOf(".")+1);
				saveFileNm+="."+ext;
			}
			LOG.debug("=saveFileNm="+saveFileNm);
			//파일사이즈
			long fileSize = mFile.getSize();//byte단위
			
			String savePath = "";
			if("20".equals(fileDiv)) { //이미지
				savePath =imageYearMonthPath;
			}else {
				savePath =yearMonthPath;
			}
			//원본파일(lec1.프로그래밍 기초 강좌 소개-v3.pptx) -> 저장파일(202109131324224857543c0621d547c193c3c02342b58e93.pptx)
			fileVO.setOrgFileNm(orgFileNm);  //원본파일명
			fileVO.setSaveFileNm(saveFileNm);//저장파일명
			fileVO.setFileSize(fileSize);    //파일사이즈
			fileVO.setExt(ext);              //확장자
			fileVO.setSavepath(savePath);    //저장경로
			fileVO.setYear(year);            //년도
			fileVO.setMonth(month);          //월
			
			File renameFile=new File(savePath,fileVO.getSaveFileNm());
			LOG.debug("fileVO:"+fileVO);
			
			list.add(fileVO);
			
			//file서버에 저장
			mFile.transferTo(renameFile);	
		}
		
		modelAndView.addObject("list", list);
		modelAndView.setViewName("file/file_upload");
		
		return modelAndView;
	}
	
}
