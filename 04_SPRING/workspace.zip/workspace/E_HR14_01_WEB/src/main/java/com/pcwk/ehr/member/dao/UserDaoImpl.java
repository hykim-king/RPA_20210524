package com.pcwk.ehr.member.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.pcwk.ehr.Level;
import com.pcwk.ehr.SearchVO;
import com.pcwk.ehr.member.domain.UserVO;
//
//namespace : namespace +"."+id

@Repository
public class UserDaoImpl implements UserDao {
	final static org.slf4j.Logger LOG = LoggerFactory.getLogger(UserDaoImpl.class);
		
	@Autowired
	SqlSessionTemplate   sqlSessionTemplate;
	
	final String NAMESPACE = "com.pcwk.ehr.member";

	public UserDaoImpl() {
		
	}

	//id가 있는지
	public int idCheck(UserVO inVO) {
		int flag = 0;
		
		String statement = this.NAMESPACE +".idCheck";
		LOG.debug("statement:" + statement);
		LOG.debug("param:" + inVO);
		
		flag = this.sqlSessionTemplate.selectOne(statement, inVO);
		LOG.debug("flag:" + flag);
		return flag;
	}
	
	//비번 check
	public int passCheck(UserVO inVO) {
		int flag = 0;
		String statement = this.NAMESPACE +".passCheck";
		LOG.debug("statement:" + statement);
		LOG.debug("param:" + inVO);
		
		flag = this.sqlSessionTemplate.selectOne(statement, inVO);
		LOG.debug("flag:" + flag);		
		return flag;		
	}
	
	
	

	@SuppressWarnings({ "deprecation" })
	public List<UserVO> getAll() {
		List<UserVO> list = new ArrayList<UserVO>();
		
		String statement = this.NAMESPACE +".getAll";
		
		list = this.sqlSessionTemplate.selectList(statement);
		
		for (UserVO vo : list) {
			LOG.debug("vo:" + vo);
		}

		return list;
	}

	public List<?> doRetrieve(SearchVO searchVO) throws SQLException {
		List<UserVO>   list = new ArrayList<UserVO>();
		
		String statement = this.NAMESPACE +".doRetrieve";
		LOG.debug("=========================================");
		LOG.debug("statement" + statement);
		LOG.debug("searchVO" + searchVO);
		LOG.debug("=========================================");		
		
		list = this.sqlSessionTemplate.selectList(statement, searchVO);
		
		for (UserVO vo : list) {
			LOG.debug("vo:" + vo);
		}		
		return list;
	}
	
	/**
	 * 등록 건수
	 * 
	 * @return 등록 건수
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	@SuppressWarnings("deprecation")
	public int getCount() throws ClassNotFoundException, SQLException {
		int cnt = 0;

		String statement = this.NAMESPACE +".getCount";
		
		cnt = this.sqlSessionTemplate.selectOne(statement);
		LOG.debug("=========================================");
		LOG.debug("cnt=" + cnt);
		LOG.debug("=========================================");

		return cnt;
	}

	/**
	 * 사용자 조회
	 * 
	 * @param inVO
	 * @return UserVO
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	@SuppressWarnings("deprecation")
	public UserVO doSelectOne(UserVO inVO) throws ClassNotFoundException, SQLException {
		UserVO outVO = null;

		String statement = this.NAMESPACE+".doSelectOne";
		
		
		LOG.debug("=========================================");
		LOG.debug("inVO=" + inVO.toString());
		LOG.debug("statement=" + statement);
		LOG.debug("=========================================");

		outVO = this.sqlSessionTemplate.selectOne(statement, inVO);
		LOG.debug("outVO=" + outVO);
		return outVO;
	}

	/**
	 * 전체삭제
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public void deleteAll() throws SQLException {

		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".deleteAll";
		int flag = sqlSessionTemplate.delete(statement);
		LOG.debug("=========================================");
		LOG.debug("flag=" + flag);
		LOG.debug("=========================================");		
	}

	/**
	 * 사용자 등록
	 * 
	 * @param inVO
	 * @return :성공(1)/실패(0)
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int doInsert(final UserVO user) throws ClassNotFoundException, SQLException {
		int flag = 0;
		
		LOG.debug("=========================================");
		LOG.debug("param=" + user.toString());
		LOG.debug("=========================================");

		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doInsert";

		flag = sqlSessionTemplate.insert(statement, user);
		LOG.debug("flag=" + flag);

		return flag;
	}
	
	public int doDelete(UserVO user) throws SQLException {
		int flag = 0;

		LOG.debug("=========================================");
		LOG.debug("param=" + user.toString());
		LOG.debug("=========================================");
		//com.pcwk.ehr.member.doDelete
		//com.pcwk.ehr.member
		//NAMESPACE +"."+id
		String statement = NAMESPACE + ".doDelete";
		
		
		flag = this.sqlSessionTemplate.delete(statement, user);
		
		LOG.debug("flag=" + flag);
		return flag;
	}

	public int doUpdate(UserVO user) throws SQLException {
        int flag = 0;
        
		LOG.debug("=========================================");
		LOG.debug("param=" + user.toString());
		LOG.debug("=========================================");		
		String statement  = NAMESPACE +".doUpdate";
		flag = sqlSessionTemplate.update(statement, user);
		LOG.debug("flag=" + flag);
		return flag;
	}



}
