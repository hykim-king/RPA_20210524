/**
* <pre>
* com.pcwk.ehr.main
* Class Name : MainController.java
* Description: main페이지 Controller
* Author: HKEDU
* Since: 2021/09/15
* Version 0.1
* Copyright (c) by H.R.KIM All right reserved.
* Modification Information
* 수정일   수정자    수정내용
*-----------------------------------------------------
*2021/09/15 최초생성
*-----------------------------------------------------
* </pre>
*/
package com.pcwk.ehr.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author HKEDU
 *
 */
@Controller
public class MainController {

	
	final Logger  LOG = LoggerFactory.getLogger(getClass());

	
	@RequestMapping(value = "main/main_view.do",method = RequestMethod.GET)
	public String mainView(Model model) {
		LOG.debug("============================");
		LOG.debug("=mainView===");
		LOG.debug("============================");
		
		return "main/main";
	}
	
}
