/**
 * 
 */
 
 let eUtil = {};
 
 //Null Check함수
 eUtil.isEmpty = function(str){
    if(null == str)      return true;   
    if(undefined == str) return true;
    
    str = str.toString();
    if(str.trim().length == 0) return true;
    
    return false;
 }
 
 
let EClass = {
    /*
      Ajax Wrapper
      필수) _METHOD : GET/POST
      필수) _URL    : 요청 url
      필수) _PARAMETER : 
      필수) _CALLBACK
      선택) _ASYNC
      선택) _errorMsg
    
     */
    callAjax : function(_METHOD,_URL,_ASYNC,_PARAMETER,_CALLBACK){
        if(eUtil.isEmpty(URL) == false ){
           
           let async =   _ASYNC;
           if(eUtil.isEmpty(async) == true) async = true;         
           
           console.log("=callAjax=================") 
           console.log("_URL:"+_URL);
           console.log("_METHOD:"+_METHOD); 
           console.log("_ASYNC:"+async); 
           
           let _paramArray = Object.keys(_PARAMETER);
           if(_paramArray.length>0){
               for( let i=1;i<_paramArray.length;i++){
                   console.log(_paramArray[i]+":"+_PARAMETER[_paramArray[i]]);
               }
           } 
           console.log("=callAjax=================") 
           //------------------------------------------------------------------- 
         $.ajax({
             type: _METHOD,
             url:_URL,
             asyn:async,
             dataType:"html",
             data:_PARAMETER,
             success:function(data){//통신 성공
                 console.log("success data:"+data);
                 _CALLBACK(data);
             },
             error:function(xhr,status,err){//실패시 처리
                 console.log("error:"+xhr.status);
             }
         });           
           
           //------------------------------------------------------------------- 
        }else{
            alert("올바른 요청이 아닙니다.");
            return;    
        }
    }
    
}















