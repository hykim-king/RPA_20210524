package com.pcwk.ehr.anno.service;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.anno.dao.AnnoDao;

//<bean class="com.pcwk.ehr.anno.dao.AnnoDao" id="annoDao" />
//<bean class="com.pcwk.ehr.anno.service.AnnoServiceImpl" id="annoServiceImpl" >
//  <property name="userDao"    ref="annoDao"/>
//</bean>
@Service
public class AnnoServiceImpl implements AnnoService {
 
	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	AnnoDao  dao;
	
	@Override
	public Object doSelectOne(Object inVO) throws ClassNotFoundException, SQLException {
		
		LOG.debug("-----------------------------");
		LOG.debug("--service doSelectOne----");
		LOG.debug("-----------------------------");
		return dao.doSelectOne(inVO);
	}

}

