package com.pcwk.ehr.anno.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.pcwk.ehr.anno.domain.AnnoVO;
import com.pcwk.ehr.anno.service.AnnoService;


//<bean class="com.pcwk.ehr.anno.service.AnnoServiceImpl" id="annoServiceImpl" >
//<bean class="com.pcwk.ehr.anno.controller.AnnoController" id="annoController" >
//<property name="annoServiceImpl"    ref="annoServiceImpl"/>
//</bean>
@Controller
public class AnnoController {
	final Logger  LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	AnnoService service;
	
	
	@RequestMapping(value = "anno/annoView.do")
	public String annoView() {
		LOG.debug("===========================");
		LOG.debug("===========================");		
		return "anno/anno_mng";
	}
	
	
	//anno/doSelectOne.do?user_id=jamesol&passwd=1234
	//http://localhost:8080/ehr/anno/doSelectOne.do?user_id=jamesol&passwd=1234
	@RequestMapping(value = "anno/doSelectOne.do")
	public String doSelectOne(Model model,HttpServletRequest req) throws ClassNotFoundException, SQLException{
		
		//request -> VO
		String userId = req.getParameter("user_id");
		String passwd = req.getParameter("passwd");
		AnnoVO inVO =new AnnoVO();
		inVO.setUserId(userId);
		inVO.setPasswd(passwd);
		LOG.debug("===========================");
		LOG.debug("==inVO=="+inVO);
		LOG.debug("===========================");
		
		AnnoVO outVO= (AnnoVO) service.doSelectOne(inVO);
		LOG.debug("===========================");
		LOG.debug("==outVO=="+outVO);
		LOG.debug("===========================");
		model.addAttribute("vo", outVO);
		return "anno/anno_mng";
	}
	
}
