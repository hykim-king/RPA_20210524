package com.pcwk.ehr.anno.service;

import java.sql.SQLException;
import java.util.List;

public interface AnnoService {

	
	Object doSelectOne(Object inVO) throws ClassNotFoundException, SQLException;
	
//	int doInsert(Object user) throws ClassNotFoundException, SQLException;
//	
//	int doDelete(Object user) throws SQLException;
//	
//	int doUpdate(Object user) throws SQLException;
//	
//	List<?> doRetrieve(Object user) throws SQLException;
}
