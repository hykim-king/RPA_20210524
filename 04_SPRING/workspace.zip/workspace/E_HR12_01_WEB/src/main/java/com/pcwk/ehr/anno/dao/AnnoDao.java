package com.pcwk.ehr.anno.dao;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.pcwk.ehr.anno.domain.AnnoVO;



/**
 * <bean class="com.pcwk.ehr.anno.dao.AnnoDao" id="annoDao" />
 * xml에 별도로 등록할 필요가 없음.
 * @author HKEDU
 *
 */
@Repository
public class AnnoDao {
	
	final Logger  LOG = LoggerFactory.getLogger(getClass());
	

	public Object doSelectOne(Object inVO) throws ClassNotFoundException, SQLException{
		
		AnnoVO  vo = (AnnoVO) inVO;
		LOG.debug("===========================");
		LOG.debug("==vo=="+vo);
		LOG.debug("===========================");
		
		vo.setPasswd(vo.getPasswd()+"_CALL");
		return vo;
	}
//
//	/**
//	 * 전체삭제
//	 * 
//	 * @throws ClassNotFoundException
//	 * @throws SQLException
//	 */
//	void deleteAll() throws SQLException{
//		
//	}
//
//	/**
//	 * 사용자 등록
//	 * 
//	 * @param inVO
//	 * @return :성공(1)/실패(0)
//	 * @throws ClassNotFoundException
//	 * @throws SQLException
//	 */
//	int doInsert(Object user) throws ClassNotFoundException, SQLException{
//		return 0;
//	}
//
//	/**
//	 * 사용자 삭제
//	 * @param user
//	 * @return:성공(1)/실패(0)
//	 * @throws SQLException
//	 */
//	int doDelete(Object user) throws SQLException{
//		return 0;
//	}
//	
//	/**
//	 * 수정
//	 * @param user
//	 * @return:성공(1)/실패(0)
//	 * @throws SQLException
//	 */
//	int doUpdate(Object user) throws SQLException{
//		return 0;
//	}
//	
//	/**
//	 * 목록조회
//	 * @param user
//	 * @return List<?>
//	 * @throws SQLException
//	 */
//	List<?> doRetrieve(Object user) throws SQLException{
//		return null;
//	}
}
