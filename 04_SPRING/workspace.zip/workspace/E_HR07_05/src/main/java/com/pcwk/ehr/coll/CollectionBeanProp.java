package com.pcwk.ehr.coll;

import java.util.Properties;

public class CollectionBeanProp {

	private Properties addressProps;

	public CollectionBeanProp() {
		super();
	}

	public Properties getAddressProps() {
		return addressProps;
	}

	public void setAddressProps(Properties addressProps) {
		this.addressProps = addressProps;
	}

}
