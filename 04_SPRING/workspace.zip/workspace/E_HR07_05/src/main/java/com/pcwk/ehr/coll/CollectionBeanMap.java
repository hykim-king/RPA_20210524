package com.pcwk.ehr.coll;

import java.util.Map;

public class CollectionBeanMap {
	private Map<String, String> addressMap;
	
	public CollectionBeanMap() {
		super();
	}

	public Map<String, String> getAddressMap() {
		return addressMap;
	}

	public void setAddressMap(Map<String, String> addressMap) {
		this.addressMap = addressMap;
	}

}
