package com.pcwk.ehr.coll;

import static org.junit.Assert.*;

import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/coll/applicationContextProp.xml")
public class CollectionBeanPropTest {
	final Logger LOG = Logger.getLogger(getClass());
	@Autowired
	ApplicationContext context;

	CollectionBeanProp collectionBeanProp;

	@Before
	public void setUp() throws Exception {
		collectionBeanProp = context.getBean("collectionBeanProp", CollectionBeanProp.class);

		LOG.debug("============================");
		LOG.debug("=context=" + context);
		LOG.debug("=collectionBeanProp=" + collectionBeanProp);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		Properties props = collectionBeanProp.getAddressProps();

		Set<Object> set = props.keySet();

		for (Object key : set) {
			LOG.debug(key + "," + props.getProperty(key.toString()));
		}

	}

}
