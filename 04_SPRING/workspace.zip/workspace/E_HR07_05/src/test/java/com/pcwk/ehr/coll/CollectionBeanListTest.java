package com.pcwk.ehr.coll;

import static org.junit.Assert.*;

import java.util.List;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/coll/applicationContextList.xml")
public class CollectionBeanListTest {
    final Logger LOG = Logger.getLogger(getClass());
	
    @Autowired
    ApplicationContext  context;
    
    CollectionBeanList  collectionBeanList;
    
	@Before
	public void setUp() throws Exception {
		collectionBeanList = (CollectionBeanList) context.getBean("collectionBeanList");
		LOG.debug("============================");
		LOG.debug("=context="+context);
		LOG.debug("=collectionBeanList="+collectionBeanList);
		LOG.debug("============================");
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void test() {
		LOG.debug("=test()=");
		
		List<String> list = collectionBeanList.getAddressList();
		for( String str  :list) {
			LOG.debug(str);
		}
		
		
	}

}
