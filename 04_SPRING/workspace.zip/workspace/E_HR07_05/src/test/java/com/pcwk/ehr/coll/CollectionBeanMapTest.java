package com.pcwk.ehr.coll;

import static org.junit.Assert.*;

import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/com/pcwk/ehr/coll/applicationContextMap.xml")
public class CollectionBeanMapTest {
    final Logger LOG = Logger.getLogger(getClass());
    
    @Autowired
    ApplicationContext  context;
    
    CollectionBeanMap collectionBeanMap;
    
	@Before
	public void setUp() throws Exception {
		
		collectionBeanMap = context.getBean("collectionBeanMap", CollectionBeanMap.class);
		LOG.debug("============================");
		LOG.debug("=context="+context);
		LOG.debug("=collectionBeanMap="+collectionBeanMap);
		LOG.debug("============================");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		Map<String, String> map = collectionBeanMap.getAddressMap();
		 
		Set<String> set = map.keySet();
		
		for(String key :set) {
			
			LOG.debug(key+","+map.get(key));
			
		}
		
		
		
		
		
	}

}
