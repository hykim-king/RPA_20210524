package com.pcwk.ehr;

public class SamsungTv implements Tv {

	private String brandNm = "SAMSUNG";
	
	private int price;
	private Speaker speaker;
	
	public SamsungTv() {
		LOG.debug("============================");
		LOG.debug("=SamsungTv()=");
		LOG.debug("============================");		
	}
	
	//Setter Injection
	public void setPrice(int price) {
		this.price = price;
	}

	//Setter Injection
	public void setSpeaker(Speaker speaker) {
		this.speaker = speaker;
	}



	public void powerOn() {
		LOG.debug("============================");
		LOG.debug("=powerOn()=");
		LOG.debug("============================");

	}

	public void powerOff() {
		LOG.debug("============================");
		LOG.debug("=powerOff()=");
		LOG.debug("============================");

	}

	public void volumeUp() {
		speaker.volumeUp();

	}

	public void volumeDown() {
		speaker.volumeDown();

	}

}
